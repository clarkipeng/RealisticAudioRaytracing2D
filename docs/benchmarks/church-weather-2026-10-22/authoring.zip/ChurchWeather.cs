using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;

// One-off authoring/check tool kept with the evidence, not shipped in Assets.
public static class ChurchWeather
{
    const string Output="/Users/clarkpeng/UnityGames/realisticaudioraytracing2d/.context/church-weather";
    static readonly string[] Clips={"RainCourtyard","RainGarden","Thunder"};
    public static void Build()
    {
        if(!Application.isBatchMode || Application.isPlaying)throw new Exception("Offline batch only");
        foreach(string name in Clips)
        {
            var importer=(AudioImporter)AssetImporter.GetAtPath("Assets/External/Church/Audio/"+name+".wav");
            var settings=importer.defaultSampleSettings;
            settings.loadType=AudioClipLoadType.DecompressOnLoad;settings.compressionFormat=AudioCompressionFormat.PCM;
            settings.sampleRateSetting=AudioSampleRateSetting.PreserveSampleRate;settings.preloadAudioData=true;
            importer.defaultSampleSettings=settings;importer.forceToMono=false;importer.loadInBackground=false;importer.SaveAndReimport();
        }
        EditorSceneManager.OpenScene("Assets/Scenes/Church.unity");
        var session=UnityEngine.Object.FindAnyObjectByType<SceneSession>();var manager=session.manager;
        if(manager.takeRoot.Find("Weather")!=null)throw new Exception("Weather already authored; edit its existing objects");
        var root=new GameObject("Weather").transform;root.SetParent(manager.takeRoot,false);
        var names=new[]{"Rain courtyard","Rain east garden","Thunder outside"};
        var ids=new[]{"weather-rain-courtyard","weather-rain-garden","weather-thunder"};
        var positions=new[]{new Vector3(-7,1.3f,-40),new Vector3(23,1.3f,4),new Vector3(-32,45,-16)};
        var gains=new[]{.6f,.8f,2f};
        var sources=new RaytracedAudioSource[3];
        for(int i=0;i<sources.Length;i++)
        {
            var source=new GameObject(names[i]).AddComponent<RaytracedAudioSource>();sources[i]=source;
            source.transform.SetParent(root,false);source.transform.position=positions[i];source.rayTraceManager=manager;
            source.clip=AssetDatabase.LoadAssetAtPath<AudioClip>("Assets/External/Church/Audio/"+Clips[i]+".wav");
            source.loop=true;source.gain=gains[i];
            manager.takeObjects.Add(new RayTraceManager.TakeObjectBinding{id=ids[i],transform=source.transform,geometry=false});
        }
        session.startSounds=session.startSounds.Concat(sources).ToArray();manager.RegisterTakeObjects();
        EditorUtility.SetDirty(manager);EditorUtility.SetDirty(session);
        EditorSceneManager.SaveScene(session.gameObject.scene);AssetDatabase.SaveAssets();
        Verify();
    }

    public static void Verify()
    {
        if(!Application.isBatchMode || Application.isPlaying)throw new Exception("Offline batch only");
        EditorSceneManager.OpenScene("Assets/Scenes/Church.unity");
        var session=UnityEngine.Object.FindAnyObjectByType<SceneSession>();var manager=session.manager;
        string originalSettings=EditorJsonUtility.ToJson(manager);
        var weather=manager.takeRoot.Find("Weather").GetComponentsInChildren<RaytracedAudioSource>();
        if(weather.Length!=3 || manager.takeSources.Count!=9 || session.startSounds.Length!=5)throw new Exception("Source registry mismatch");
        Physics.SyncTransforms();
        foreach(var source in weather)
        {
            if(!session.startSounds.Contains(source) || !manager.takeSources.Contains(source) || source.streamed || !source.loop ||
                source.clip==null || source.clip.frequency!=44100 || source.clip.channels!=1 || source.rayTraceManager!=manager)
                throw new Exception("Invalid weather source "+source.name);
            if(Physics.OverlapSphere(source.transform.position,.1f).Length!=0)throw new Exception("Emitter intersects solid geometry: "+source.name);
        }
        var scene=SceneToTake.Compile(manager.takeObjects,manager.takeDimension,manager.takeCurveTolerance,manager.takeDefaultMaterial,
            weather.Select(s=>s.transform).ToArray(),weather.Select(s=>s.clip).ToArray(),manager.takeListeners.ToArray(),out var geometry);
        if(geometry.Length!=17321)throw new Exception("Weather changed acoustic geometry");
        var state=manager.takeObjects.Select((b,i)=>SceneToTake.Observe(scene,i,b.transform)).ToArray();
        state[scene.listeners[0]].position=new Vector3(-2,2.7f,-41);
        var pcm=weather.Select(s=>RayTraceManager.LoadSample(s.clip,44100)).ToArray();
        const int rate=44100;
        const long offset=7*rate;
        string takeDirectory=Output+"/take";
        using(var writer=new AcousticTake.Writer(takeDirectory,rate,scene,geometry,pcm))
        {
            writer.Append(0,state);writer.Append(3*rate,state);
            for(int i=0;i<weather.Length;i++)writer.Append(new AcousticTake.VoiceEvent{
                sample=0,sourceIndex=i,action=AcousticTake.VoiceAction.Play,gain=weather[i].gain,loop=true,clipOffset=offset});
            writer.Complete();
        }
        using(var take=AcousticTake.Open(takeDirectory))
        {
            var signals=TakeRender.Signal.FromTake(take,pcm);
            for(int i=0;i<weather.Length;i++)
            {
                // Exercise the real source reader at wraparound and at the start offset
                // used when a multiplayer client joins an already-running world.
                var signal=new TakeRender.Signal(pcm[i]);signal.SetActive(0,true);signal.Append(take.Events[i]);
                foreach(long at in new[]{0L,1L,pcm[i].LongLength-offset-1,pcm[i].LongLength-offset,pcm[i].LongLength*2})
                {
                    float expected=pcm[i][(at+offset)%pcm[i].LongLength]*weather[i].gain;
                    if(signal.Read((double)at)!=expected)throw new Exception("Clip phase changed at wrap/join");
                    if(at<=take.Metadata.durationSamples && signals[i].Read((double)at)!=expected)throw new Exception("Recorded event replay changed PCM");
                }
                if(AcousticTake.HashFile(takeDirectory+"/clip-"+i+".f32")!=scene.clips[i].sha256)throw new Exception("PCM round-trip failed");
            }
            var settings=JsonUtility.FromJson<TakeRender.Settings>(JsonUtility.ToJson(manager.directSettings));
            // A short smoke render is intentionally cheaper than the saved live profile.
            settings.fftSize=256;settings.spectralHop=64;settings.raysPerBin=1;settings.maxBounces=4;
            settings.responseStepSamples=4096;settings.maximumResponsesPerBatch=4;settings.tailSamples=4096;
            var report=TakeRender.RenderDirect(take,settings,Output+"/render",shader:manager.directShader);
            if(!report.complete)throw new Exception("Offline renderer did not finish");
        }
        if(EditorJsonUtility.ToJson(manager)!=originalSettings)throw new Exception("Diagnostic changed saved audio settings");
        var cam=session.player.GetComponentInChildren<Camera>();cam.transform.position=new Vector3(0,3,-8);cam.transform.LookAt(new Vector3(0,8,19));
        session.GetComponent<ChurchVisualPreset>().Apply(ChurchVisualPreset.Preset.PolishedLowPoly);
        var rt=new RenderTexture(1280,900,24){antiAliasing=4};cam.targetTexture=rt;
        var overlay=cam.GetComponent<AudioSourceOverlay>();overlay.visible=true;overlay.Refresh();Canvas.ForceUpdateCanvases();overlay.Refresh();
        var labels=cam.GetComponentsInChildren<Text>().Where(t=>t.gameObject.activeInHierarchy).Select(t=>t.text).ToArray();
        if(labels.Length!=5 || weather.Any(s=>!labels.Any(t=>t.Contains(s.name))))throw new Exception("Weather marker missing");
        File.WriteAllLines(Output+"/labels.txt",labels);
        cam.Render();RenderTexture.active=rt;var tex=new Texture2D(rt.width,rt.height,TextureFormat.RGB24,false);
        tex.ReadPixels(new Rect(0,0,rt.width,rt.height),0,0);tex.Apply();File.WriteAllBytes(Output+"/weather-sources.png",tex.EncodeToPNG());
        cam.targetTexture=null;RenderTexture.active=null;UnityEngine.Object.DestroyImmediate(tex);rt.Release();UnityEngine.Object.DestroyImmediate(rt);
        File.WriteAllText(Output+"/verification.json","{\"registeredSources\":9,\"autostartClipSources\":5,\"weatherEmitters\":3,\"weatherOutsideSolids\":true,\"acousticTriangles\":17321,\"clipPhaseAndRecordedEvents\":true,\"originalManagerSettingsPreserved\":true,\"visibleLabels\":5,\"renderScope\":\"3 second fixed outdoor receiver, weather only, reduced FFT/ray/bounce profile; no Play mode or network/microphone startup\"}");
        Debug.Log("CHURCH_WEATHER_VERIFIED");
    }
}
