from pathlib import Path
import hashlib, json, warnings
import numpy as np
from scipy.io import wavfile
from scipy.signal import resample_poly

root = Path(__file__).resolve().parent
output = root.parent / 'gpu-audio/runner/Assets/External/Church/Audio'
rate = 44100

def read(number):
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', wavfile.WavFileWarning)
        hz, raw = wavfile.read(root / (number + '.wav'))
    audio = raw.astype(np.float64) / (2 ** (raw.dtype.itemsize * 8 - 1))
    if audio.ndim == 2:
        audio = audio.mean(axis=1)
    if hz != rate:
        divisor = np.gcd(hz, rate)
        audio = resample_poly(audio, rate // divisor, hz // divisor)
    return audio

rain = read('0124')
clips = {}
for name, start, duration in [('RainCourtyard', 1, 11), ('RainGarden', 13, 13)]:
    count = duration * rate
    raw = rain[start * rate:(start + duration + 1) * rate].copy()
    phase = np.linspace(0, np.pi / 2, rate)
    audio = raw[:count].copy()
    # The end joins the original next sample; the first second transitions back
    # into the head with constant-power weights, without a silent loop boundary.
    audio[:rate] = raw[count:] * np.cos(phase) + raw[:rate] * np.sin(phase)
    audio *= .4 / np.max(np.abs(audio))
    clips[name] = audio

thunder = read('3114')
thunder -= np.mean(thunder)
fade = round(rate * .08)
thunder[:fade] *= np.sin(np.linspace(0, np.pi / 2, fade)) ** 2
thunder[-fade:] *= np.cos(np.linspace(0, np.pi / 2, fade)) ** 2
thunder *= .7 / np.max(np.abs(thunder))
timeline = np.zeros(42 * rate)
timeline[8 * rate:8 * rate + len(thunder)] = thunder
clips['Thunder'] = timeline

stats = {}
for name, audio in clips.items():
    pcm = np.round(audio * 32767).astype(np.int16)
    wavfile.write(output / (name + '.wav'), rate, pcm)
    decoded = pcm.astype(np.float64) / 32768
    seam = float(abs(decoded[0] - decoded[-1]))
    ordinary = float(np.percentile(abs(np.diff(decoded)), 99.9))
    assert np.isfinite(decoded).all() and np.max(abs(decoded)) < 1
    assert seam <= ordinary, (name, seam, ordinary)
    if name.startswith('Rain'):
        assert min(np.sqrt(np.mean(decoded[i:i+rate]**2)) for i in range(0,len(decoded),rate)) > .01
    stats[name] = dict(samples=len(pcm), seconds=len(pcm)/rate, peak=float(np.max(abs(decoded))),
                       rms=float(np.sqrt(np.mean(decoded**2))), loopSeamStep=seam,
                       ordinaryStep99_9Percentile=ordinary,
                       sha256=hashlib.sha256((output/(name+'.wav')).read_bytes()).hexdigest())
stats['rainCorrelation'] = float(np.corrcoef(clips['RainCourtyard'],clips['RainGarden'][:11*rate])[0,1])
assert abs(stats['rainCorrelation']) < .05
(root/'clip-checks.json').write_text(json.dumps(stats,indent=2)+'\n')
print(json.dumps(stats,indent=2))
