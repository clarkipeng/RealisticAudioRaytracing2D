from pathlib import Path
import hashlib,json,re,shutil,subprocess,zipfile
import numpy as np
from scipy.io import wavfile
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

repo=Path.cwd();scratch=repo/'.context/church-weather';runner=repo/'.context/gpu-audio/runner'
out=repo/'docs/benchmarks/church-weather-2026-10-22';out.mkdir(exist_ok=True)
scene=Path('Assets/Scenes/Church.unity')
old=subprocess.check_output(['git','show','HEAD:'+str(scene)]).decode()
new='\n'.join(line.rstrip() for line in (runner/scene).read_text().splitlines())+'\n'
def blocks(s):return {int(i):(int(t),body) for t,i,body in re.findall(r'^--- !u!(\d+) &(\d+)(.*?)(?=^--- !u!|\Z)',s,re.M|re.S)}
a,b=blocks(old),blocks(new);colliders={64,65,135,136,143};preserved=0
for i,(typ,body) in a.items():
 if typ not in colliders|{4,33,114}:continue
 other=b[i][1]
 if typ==4:
  body=re.sub(r'  m_Children:.*?(?=  m_Father:)','',body,flags=re.S)
  other=re.sub(r'  m_Children:.*?(?=  m_Father:)','',other,flags=re.S)
 if typ==114 and 'Acoustics::SceneSession' in body:
  body=re.sub(r'  startSounds:.*?(?=  retainFullReference:)','',body,flags=re.S)
  other=re.sub(r'  startSounds:.*?(?=  retainFullReference:)','',other,flags=re.S)
 if typ==114 and 'Acoustics::RayTraceManager' in body:
  body=re.sub(r'  takeObjects:.*?(?=  takeListeners:)','',body,flags=re.S)
  other=re.sub(r'  takeObjects:.*?(?=  takeListeners:)','',other,flags=re.S)
 assert body==other,('Unexpected old component change',i)
 preserved+=int(typ in colliders)
assert sum(t in colliders for t,v in b.values())==preserved==58
# Existing persisted IDs and source references must remain intact and in order.
for token in re.findall(r'  - id: (.+)\n',old):assert '  - id: '+token+'\n' in new
(repo/scene).write_text(new)
assets=[scene]
for name in ['RainCourtyard','RainGarden','Thunder']:
 for suffix in ['.wav','.wav.meta']:
  p=Path('Assets/External/Church/Audio')/(name+suffix);shutil.copy2(runner/p,repo/p);assets.append(p)
verification=json.loads((scratch/'verification.json').read_text());verification['existingCollidersPreserved']=preserved
rate,pcm=wavfile.read(scratch/'render/listener-0.wav')
assert np.isfinite(pcm).all() and np.max(abs(pcm))<1 and np.mean(pcm*pcm)>1e-8
verification['renderPeak']=float(np.max(abs(pcm)));verification['renderRms']=float(np.sqrt(np.mean(pcm*pcm)))
(out/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
for name in ['clip-checks.json','weather-sources.png','labels.txt']:shutil.copy2(scratch/name,out/name)
shutil.copy2(scratch/'render/listener-0.wav',out/'outdoor-smoke.wav')
shutil.copy2(scratch/'render/run.json',out/'render.json')
# A small inspectable artifact, with no browser or audio playback.
fig,axes=plt.subplots(3,1,figsize=(11,7),layout='constrained')
t=np.arange(len(pcm))/rate
axes[0].plot(t[::16],pcm[::16],lw=.5);axes[0].set(title='Outdoor weather: reduced-cost GPU smoke render',ylabel='Pressure amplitude')
axes[1].specgram(pcm,NFFT=1024,Fs=rate,noverlap=768,cmap='magma',vmin=-115,vmax=-50)
axes[1].set(ylim=(0,10000),ylabel='Frequency (Hz)',xlabel='Render time (s); source clips start at phase 7 s')
_,thunder=wavfile.read(repo/'Assets/External/Church/Audio/Thunder.wav')
axes[2].plot(np.arange(len(thunder))[::256]/rate,thunder[::256]/32768,lw=.6)
axes[2].set(title='Authored thunder loop: one recorded roll, then quiet',xlabel='Loop time (s)',ylabel='Source amplitude',xlim=(0,42))
fig.savefig(out/'waveform-spectrogram.png',dpi=130);plt.close(fig)
with zipfile.ZipFile(out/'authoring.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['prepare.py','publish.py','downloads.json','build.log']:z.write(scratch/name,name)
 z.write(runner/'Assets/Editor/ChurchWeather.cs','ChurchWeather.cs')
 for name in ['rain-and-storm-s0124.html','thunder-3-s3114.html']:z.write(scratch/name,name)
with zipfile.ZipFile(out/'authoring.zip') as z:assert z.testzip() is None
manifest={str(p):hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in assets}
manifest.update({str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.name!='manifest.json'})
(out/'manifest.json').write_text(json.dumps({'parentCommit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'sha256':manifest},indent=2)+'\n')
conductor=Path('/Users/clarkpeng/conductor/workspaces/realisticaudioraytracing2d/tyler/.context')
shutil.copy2(out/'weather-sources.png',conductor/'church-weather-sources.png')
shutil.copy2(out/'waveform-spectrogram.png',conductor/'church-weather-audio.png')
print(json.dumps(verification,indent=2))
