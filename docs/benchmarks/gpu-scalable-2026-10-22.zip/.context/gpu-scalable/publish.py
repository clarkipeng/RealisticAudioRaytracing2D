import hashlib,json,platform,subprocess,zipfile
from pathlib import Path
import xml.etree.ElementTree as ET
import numpy,scipy,matplotlib
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];DOC=ROOT/'docs/benchmarks'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
final=[]
for stamp,count in (('142450',67),('142604',4),('142653',19)):
 p=OUT/f'gpu-{stamp}.xml';t=ET.parse(p).getroot();assert t.get('result')=='Passed' and int(t.get('passed'))==count
 provenance=json.loads((OUT/f'provenance-{stamp}.json').read_text())
 for name in ('ScalableRoutes.compute','ScalableRouteChecks.cs'):
  assert next(v for k,v in provenance['files'].items() if k.endswith('/'+name))==sha(OUT/name)
 final.append(dict(file=str(p.relative_to(ROOT)),sha256=sha(p),**t.attrib))
controls={'control-1','control-9','control-25','empty','subset','no-support'};files=set()
for p in OUT.rglob('*'):
 if not p.is_file() or '__pycache__' in p.parts or p.name=='manifest.json':continue
 rel=p.relative_to(OUT)
 if p.suffix=='.log' and p.name!='gpu-130545.log':continue
 if len(rel.parts)==1 or rel.parts[0] in ('source','streaming','compact16k'):
  files.add(p);continue
 if p.parent.name in controls:
  if p.name in ('generated.bin','routes.bin','bvh.bin','config.txt','generated.csv','scalable.csv','generation.json','scaling.json'):
   files.add(p);continue
  if p.name.startswith(('edge-','mirror-','counts-','valid-')):
   parts=p.stem.split('-');config=tuple(map(int,parts[-2:]));configs={tuple(map(int,x.split(','))) for x in (p.parent/'config.txt').read_text().splitlines()}
   if config in configs and config[0]==1:files.add(p)
 elif p.suffix in ('.json','.csv','.txt'):files.add(p)
for meta in OUT.glob('*/generation.json'):files.add(Path(json.loads(meta.read_text())['scene']))
for name in ('1','9','25','barrier','staggered','slit','corridor'):
 p=Path(json.loads((OUT/f'map-{name}-65536/generation.json').read_text())['scene']).parent;step='0.35' if name.isdigit() else '0.25'
 for ext in ('npz','json'):files.add(p/f'reference-{step}-250.{ext}')
assert all(p.is_file() for p in files)
save(OUT/'manifest.json',{str(p.relative_to(ROOT)):sha(p) for p in sorted(files)});files.add(OUT/'manifest.json')
archive=DOC/'gpu-scalable-2026-10-22.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(files):z.write(p,p.relative_to(ROOT))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
save(DOC/'gpu-scalable-2026-10-22.json',dict(baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
 scope='Offline, static rigid extruded rectangles, equal source/receiver z=0, 250 Hz, width 1, at most two interactions. No live renderer change.',
 environment=dict(python=platform.python_version(),numpy=numpy.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__,unity='6000.4.1f1',gpu='Apple M5 / Metal',mode='Batch, audio disabled, nice 15, one worker, BLAS threads limited'),
 method='Linear endpoint-visibility/facing lists, bounded candidate preparation and zero-support compaction, probability-corrected complete-path height integration, BVH visibility, bounded second-reflection sampling, GPU sum.',
 timing='Fresh old/new component sums: input packing, buffer setup, warm geometry work, receiver submission, dispatch and blocking readback. New includes BVH/extra draw preparation. Excludes process startup, compile/warmup, diagnostics exports, reference solving, DSP/audio. Baseline runs first per case; new configurations rotate per receiver. Not GPU timestamps or a statistical speed guarantee.',
 results=json.loads((OUT/'summary.json').read_text()),controls=json.loads((OUT/'checks.json').read_text()),smallSceneRepeats=json.loads((OUT/'repeats.json').read_text()),finalSuites=final,
 complexity=dict(previous='O(E^2 W) visibility, O(E^2) storage',new='O((E + min(S,R) + min(N,M)) Q(W) + N) receiver work; O(W+E+S+N) storage. R candidate paths, M mirror pairs, Q actual visibility-query cost. Fixed depth.'),
 archive=dict(file=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,files=len(files)),images={p.name:sha(p) for p in DOC.glob('gpu-scalable-*-2026-10-22.png')},
 limitations=['Full per-receiver edge scan and serial linear/bounded compactions remain; not fixed-ray-count scaling.', 'The 16K path budget failed 100-box parity; final 65K covers that control. Above 100 boxes accuracy is unqualified.', 'Large-layout candidate acceptance falls markedly; fixed compute does not guarantee fixed error.', 'Dense-scene wave-reference error remains large; no DLSS teacher/live audio qualification.', 'Small-scene timing regressions and large host variation are retained; no no-slowdown guarantee.', 'No finite 3D, arbitrary material/mesh, moving, higher-order or broadband validation. Existing shader compiler warnings remain.']))
print('Archived',len(files),'files;',archive.stat().st_size,'bytes')
