bool Faces(uint plane,float2 p)
{
    uint side=plane%4;float d=p[PlaneAxis(plane)]-PlanePosition(plane);
    return (side==0 || side==3)?d<0:d>0;
}
[numthreads(64,1,1)]
void BuildFlags(uint id:SV_DispatchThreadID)
{
    if(id>=EdgeCount)return;
    uint a=Visible(Source,Corner(id))?1:0,b=Visible(Corner(id),Receiver)?1:0;
    Flags[id]=a|(b<<1)|((uint)Faces(id,Source)<<2)|((uint)Faces(id,Receiver)<<3)|((a&b)<<4);
}
[numthreads(1,1,1)]
void Compact(uint id:SV_DispatchThreadID)
{
    uint count[5]={0,0,0,0,0};
    for(uint i=0;i<EdgeCount;i++)for(uint j=0;j<5;j++)
        if((Flags[i]&(1u<<j))!=0)ListsOut[j*EdgeCount+count[j]++]=i;
    for(uint j=0;j<5;j++)CountsOut[j]=count[j];
    float paths=count[4]+(float)count[0]*count[1]+(float)count[2]*count[1]+(float)count[0]*count[3];
    DispatchArgs[0]=max(1,((uint)min((float)PathBudget,paths)+63)/64);DispatchArgs[1]=1;DispatchArgs[2]=1;
    uint mirrorWork=(uint)min((float)SampleCount,max(1.0,max((float)count[2],(float)count[2]*count[3])));
    DispatchArgs[3]=(mirrorWork+63)/64;DispatchArgs[4]=1;DispatchArgs[5]=1;
}
uint Item(uint list,uint i){return Lists[list*EdgeCount+i];}
float4 CandidateCounts(){return float4(Counts[4],(float)Counts[0]*Counts[1],(float)Counts[2]*Counts[1],(float)Counts[0]*Counts[3]);}
// Small candidate sets are stratified completely; larger ones are sampled with
// independent discrete choices. No large E*E integer index or allocation.
struct Prepared {Step first,second;float4 info;};
RWStructuredBuffer<Prepared> PreparedOut;
StructuredBuffer<Prepared> PreparedIn;
RWStructuredBuffer<uint> SelectedOut, ValidOut;
StructuredBuffer<uint> Selected, Valid;
Route Choose(uint tile,out Step first,out Step second)
{
    Route route=(Route)0;first=(Step)0;second=(Step)0;
    float4 sizes=CandidateCounts();float total=dot(sizes,1);
    if(total==0)return route;uint family=0,a=0,b=0;float inverse;
    if(total<=PathBudget)
    {
        if(tile>=(uint)total)return route;
        uint rank=tile;inverse=1;
        for(uint j=0;j<3;j++){if(rank<(uint)sizes[j])break;rank-=(uint)sizes[j];family++;}
        uint columns=family==1 || family==2?Counts[1]:(family==3?Counts[3]:1);a=rank/columns;b=rank%columns;
    }
    else
    {
        float3 u=RouteDraws[tile];float x=u.x*total,before=0;
        for(uint j=0;j<3;j++){if(x<before+sizes[j])break;before+=sizes[j];family++;}
        uint rows=family==0?Counts[4]:(family==2?Counts[2]:Counts[0]);
        uint columns=family==1 || family==2?Counts[1]:(family==3?Counts[3]:1);
        a=min(rows-1,(uint)(u.y*rows));b=min(columns-1,(uint)(u.z*columns));inverse=total/PathBudget;
    }
    route.weight=inverse;
    if(family==0)
    {
        uint e=Item(4,a);first=MakeStep(e,Source,Receiver,length(Receiver-Corner(e)));route.depth=1;
    }
    else if(family==1)
    {
        a=Item(0,a);b=Item(1,b);if(a==b || !Visible(Corner(a),Corner(b)))return (Route)0;
        float last=length(Receiver-Corner(b));first=MakeStep(a,Source,Corner(b),length(Corner(b)-Corner(a))+last);
        second=MakeStep(b,Corner(a),Receiver,last);route.depth=2;
        if(a/4==b/4 && any(Corner(a)==Corner(b)))route.weight*=.5;
    }
    else
    {
        uint e=family==2?Item(1,b):Item(0,a),plane=family==2?Item(2,a):Item(3,b);float2 from=Source,to=Receiver;
        if(family==2){if(!MirrorLeg(plane,Source,Corner(e)))return (Route)0;from=Reflect(plane,Source);}
        else {if(!MirrorLeg(plane,Corner(e),Receiver))return (Route)0;to=Reflect(plane,Receiver);}
        first=MakeStep(e,from,to,length(to-Corner(e)));route.depth=1;
    }
    if(first.shape.x+first.shape.z>=Horizon || all(first.halfSine==0) || (route.depth==2 && all(second.halfSine==0)))route.depth=0;
    return route;
}
float MirrorDistance(uint a,uint b)
{
    float2 first=Reflect(a,Source),second=Reflect(b,first),hitA=0,hitB=0;
    if(a!=b && HitMirror(b,Receiver,second,hitB) && HitMirror(a,hitB,first,hitA) && Visible(Source,hitA) && Visible(hitA,hitB) && Visible(hitB,Receiver))return length(second-Receiver);
    return 0;
}
float2 Pressure(float distance)
{
    if(distance<=0 || distance>=Horizon)return 0;float2 phase;sincos(-WaveNumber*distance,phase.y,phase.x);return phase/distance;
}
[numthreads(64,1,1)]
void Mirrors(uint3 id:SV_DispatchThreadID,uint3 group:SV_GroupID,uint lane:SV_GroupIndex)
{
    float2 value=0;
    if(id.x<SampleCount){
    // First-order reflections and direct sound require only linear work.
    for(uint a=id.x;a<Counts[2];a+=SampleCount)
    {
        uint plane=Item(2,a);if(MirrorLeg(plane,Source,Receiver))value+=Pressure(length(Reflect(plane,Source)-Receiver));
    }
    if(id.x==0 && Visible(Source,Receiver))value+=Pressure(length(Receiver-Source));
    float count=(float)Counts[2]*Counts[3];
    if(count<=SampleCount)
    {
        if(id.x<(uint)count)value+=Pressure(MirrorDistance(Item(2,id.x/Counts[3]),Item(3,id.x%Counts[3])));
    }
    else
    {
        float3 u=RouteDraws[id.x];uint a=min(Counts[2]-1,(uint)(u.y*Counts[2])),b=min(Counts[3]-1,(uint)(u.z*Counts[3]));
        value+=Pressure(MirrorDistance(Item(2,a),Item(3,b)))*(count/SampleCount);
    }
    }
    if(Capture!=0 && id.x<SampleCount)MirrorContributions[id.x]=value;
    Sum[lane]=value;GroupMemoryBarrierWithGroupSync();
    for(uint stride=32;stride>0;stride>>=1){if(lane<stride)Sum[lane]+=Sum[lane+stride];GroupMemoryBarrierWithGroupSync();}
    if(lane==0)Partials[group.x]+=Sum[0];
}
// Candidate storage is bounded by the requested path budget, not scene pairs.
[numthreads(64,1,1)]
void PreparePaths(uint id:SV_DispatchThreadID)
{
    if(id>=PathBudget || id>=dot(CandidateCounts(),1))return;Prepared p=(Prepared)0;Route r=Choose(id,p.first,p.second);p.info=float4(r.depth,r.weight,0,0);PreparedOut[id]=p;
}
[numthreads(1,1,1)]
void CompactPaths(uint id:SV_DispatchThreadID)
{
    uint count=0,limit=(uint)min((float)PathBudget,dot(CandidateCounts(),1));for(uint i=0;i<limit;i++)if(PreparedIn[i].info.x!=0)SelectedOut[count++]=i;ValidOut[0]=count;
}
[numthreads(64,1,1)]
void IntegratePaths(uint3 id:SV_DispatchThreadID,uint3 group:SV_GroupID,uint lane:SV_GroupIndex)
{
    float2 value=0;uint count=Valid[0];
    if(id.x<SampleCount && count>0)
    {
        uint base=SampleCount/count,extra=SampleCount%count,split=(base+1)*extra;
        uint rank=id.x<split?id.x/(base+1):extra+(id.x-split)/base;
        uint begin=rank*base+min(rank,extra),samples=base+(rank<extra);
        Prepared p=PreparedIn[Selected[rank]];Route r=(Route)0;r.depth=(uint)p.info.x;r.weight=2*p.info.y/samples;
        value=Evaluate(r,id.x-begin,p.first,p.second);
    }
    if(Capture!=0 && id.x<SampleCount){Contributions[id.x]=value;MirrorContributions[id.x]=0;}
    Sum[lane]=value;GroupMemoryBarrierWithGroupSync();
    for(uint stride=32;stride>0;stride>>=1){if(lane<stride)Sum[lane]+=Sum[lane+stride];GroupMemoryBarrierWithGroupSync();}
    if(lane==0)Partials[group.x]=Sum[0];
}
