import json,sys
from pathlib import Path
import numpy as np
import prepare as p
from inputs import extend
names=('1','9','25','barrier','staggered','slit','corridor')
def scene(name):return p.ROOT/(f'.context/spatial-accuracy/planar-{name}/scene.json' if name.isdigit() else f'.context/wave-study/pilot/{name}-1/scene.json')
if sys.argv[1]=='pilot':
 for name in names:
  s=scene(name);length=len(json.loads(s.read_text())['points'])//3
  for n in (65536,262144):
   label=f'pilot-{name}-{n}';p.prepare(label,s,np.linspace(0,length-1,25,dtype=int),count=n);extend(p.OUT/label,((1,16384),(1,4096)))
elif sys.argv[1]=='maps':
 for name in names:
  s=scene(name);length=len(json.loads(s.read_text())['points'])//3
  for n in (65536,262144):
   label=f'map-{name}-{n}';p.prepare(label,s,np.arange(length),count=n);extend(p.OUT/label,((0,65536),(1,65536)))
elif sys.argv[1]=='seeds':
 for name in names:
  s=scene(name);length=len(json.loads(s.read_text())['points'])//3
  for seed in (65554,131091,196628):
   for n in (65536,262144):
    label=f'seed-{name}-{seed}-{n}';p.prepare(label,s,np.linspace(0,length-1,25,dtype=int),count=n,seed=seed);extend(p.OUT/label,((1,65536),))
elif sys.argv[1]=='scaling':
 for side in (1,3,5,10,20,40,50):
  base=json.loads(scene('25').read_text());centers=np.arange(side)*2-(side-1);base['walls']=[dict(base['walls'][0],center=[float(x),float(y),0]) for x in centers for y in centers];span=max(side,4);base['source']=[-span-1.5,-.4,0];base['points']=[v for x,y in ((-span-1,0),(0,.8),(span+.8,.7),(0,-span-.8),(0,span+.8)) for v in (x,y,0)]
  # Keep probes outside all boxes, including the one-box control.
  root=p.OUT/f'scale-scene-{side}';root.mkdir(exist_ok=True);s=root/'scene.json';s.write_text(json.dumps(base,indent=2)+'\n')
  name=f'scale-{side*side}';p.prepare(name,s,np.arange(5));extend(p.OUT/name,((0,65536),(1,65536)))
