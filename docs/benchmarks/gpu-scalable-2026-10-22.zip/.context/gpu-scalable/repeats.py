import json
from pathlib import Path
import numpy as np
OUT=Path(__file__).resolve().parent;rows=[]
for name in ('1','barrier','slit'):
 for n in (65536,262144):
  runs=[]
  for repeat in range(3):
   p=OUT/f'repeat-{name}-{n}-{repeat}';o=np.genfromtxt(p/'generated.csv',delimiter=',',names=True);o=o[o['mode']==2];a=np.genfromtxt(p/'scalable.csv',delimiter=',',names=True);a=a[a['bvh']==1]
   old=o['real']+1j*o['imag']+o['mirror_real']+1j*o['mirror_imag'];new=a['real']+1j*a['imag'];np.testing.assert_allclose(new,old,rtol=.001,atol=1e-5)
   runs.append(dict(oldMedianMs=float(np.median(o['solve_seconds'])*1000),newMedianMs=float(np.median(a['solve_seconds'])*1000),oldTotalMs=float(o['solve_seconds'].sum()*1000),newTotalMs=float(a['solve_seconds'].sum()*1000)))
  row=dict(scene=name,samples=n,receivers=25,runs=runs,oldMedianMs=float(np.median([r['oldMedianMs'] for r in runs])),newMedianMs=float(np.median([r['newMedianMs'] for r in runs])));row['ratio']=row['oldMedianMs']/row['newMedianMs'];rows.append(row);print(name,n,row['oldMedianMs'],row['newMedianMs'],row['ratio'])
(OUT/'repeats.json').write_text(json.dumps(rows,indent=2)+'\n')
