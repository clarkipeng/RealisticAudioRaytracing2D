# Bounded GPU route experiment — 22 October 2026

Based on `5da651f`; no live renderer changes. Extract the archive at the repository root. It restores project-relative `.context/` evidence. Source is in `.context/gpu-scalable`; prior integrator/geometry/harness snapshots are in `source/`. Final composed shader and fixture are `ScalableRoutes.compute` and `ScalableRouteChecks.cs`.

Use the existing isolated `.context/gpu-audio/runner` and `.context/wave-planar/venv` (Python, NumPy, SciPy, matplotlib), and Unity 6000.4.1f1. Installed dependencies, the runner's Library cache and Unity binaries are not bundled. The runner contains the project's normal test dependencies. Never stage into the interactive project. The run script requires the isolated runner to be closed and removes its staged files in `finally`. Unity runs at nice 15, in Metal batch mode, audio disabled, one job worker. Do not add `-nographics`: Metal is required. No speaker/microphone/player-window interaction.

## Reproduce

From this directory, set thread limits before running Python:

```sh
export OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
PYTHON=../wave-planar/venv/bin/python
"$PYTHON" build.py
```

Metadata contains original absolute scene paths. On a different checkout, resolve the suffix beginning `.context/` under the new repository root and update `generation.json` / `scaling.json` paths before analysis. Scene/reference files are included. Regenerate omitted large inputs from the exact existing metadata and configuration, preserving receiver IDs and seeds (the binary hashes in `generation.json` describe the original inputs):

```python
import json
from pathlib import Path
import prepare
from inputs import extend
for p in sorted(Path('.').iterdir()):
    if not p.is_dir() or not (p/'generation.json').exists():
        continue
    if (p/'generated.bin').exists():
        continue  # archived control input
    m = json.loads((p/'generation.json').read_text())
    configurations = [tuple(map(int, x.split(',')))
                      for x in (p/'config.txt').read_text().splitlines()]
    prepare.prepare(p.name, Path(m['scene']), m['indices'], m['samples'],
                    m['depth'], m['seed'], m['scale'])
    extend(p, configurations)
```

Run only one heavy command at a time, using `nice -n 15 "$PYTHON" ...`:

```sh
nice -n 15 "$PYTHON" run.py control-1 control-9 control-25 empty subset no-support map-* seed-* scale-1 scale-9 scale-25 scale-100 --baseline
nice -n 15 "$PYTHON" run.py scale-400 scale-1600 scale-2500
nice -n 15 "$PYTHON" check.py control-1 control-9 control-25 empty subset no-support
nice -n 15 "$PYTHON" analyze.py
nice -n 15 "$PYTHON" run.py repeat-* --baseline
nice -n 15 "$PYTHON" repeats.py
nice -n 15 "$PYTHON" plots.py
```

`plots.py` copies PNGs into the original Conductor `.context/`; change DEST when running elsewhere. Regenerated packing times change, so preserve original `summary.json`, `scaling.json`, raw CSVs and ledger before rerunning. Do not run `document.py` against an already-updated history: it is the one-time report insertion used for this checkpoint.

## Evidence and omissions

Final suites: `gpu-142450.xml` (67 passed), `gpu-142604.xml` (4 passed), `gpu-142653.xml` (19 passed). Matching provenance JSON hashes the exact shader/fixture staged into the runner. `checks.json` records independent CPU checks, `summary.json` the complete maps/scaling, `repeats.json` the small-scene repetitions. `fields-*.npz` contains complex old/new pressure and wave references. CSV times are host-observed dispatch/blocking-readback, not GPU timestamps. Measured map totals include prep/setup; they exclude startup/compile/warmup, references, exports and audio synthesis.

Controls retain exact inputs and final BVH sample captures at their configured budgets. Linear output is checked against the same CSV, so duplicate linear captures are omitted. Old descriptor/capture files are unnecessary for the independent new-code checks and omitted. Large generated.bin/routes.bin/bvh.bin inputs are regenerable and omitted; all raw CSVs/configs/metadata remain. Source snapshots `streaming/` and `compact16k/` preserve the rejected streaming attempt and the earlier smaller-budget experiment with their original raw metadata/results. They are not the final method. `pilot-*` is the earlier 4K/16K investigation. Initial passing suites and the pre-test licensing failure log are retained but not counted as final validation.

Fixed 65K work is not fixed accuracy: 16K candidates failed the 100-box enumeration comparison; 65K passes it. Above 100 boxes there is no independent wave or enumeration accuracy qualification. Per-receiver O(E) visibility preparation, low acceptance at large scales, small-scene overhead, depth-two coverage and the underlying dense-scene model error remain. This is not a qualified DLSS teacher or realtime broadband renderer.
