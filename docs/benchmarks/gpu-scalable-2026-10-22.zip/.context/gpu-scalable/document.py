import json
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];s=json.loads((OUT/'summary.json').read_text());q={(r['scene'],r['samples']):r for r in s['maps']};labels={'1':'1 box','9':'9 boxes','25':'25 boxes','barrier':'Thick wall','staggered':'Staggered walls','slit':'Slit','corridor':'Corridor'}
lines=['# Acoustic experiments: history, 2D maps and GPU scaling','',
'''The latest offline prototype removes the **quadratic edge-pair buffers and unbounded pair enumeration**. It retains the complete-path diffraction integrator, bounds candidate work, and uses a box BVH for visibility. In the 100-box control, median solve/readback falls from **68.04 to 5.80 ms (11.7×)** with effectively identical pressure. The 2,500-box run completes in **15.45 ms per receiver using 10.15 MB of GPU buffers**. The old descriptor allocation alone would need 33.6 GB there; that allocation is calculated, not a successful old run.

This is a scaling improvement for the **offline two-interaction prototype**, not a production renderer change or proof of ray-tracer scaling at fixed accuracy. There is still linear edge-list preparation per receiver. All seven existing wave-reference maps retain their earlier accuracy; the dense-scene physical error remains large. Some small-scene timings regress. Tests ran silently in the isolated Unity Metal batch runner with audio disabled, one worker and reduced priority.

**Bounded path sampling and BVH visibility — 22 October**

![Three larger 2D pressure maps](benchmarks/gpu-scalable-large-2026-10-22.png)

![Four original 2D scenes](benchmarks/gpu-scalable-small-2026-10-22.png)

These are XY maps at 250 Hz of a point source and infinitely extruded rigid boxes, with source/listener z=0. This is a 2.5D benchmark, not finite 3D or cylindrical 2D propagation. Both methods use the same signed integrand, path orders, phase, width 1, seed 17, horizon and height-sample budget. No smoothing, gain fitting or amplitude clipping. The numerical wave references retain their earlier refinement qualifications; they are not exact truth.

| Scene | 65K old → new map time | 262K old → new map time | 262K old → new complex-pressure error |
|---|---:|---:|---:|''']
for name,label in labels.items():
 a,b=q[name,65536],q[name,262144];lines.append(f"| {label} | {a['oldSeconds']:.3f} → {a['newSeconds']:.3f} s | {b['oldSeconds']:.3f} → {b['newSeconds']:.3f} s | {b['old']['errorPercent']:.2f}% → {b['new']['errorPercent']:.2f}% |")
lines.append('''
Across the seven maps (4,842 cells) at both budgets, the largest per-map old/new relative complex-pressure L2 difference is **0.0222%** (25 boxes, 65K). BVH and linear visibility produce **bit-for-bit identical pressure** in every measured comparison. Four seeds on 25 fixed receiver positions per scene are archived; they do not establish high fidelity at larger scales.

These totals include input packing, buffer setup, source/scene preparation, all receiver submissions, GPU dispatches and blocking readbacks. Old and new are freshly measured here: **neither adds archived CPU acoustic-field costs**. New totals also include building the BVH and extra sampling draws. They exclude Unity startup, first compile/warmup, wave solving, capture/CSV export, plotting and audio/DSP. They are component sums and host-observed times, not GPU hardware timestamps. The baseline runs before new variants within each case; new BVH/linear variants rotate order per receiver. One complete map pass is not a statistical performance guarantee.

Full-map timings include small-scene regressions: one box and thick wall at 65K, thick wall and slit at 262K. Three additional 25-probe runs investigated those scenes. Median-of-run median solve times improve by 3–11% in five of six scene/budget combinations, but the 262K slit changes **0.536 → 0.597 ms**, an 11% slowdown by that aggregate. Its individual runs vary substantially (one new run has 1.644 ms median). All raw runs are retained. This does **not** justify a universal “no performance loss” claim or replacing the full-map totals with favorable repeats.

**What changed**

```text
Once per static scene, CPU:
    build a flat box BVH; upload geometry and scrambled sample sequences

For each receiver, GPU:
    mark source-visible / receiver-visible edges and facing faces
    compact into five linear lists
    describe the possible path families by their counts, without a pair table
    if candidate count <= requested path budget S:
        visit every candidate once
    else:
        sample S candidates; retain inverse selection probability
    check the sampled segments through the BVH
    prepare distances and wedge terms for those candidates
    discard candidates that have zero contribution for every height
    distribute N height samples across the remaining candidates
    integrate signed pressure using the existing complete-path height proposal
    add direct and first-order mirror paths
    enumerate second-order mirrors if they fit N; otherwise sample N pairs
    reduce to one complex pressure value and read it back
```

Compaction rejects occluded, degenerate or out-of-horizon paths with zero support. It never discards small or inconvenient pressure values. The code writes the accepted indices into a bounded list.

Four diffraction families remain: one edge, two edges, mirror→edge and edge→mirror. First and second mirror-only paths remain too. At large candidate counts, family selection is proportional to its count, then the two IDs are selected independently. No nearest-edge restriction or shortest-path substitution is introduced.

Let R be the conceptual candidate count and S the selected count. When sampling is needed, each candidate carries **R/S**. Removing zero-support candidates does not renormalize that factor. Each retained candidate gets an average of its height samples, multiplied by its original selection weight and the existing symmetry factor. Candidate draws and height draws are separately scrambled. This preserves the estimator for the covered path model in ideal arithmetic; it does not guarantee low variance, complete physics or exact floating-point probabilities at arbitrary scale. Repeated sampled candidates are retained.

The first implementation integrated a fixed height tile for every candidate, wasting most samples on invalid geometry. It was rejected. The final version validates bounded candidates first and spends the height budget only on supported paths. A 16K path budget preserved the original seven scenes but differed by about **100% relative norm** from the 100-box enumeration estimate. Raising S to 65,536 covers that control's 35–41K candidates and restores agreement. This is an exposed compute/variance budget, not a physical scene cap or a universal optimum.

**Actual scaling**

![Measured runtime and buffer scaling](benchmarks/gpu-scalable-scaling-2026-10-22.png)

| Boxes / corners | Old enumeration ms | Bounded + linear visibility ms | Bounded + BVH ms | New GPU MB | Candidate count range | Accepted sampled paths |
|---|---:|---:|---:|---:|---:|---:|''')
for r in s['scaling']:
 old=f"{r['oldMedianMs']:.2f}" if 'oldMedianMs'in r else 'not run';lines.append(f"| {r['boxes']:,} / {r['edges']:,} | {old} | {r['linearMedianMs']:.2f} | {r['newMedianMs']:.2f} | {r['gpuBytes']/1e6:.2f} | {r['minCandidates']:,.0f}–{r['maxCandidates']:,.0f} | {r['minAccepted']:,}–{r['maxAccepted']:,} |")
lines.append('''
Five probes per layout, 65,536 height samples and up to 65,536 candidate paths. GPU buffer bytes include inputs, BVH, descriptors, counters, scratch, reduction and outputs; they exclude Unity/driver memory. The 100-box allocation falls from **58.29 to 9.73 MB**. At 2,500 boxes, BVH visibility is **2.35× faster** than the new sampler with linear visibility, with bitwise-identical output. The old quadratic implementation was not run above 100 boxes to avoid huge allocations.

Scene extent grows at fixed box density and fixed delay horizon. Visibility, rejection and accepted path counts change, so the runtime curve is not a formal scaling law. BVH/draw input preparation takes approximately 4.7 ms at 100 boxes and 70.5 ms at 2,500 boxes, separate from the per-receiver timings in the table and amortizable over a static scene. The current harness rebuilds it once per case. Static source-visible lists are still recomputed at every receiver.

Only the original seven scenes have wave-reference comparisons. The larger scaling layouts establish finite output, runtime/memory and BVH/linear parity, **not acoustic accuracy**. At 2,500 boxes only 65–510 of 65,536 candidates survive at these five probes. This identifies a remaining sampling-efficiency problem: bounded uniform candidate sampling is scalable in work but can be noisy. The 100-box enumeration result itself is an approximate two-interaction estimate, not independent truth.

Write E for corners/faces, W for boxes, N for height samples, S for candidate budget, M for the second-reflection candidate count, and Q(W) for the actual visibility-query cost:

- Previous geometry preparation: O(E²W) brute-force visibility and O(E²) persistent descriptors.
- New receiver work: **O((E + min(S,R) + min(N,M))·Q(W) + N)** at fixed interaction depth, including a linear number of first reflections and bounded second-reflection samples.
- New persistent storage: **O(W + E + S + N)**. Small scenes allocate only the possible candidate capacity, not the entire requested budget.
- An ideal fixed-N, bounded-depth BVH ray walk is approximately O(N·Q(W)); this prototype still has the extra E term. BVH queries are often efficient but can degrade toward O(W); there is no unconditional logarithmic guarantee.

The serial list/accepted-path compactions are linear in E and bounded S respectively. The prototype does not yet use a parallel prefix scan, source-list reuse, instanced BLAS/TLAS, dynamic BVH refits, or multiple-frequency reuse. Avoid adding those until their cost is measured. The next scaling target is the full per-receiver edge scan and low candidate acceptance; replacing it needs a proposal that retains support and demonstrably reduces variance. Adding samples alone cannot recover unrepresented higher-order paths.

**Verification, code size and checkpoint**

Final suites pass **67 + 4 + 19 Unity test executions**: full maps/additional seeds/controls/small scaling, large scaling, and timing repeats. Each suite also includes the angle control. Independent Python visibility/count/pressure checks cover 22 control positions, including empty scenes, no support, fewer samples than routes, sampled mirror pairs and multiple candidate budgets. Maximum per-case aggregate CPU/GPU discrepancy is **0.00215%**. Existing shader compiler warnings remain; the tests qualify the archived cases, not arbitrary geometry scales. A launch attempt failed during Unity licensing/package-manager initialization before tests ran; its log is retained and excluded from passing results.

The final composed shader is **356 lines versus 385** in the previous prototype; the C# measurement fixture is **74 versus 96**. This is a comparison of those two files only, not a claim that the whole experiment adds no code. The integrand is reused by the build script; plotting, controls and raw evidence stay in the experiment archive. No runtime dependency or live shader variant was added.

The prior implementation is preserved at `5da651f`. This experiment remains offline: rigid extruded rectangles, one frequency and at most two interactions. Arbitrary meshes/materials, higher orders, finite 3D, moving audio, audible artifact behavior and DLSS teacher quality are not validated. The high dense-scene error remains a blocker to calling this a high-fidelity reference.

[Complete numerical ledger](benchmarks/gpu-scalable-2026-10-22.json) · [Source, reproducible inputs, raw results and controls](benchmarks/gpu-scalable-2026-10-22.zip).

---

''')
p=ROOT/'docs/acoustic-experiment-history.md';old=p.read_text();old=old[old.index('**Latest experiment: geometry reuse'):].replace('**Latest experiment: geometry reuse','**Previous experiment: geometry reuse',1).replace('| Latest experiment, 21 Oct |','| `5da651f`, 21 Oct |',1);old=old.replace('| `5da651f`, 21 Oct |', '| Latest experiment, 22 Oct | Bounded candidate paths, GPU compaction and BVH visibility | Removes quadratic descriptors; 100-box control is 11.7× faster. Original maps retain accuracy; large-scene accuracy and small-scene regressions remain unresolved. |\n| `5da651f`, 21 Oct |',1)
chronology=old.splitlines();i=next(i for i,x in enumerate(chronology) if x.startswith('| Latest experiment, 22 Oct'));chronology[i],chronology[i+1]=chronology[i+1],chronology[i];old='\n'.join(chronology)+'\n'
p.write_text('\n'.join(lines)+old)
p=ROOT/'docs/cleanup-results.md';old=p.read_text();title,rest=old.split('\n',1);p.write_text(title+'\n\n## Bounded GPU paths and BVH scaling — 2026-10-22\n\n[Consolidated report, seven 2D maps and scaling plot](acoustic-experiment-history.md). The offline prototype removes quadratic path buffers and bounds candidate work. At 100 boxes, old/new median solve+readback is 68.04 → 5.80 ms with effectively identical pressure; at 2,500 boxes, 15.45 ms and 10.15 MB of GPU buffers. Full-map old/new pressure differs by at most 0.0222%; BVH/linear output is bitwise equal. Large-scene wave accuracy is unqualified, an O(E) per-receiver scan remains, and small-scene timing regressions are reported. Final suites: 67 + 4 + 19 test executions; independent CPU controls pass. No runtime changes. [Source/data archive](benchmarks/gpu-scalable-2026-10-22.zip).\n'+rest)
