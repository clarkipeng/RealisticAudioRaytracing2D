// Complete one/two-interaction samples without edge-pair tables.
struct Node {float4 bounds;uint4 links;}; // preorder; links.x=escape, links.y=box+1 or zero
StructuredBuffer<Node> Nodes;
StructuredBuffer<float3> RouteDraws;
RWStructuredBuffer<uint> Flags, ListsOut, CountsOut;
StructuredBuffer<uint> Lists, Counts;
uint NodeCount, UseBvh, PathBudget;
RWStructuredBuffer<uint> DispatchArgs;

bool Overlaps(float4 box,float2 a,float2 b,bool open)
{
    float lo=0,hi=1;
    for(uint axis=0;axis<2;axis++)
    {
        float d=b[axis]-a[axis];
        if(d==0){if(open?(a[axis]<=box[axis] || a[axis]>=box[axis+2]):(a[axis]<box[axis] || a[axis]>box[axis+2]))return false;}
        else {float x=(box[axis]-a[axis])/d,y=(box[axis+2]-a[axis])/d;lo=max(lo,min(x,y));hi=min(hi,max(x,y));}
    }
    return open?lo<hi-4*1.192092896e-7:lo<=hi;
}
bool Visible(float2 a,float2 b)
{
    if(UseBvh==0){for(uint i=0;i<BoxCount;i++)if(Overlaps(Boxes[i],a,b,true))return false;return true;}
    uint index=0;
    while(index<NodeCount)
    {
        Node node=Nodes[index];
        if(node.links.y!=0){if(Overlaps(Boxes[node.links.y-1],a,b,true))return false;index++;}
        else index=Overlaps(node.bounds,a,b,false)?index+1:node.links.x;
    }
    return true;
}
