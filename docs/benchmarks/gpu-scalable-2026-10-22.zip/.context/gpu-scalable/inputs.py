import json,struct,time
from pathlib import Path
import numpy as np
from scipy.stats import qmc
OUT=Path(__file__).resolve().parent

def extend(directory,configs=((0,65536),(1,65536))):
 directory=Path(directory);m=json.loads((directory/'generation.json').read_text());start=time.perf_counter();raw=(directory/'generated.bin').read_bytes();_,n,_,_,w,_=struct.unpack_from('<6I',raw);boxes=np.frombuffer(raw,'<f4',offset=44,count=4*w).reshape(w,4);records=[]
 def build(ids):
  index=len(records);records.append(None);bounds=np.r_[boxes[ids,:2].min(axis=0),boxes[ids,2:].max(axis=0)].astype('<f4');bounds[:2]=np.nextafter(bounds[:2],np.float32(-np.inf));bounds[2:]=np.nextafter(bounds[2:],np.float32(np.inf))
  if len(ids)>1:
   center=(boxes[ids,:2]+boxes[ids,2:])/2;axis=np.argmax(np.ptp(center,axis=0));order=ids[np.argsort(center[:,axis],kind='stable')];mid=len(ids)//2;build(order[:mid]);build(order[mid:]);leaf=0
  else:leaf=int(ids[0])+1
  records[index]=bounds.tobytes()+struct.pack('<4I',len(records),leaf,0,0)
 if w:build(np.arange(w))
 (directory/'bvh.bin').write_bytes(b''.join(records))
 edgeCount=4*w;capacity=max(1,min(max(min(s,n) for _,s in configs),2*edgeCount*edgeCount+edgeCount));routeCount=max(capacity,n if (edgeCount//2)**2>n else 0)
 draws=qmc.Sobol(3,scramble=True,bits=30,seed=m['seed']^0x53A91).random_base2((routeCount-1).bit_length())[:routeCount]+.5/2**30
 draws=np.clip(draws.astype('<f4'),np.nextafter(np.float32(0),np.float32(1)),np.nextafter(np.float32(1),np.float32(0)))
 (directory/'routes.bin').write_bytes(draws.tobytes());(directory/'config.txt').write_text(''.join(f'{b},{min(h,n)}\n' for b,h in configs));m['extensionSeconds']=time.perf_counter()-start;m['nodes']=len(records);m['routeDraws']=routeCount;m['allocatedPaths']=capacity;(directory/'scaling.json').write_text(json.dumps(m,indent=2)+'\n')
