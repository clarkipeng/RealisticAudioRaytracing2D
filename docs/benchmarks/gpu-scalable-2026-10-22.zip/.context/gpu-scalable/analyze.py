import json,sys
from pathlib import Path
import numpy as np
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1]
names=('1','9','25','barrier','staggered','slit','corridor');maps=[];seeds=[];scaling=[]
def read(p):
 d=np.genfromtxt(p/'scalable.csv',delimiter=',',names=True,ndmin=1);a=d[(d['bvh']==1)&(d['paths']==65536)]
 b=d[(d['bvh']==0)&(d['paths']==65536)]
 if len(b):np.testing.assert_array_equal(a['point'],b['point']);np.testing.assert_array_equal(a['real'],b['real']);np.testing.assert_array_equal(a['imag'],b['imag'])
 return a,b

def field(a):return a['real']+1j*a['imag']
def oldread(p):
 a=np.genfromtxt(p/'generated.csv',delimiter=',',names=True,ndmin=1);a=a[a['mode']==2];return a,field(a)+a['mirror_real']+1j*a['mirror_imag']
def metrics(x,r):
 level=20*np.log10(np.maximum(abs(x),1e-12)/np.maximum(abs(r),1e-12))
 return dict(errorPercent=float(100*np.linalg.norm(x-r)/np.linalg.norm(r)),within3dBPercent=float(100*np.mean(abs(level)<=3)))
def cost(a,m,new):return float(np.sum(a['solve_seconds']+a['input_seconds'])+a['setup_seconds'][0]+m['preparationSeconds']+(m['extensionSeconds'] if new else a['graph_seconds'][0]))
for name in names:
 fields={}
 for n in (65536,262144):
  p=OUT/f'map-{name}-{n}';m=json.loads((p/'scaling.json').read_text());c=json.loads(Path(m['scene']).read_text());ref=np.load(Path(m['scene']).parent/('reference-0.35-250.npz' if name.isdigit() else 'reference-0.25-250.npz'))['pressure'];a,b=read(p);o,old=oldread(p);new=field(a)
  assert len(a)==len(ref)==len(o);assert np.isfinite(new).all();parity=float(np.linalg.norm(old-new)/np.linalg.norm(old));np.testing.assert_allclose(new,old,rtol=.02,atol=3e-4);assert parity<.002
  row=dict(scene=name,samples=n,pathBudget=65536,receivers=len(a),old=metrics(old,ref),new=metrics(new,ref),oldSeconds=cost(o,m,False),linearSeconds=cost(b,m,True),newSeconds=cost(a,m,True),oldMedianMs=float(1000*np.median(o['solve_seconds'])),newMedianMs=float(1000*np.median(a['solve_seconds'])),linearMedianMs=float(1000*np.median(b['solve_seconds'])),oldGpuBytes=int(o['gpu_bytes'][0]),newGpuBytes=int(a['gpu_bytes'][0]),pressureRelativeDifference=parity,bvhBitwiseParity=True,maxCandidates=float(np.max(a['candidates'])),maxAccepted=int(np.max(a['accepted'])),preparationSeconds=m['preparationSeconds'],bvhAndRouteDrawPreparationSeconds=m['extensionSeconds'],oldSetupSeconds=float(o['setup_seconds'][0]),newSetupSeconds=float(a['setup_seconds'][0]))
  row['timeRatio']=row['oldSeconds']/row['newSeconds'];maps.append(row);fields[f'old{n}']=old;fields[f'new{n}']=new
  print(name,n,'error',row['old']['errorPercent'],row['new']['errorPercent'],'seconds',row['oldSeconds'],row['newSeconds'],'ratio',row['timeRatio'],'parity',parity,flush=True)
 np.savez_compressed(OUT/f'fields-{name}.npz',**fields,reference=ref,points=np.array(c['points']).reshape(-1,3))
 ids=np.linspace(0,len(ref)-1,25,dtype=int)
 for n in (65536,262144):
  new=[fields[f'new{n}'][ids]];old=[fields[f'old{n}'][ids]]
  for seed in (65554,131091,196628):
   p=OUT/f'seed-{name}-{seed}-{n}';a,_=read(p);o,v=oldread(p);new.append(field(a));old.append(v)
  row=dict(scene=name,samples=n,receivers=25,seeds=[17,65554,131091,196628]);
  for label,v in (('old',np.array(old)),('new',np.array(new))):
   errors=[metrics(x,ref[ids])['errorPercent'] for x in v];noise=float(100*np.sqrt(np.mean(abs(v-v.mean(axis=0))**2))/np.sqrt(np.mean(abs(ref[ids])**2)));row[label]=dict(errors=errors,meanErrorPercent=float(np.mean(errors)),repeatVariationPercent=noise)
  seeds.append(row)
for boxes in (1,9,25,100,400,1600,2500):
 p=OUT/f'scale-{boxes}';a,b=read(p);m=json.loads((p/'scaling.json').read_text());row=dict(boxes=boxes,edges=4*boxes,samples=m['samples'],pathBudget=65536,receivers=len(a),newMedianMs=float(1000*np.median(a['solve_seconds'])),newMinMs=float(1000*np.min(a['solve_seconds'])),newMaxMs=float(1000*np.max(a['solve_seconds'])),linearMedianMs=float(1000*np.median(b['solve_seconds'])),gpuBytes=int(a['gpu_bytes'][0]),totalSeconds=cost(a,m,True),bvhAndDrawPreparationSeconds=m['extensionSeconds'],bvhBitwiseParity=True,minCandidates=float(np.min(a['candidates'])),maxCandidates=float(np.max(a['candidates'])),minAccepted=int(np.min(a['accepted'])),maxAccepted=int(np.max(a['accepted'])))
 if (p/'generated.csv').exists():
  o,old=oldread(p);row.update(oldMedianMs=float(1000*np.median(o['solve_seconds'])),oldGpuBytes=int(o['gpu_bytes'][0]),relativeDifferenceToEnumeration=float(np.linalg.norm(field(a)-old)/np.linalg.norm(old)))
 scaling.append(row);print('scaling',row,flush=True)
(OUT/'summary.json').write_text(json.dumps(dict(maps=maps,seeds=seeds,scaling=scaling),indent=2)+'\n')
