import json,shutil
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];DOC=ROOT/'docs/benchmarks';DEST=Path('/Users/clarkpeng/conductor/workspaces/realisticaudioraytracing2d/tyler/.context')
s=json.loads((OUT/'summary.json').read_text());rows={(r['scene'],r['samples']):r for r in s['maps']};plt.rcParams.update({'font.size':10,'figure.facecolor':'white','savefig.facecolor':'white'})
cmap=plt.colormaps['magma'].with_extremes(over='#27c9bd',under='#050505',bad='#e5e7eb')
def save(fig,label):
 name=f'gpu-scalable-{label}-2026-10-22.png';fig.savefig(DOC/name,dpi=145);plt.close(fig);shutil.copy2(DOC/name,DEST/name)
for small,names in ((False,('1','9','25')),(True,('barrier','staggered','slit','corridor'))):
 fig,axes=plt.subplots(len(names),3,figsize=(12,10.6 if not small else 12),layout='constrained')
 for row,name in enumerate(names):
  m=json.loads((OUT/f'map-{name}-262144/generation.json').read_text());c=json.loads(Path(m['scene']).read_text());f=np.load(OUT/f'fields-{name}.npz');p=f['points'];q=rows[name,262144]
  label=(name+' '+('box' if name=='1' else 'boxes')) if not small else {'barrier':'Thick wall','staggered':'Staggered walls','slit':'Slit','corridor':'Corridor'}[name]
  for col,key in enumerate(('reference','old262144','new262144')):
   ax=axes[row,col];x,y=np.unique(p[:,0]),np.unique(p[:,1]);g=np.full((len(y),len(x)),np.nan);g[np.searchsorted(y,p[:,1]),np.searchsorted(x,p[:,0])]=20*np.log10(np.maximum(abs(f[key]),1e-12));im=ax.pcolormesh(x,y,g,cmap=cmap,vmin=-40,vmax=5,shading='nearest')
   for w in c['walls']:
    center,half=np.array(w['center'][:2]),np.array(w['half'][:2]);ax.add_patch(Rectangle(center-half,*(2*half),facecolor='#515962',edgecolor='white',lw=.6))
   ax.scatter(*c['source'][:2],marker='*',s=75,color='#00a8ff',edgecolor='black',linewidth=.5,zorder=5)
   title=label+' · wave reference' if col==0 else ('Pair enumeration' if col==1 else 'Bounded paths + BVH')+f" · {q['oldSeconds' if col==1 else 'newSeconds']:.2f} s/map"
   ax.set(xlabel='x (m)',ylabel='y (m)',title=title,xlim=(-3.4,3.55) if small else (-6.9,6.25),ylim=(-2.75,2.75) if small else (-5.7,5.7));ax.set_aspect('equal')
   if col:
    v=q['old' if col==1 else 'new'];ax.text(.02,.025,f"{v['errorPercent']:.1f}% error · {v['within3dBPercent']:.0f}% within ±3 dB",transform=ax.transAxes,fontsize=8,bbox=dict(facecolor='white',alpha=.94,edgecolor='none',pad=3))
 fig.colorbar(im,ax=list(axes.flat),shrink=.7,pad=.015,extend='both',label='Pressure level (dB re unit pressure)')
 fig.suptitle('2D sound maps · same integrator, bounded route work · 250 Hz',fontsize=16)
 fig.supxlabel('262,144 height samples, up to 65,536 candidate paths, seed 17, two interactions. Same absolute colours; no smoothing or gain matching.\nError = complex-pressure L2 versus numerical wave reference. Times include setup and solve/readback, excluding reference and audio synthesis.\nThese are XY slices of infinitely extruded rigid boxes (point-source 2.5D). The remaining dense-scene error is not fixed by this optimization.',fontsize=9)
 save(fig,'small' if small else 'large')
a=s['scaling'];x=np.array([r['boxes'] for r in a]);b=[r for r in a if 'oldMedianMs' in r];fig,axes=plt.subplots(1,2,figsize=(12,5.5),layout='constrained')
ax=axes[0];ax.loglog([r['boxes'] for r in b],[r['oldMedianMs'] for r in b],'o-',label='Old pair enumeration');ax.loglog(x,[r['linearMedianMs'] for r in a],'o-',label='Bounded paths, linear visibility');ax.loglog(x,[r['newMedianMs'] for r in a],'o-',label='Bounded paths + BVH');ax.set(xlabel='Rigid boxes (4 diffraction corners each)',ylabel='Median solve + readback (ms / receiver)',title='Measured cost · 65,536 height samples');ax.legend(fontsize=9);ax.grid(alpha=.2,which='both')
ax=axes[1];ax.loglog(x,[r['gpuBytes']/1e6 for r in a],'o-',label='New: measured allocated buffers');ax.loglog([r['boxes'] for r in b],[r['oldGpuBytes']/1e6 for r in b],'o-',label='Old: measured allocated buffers');ax.loglog(x,3*(4*x)**2*112/1e6,'--',label='Old descriptors only: calculated 3E² × 112 B');ax.set(xlabel='Rigid boxes',ylabel='GPU buffer allocation (MB, decimal)',title='No quadratic pair storage');ax.legend(fontsize=8);ax.grid(alpha=.2,which='both')
fig.suptitle('Scaling through 2,500 boxes / 10,000 corners',fontsize=16);fig.supxlabel('Five probes per layout; scene extent grows at fixed density and delay horizon. Host timing, one paired pass; not a formal scaling law.\nAll methods cover at most two interactions. Larger layouts have no wave-reference qualification; a fixed sample budget does not guarantee fixed error.',fontsize=9);save(fig,'scaling')
print('Saved three comparison figures')
