import hashlib,json,os,shutil,subprocess,sys,time,uuid
from pathlib import Path
import xml.etree.ElementTree as ET
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];runner=ROOT/'.context/gpu-audio/runner';assert not (runner/'Temp/UnityLockfile').exists()
cases=[str((OUT/n).resolve()) for n in sys.argv[1:] if n!='--baseline'];baseline='--baseline' in sys.argv
names=['RouteIntegration.compute','RouteIntegrationChecks.cs']+['RouteGeneration.compute','RouteGenerationChecks.cs']
files={OUT/'source'/n:runner/'Assets/Tests/Editor'/n for n in names}
for name in ('ScalableRoutes.compute','ScalableRouteChecks.cs'):files[OUT/name]=runner/'Assets/Tests/Editor'/name
for p,d in list(files.items()):
 meta=p.with_name(p.name+'.meta')
 if not meta.exists():meta.write_text('fileFormatVersion: 2\nguid: '+uuid.uuid4().hex+'\n')
 files[meta]=d.with_name(d.name+'.meta')
assert all(not p.exists() for p in files.values());stamp=time.strftime('%H%M%S');casefile=OUT/f'cases-{stamp}.txt';casefile.write_text('\n'.join(cases)+'\n')
(OUT/f'provenance-{stamp}.json').write_text(json.dumps(dict(files={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},cases=cases,baseline=baseline),indent=2))
for source,dest in files.items():shutil.copy2(source,dest)
try:
 cmd=['nice','-n','15','/Applications/Unity/Hub/Editor/6000.4.1f1/Unity.app/Contents/MacOS/Unity','-batchmode','-force-metal','-disable-audio','-job-worker-count','1','-projectPath',str(runner),'-runTests','-testPlatform','EditMode','-testFilter','TakeChecks.MeasureScalableRoutes;TakeChecks.RouteAnglesMatchReference','-testResults',str(OUT/f'gpu-{stamp}.xml'),'-logFile',str(OUT/f'gpu-{stamp}.log')]
 result=subprocess.run(cmd,env=dict(os.environ,ACOUSTIC_PAIRED_BASELINE=str(int(baseline)),ACOUSTIC_SCALABLE_CASES=str(casefile),ACOUSTIC_GENERATION_CASES=str(casefile)),timeout=1200)
 test=ET.parse(OUT/f'gpu-{stamp}.xml').getroot();print(test.attrib,flush=True)
 assert result.returncode==0 and test.get('result')=='Passed' and int(test.get('passed'))==len(cases)+1
finally:
 for p in files.values():p.unlink(missing_ok=True)
