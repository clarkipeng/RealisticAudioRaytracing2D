# Repeat small-scene timings because the single full-map pass contains host outliers.
import json
import numpy as np
import prepare as p
from inputs import extend
for repeat in range(3):
 for name in ('1','barrier','slit'):
  for n in (65536,262144):
   m=json.loads((p.OUT/f'map-{name}-{n}/generation.json').read_text());label=f'repeat-{name}-{n}-{repeat}'
   p.prepare(label,p.Path(m['scene']),np.linspace(0,len(m['indices'])-1,25,dtype=int),count=n);extend(p.OUT/label,((0,65536),(1,65536)))
