from pathlib import Path
OUT=Path(__file__).resolve().parent
old=(OUT/'source/RouteGeneration.compute').read_text();base=(OUT/'source/RouteIntegration.compute').read_text()
prefix=base[base.index('// Offline port'):base.index('uint Terms(Step s)')]
prefix=prefix.replace('StructuredBuffer<Route> Routes;\nStructuredBuffer<Step> Steps;\n','').replace('Partials, Result, Contributions','Partials, Result, Contributions, MirrorContributions')
geometry='StructuredBuffer<float4> Boxes;\nuint EdgeCount,BoxCount;float2 Source,Receiver;\n'+old[old.index('float2 Corner('):old.index('bool Visible(')]
geometry+= (OUT/'topology.hlsl').read_text()+'\n'+old[old.index('float Angle('):old.index('struct Prepared')]
geometry+=old[old.index('uint PlaneAxis('):old.index('[numthreads(64,1,1)]\nvoid PrepareMixed')]
start=base.index('uint Terms(Step s)');sample=base[start:base.index('[numthreads(64,1,1)]\nvoid Integrate')]
a=sample.index('float2 Sample(uint index)');b=sample.index('    float previous = 0, before',a)
sample=sample[:a]+'float2 Evaluate(Route route,uint draw,Step first,Step second)\n{\n'+sample[b:]
sample=sample.replace('Step s = Steps[route.first+i];','Step s=first;if(i>0)s=second;')
reduce=base[base.index('[numthreads(64,1,1)]\nvoid Reduce'):]
kernels='BuildFlags Compact IntegratePaths Mirrors Reduce CheckAngles'.split()
(OUT/'ScalableRoutes.compute').write_text('\n'.join('#pragma kernel '+k for k in kernels)+'\n'+prefix+geometry+sample+(OUT/'sample.hlsl').read_text()+reduce)
