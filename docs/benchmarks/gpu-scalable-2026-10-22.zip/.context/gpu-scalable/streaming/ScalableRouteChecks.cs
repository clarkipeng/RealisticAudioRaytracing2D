using System;
using System.Collections.Generic;
using System.IO;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
public partial class TakeChecks
{
    public static IEnumerable<string> ScalableCases()=>File.ReadAllLines(Environment.GetEnvironmentVariable("ACOUSTIC_SCALABLE_CASES"));
    [TestCaseSource(nameof(ScalableCases)),Category("QualityMeasurement")]
    public void MeasureScalableRoutes(string directory)
    {
        Assert.That(Application.isBatchMode,Is.True);RequireGpu();long setup=System.Diagnostics.Stopwatch.GetTimestamp();
        using var input=new BinaryReader(File.OpenRead(Path.Combine(directory,"generated.bin")));
        Assert.That(input.ReadUInt32(),Is.EqualTo(0x52474731));int samples=input.ReadInt32(),depth=input.ReadInt32(),probes=input.ReadInt32(),boxes=input.ReadInt32(),capture=input.ReadInt32();
        Assert.That(depth,Is.EqualTo(2));Assert.That(samples>0&&(samples&(samples-1))==0,Is.True);
        int edges=checked(boxes*4),groups=(samples+63)/64;float wave=input.ReadSingle(),horizon=input.ReadSingle(),scale=input.ReadSingle();
        var source=new Vector4(input.ReadSingle(),input.ReadSingle(),0,0);
        var shader=UnityEngine.Object.Instantiate(AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/Tests/Editor/ScalableRoutes.compute"));
        try
        {
            int flagKernel=shader.FindKernel("BuildFlags"),compact=shader.FindKernel("Compact"),integrate=shader.FindKernel("IntegratePaths"),mirrors=shader.FindKernel("Mirrors"),reduce=shader.FindKernel("Reduce");
            using var geometry=new ComputeBuffer(Math.Max(1,boxes),16);using var flags=new ComputeBuffer(Math.Max(1,edges),4);using var lists=new ComputeBuffer(Math.Max(1,5*edges),4);using var counts=new ComputeBuffer(5,4);
            using var draw=new ComputeBuffer(samples*5,4);using var routeDraw=new ComputeBuffer(samples,12);
            using var partial=new ComputeBuffer(groups,8);using var result=new ComputeBuffer(1,8);using var invalid=new ComputeBuffer(1,4);
            using var contributions=new ComputeBuffer(capture!=0?samples:1,8);using var mirrorContributions=new ComputeBuffer(capture!=0?samples:1,8);
            using var treeInput=new BinaryReader(File.OpenRead(Path.Combine(directory,"bvh.bin")));int nodeCount=checked((int)(treeInput.BaseStream.Length/32));
            using var nodes=new ComputeBuffer(Math.Max(1,nodeCount),32);
            if(boxes>0)geometry.SetData(RouteRead<Vector4>(input,boxes));draw.SetData(RouteRead<float>(input,samples*5));
            var receivers=RouteRead<Vector2>(input,probes);Assert.That(input.BaseStream.Position,Is.EqualTo(input.BaseStream.Length));
            if(nodeCount>0)nodes.SetData(RouteRead<uint>(treeInput,nodeCount*8));
            using(var random=new BinaryReader(File.OpenRead(Path.Combine(directory,"routes.bin"))))routeDraw.SetData(RouteRead<Vector3>(random,samples));
            shader.SetInt("BoxCount",boxes);shader.SetInt("EdgeCount",edges);shader.SetInt("NodeCount",nodeCount);shader.SetInt("SampleCount",samples);shader.SetInt("Dimensions",5);shader.SetInt("GroupCount",groups);shader.SetInt("Capture",capture);
            shader.SetFloat("WaveNumber",wave);shader.SetFloat("Horizon",horizon);shader.SetFloat("ProposalScale",scale);shader.SetVector("Source",source);
            foreach(int kernel in new[]{flagKernel,integrate,mirrors}){shader.SetBuffer(kernel,"Boxes",geometry);shader.SetBuffer(kernel,"Nodes",nodes);}
            foreach(int kernel in new[]{flagKernel,compact})shader.SetBuffer(kernel,"Flags",flags);
            shader.SetBuffer(compact,"ListsOut",lists);shader.SetBuffer(compact,"CountsOut",counts);
            foreach(int kernel in new[]{integrate,mirrors}){shader.SetBuffer(kernel,"Lists",lists);shader.SetBuffer(kernel,"Counts",counts);shader.SetBuffer(kernel,"RouteDraws",routeDraw);shader.SetBuffer(kernel,"Partials",partial);}
            shader.SetBuffer(integrate,"Draws",draw);shader.SetBuffer(integrate,"Invalid",invalid);shader.SetBuffer(integrate,"Contributions",contributions);
            shader.SetBuffer(mirrors,"MirrorContributions",mirrorContributions);shader.SetBuffer(reduce,"Partials",partial);shader.SetBuffer(reduce,"Result",result);
            double setupSeconds=TakeRender.Elapsed(setup);long bytes=(long)geometry.count*16+(long)(flags.count+lists.count+counts.count+draw.count+invalid.count)*4+(long)routeDraw.count*12+(long)nodes.count*32+(long)(partial.count+result.count+contributions.count+mirrorContributions.count)*8;
            var status=new uint[1];var value=new Vector2[1];
            void Solve()
            {
                status[0]=0;invalid.SetData(status);if(edges>0)shader.Dispatch(flagKernel,(edges+63)/64,1,1);shader.Dispatch(compact,1,1,1);
                shader.Dispatch(integrate,groups,1,1);shader.Dispatch(mirrors,groups,1,1);shader.Dispatch(reduce,1,1,1);result.GetData(value);invalid.GetData(status);
                Assert.That(status[0],Is.Zero);Assert.That(float.IsFinite(value[0].x)&&float.IsFinite(value[0].y),Is.True);
            }
            string[] configurations=File.ReadAllLines(Path.Combine(directory,"config.txt"));
            using var csv=new StreamWriter(Path.Combine(directory,"scalable.csv"));csv.WriteLine("point,bvh,batch,real,imag,solve_seconds,input_seconds,setup_seconds,gpu_bytes,cold_seconds");
            for(int p=0;p<probes;p++)for(int rotation=0;rotation<configurations.Length;rotation++)
            {
                string[] config=configurations[(p+rotation)%configurations.Length].Split(',');int bvh=int.Parse(config[0]),batch=int.Parse(config[1]);
                Assert.That(batch,Is.InRange(1,Math.Min(samples,64)));Assert.That((batch&(batch-1)),Is.Zero);
                long clock=System.Diagnostics.Stopwatch.GetTimestamp();shader.SetVector("Receiver",new Vector4(receivers[p].x,receivers[p].y,0,0));shader.SetInt("UseBvh",bvh);shader.SetInt("HeightBatch",batch);double inputSeconds=TakeRender.Elapsed(clock),cold=0;
                if(p==0){clock=System.Diagnostics.Stopwatch.GetTimestamp();Solve();cold=TakeRender.Elapsed(clock);}clock=System.Diagnostics.Stopwatch.GetTimestamp();Solve();double seconds=TakeRender.Elapsed(clock);
                csv.WriteLine(FormattableString.Invariant($"{p},{bvh},{batch},{value[0].x:R},{value[0].y:R},{seconds:R},{inputSeconds:R},{setupSeconds:R},{bytes},{cold:R}"));
                if(capture!=0)
                {
                    void Dump(ComputeBuffer buffer,string name){using var file=new BinaryWriter(File.Create(Path.Combine(directory,$"{name}-{p}-{bvh}-{batch}.bin")));var v=new Vector2[samples];buffer.GetData(v);foreach(var z in v){file.Write(z.x);file.Write(z.y);}}
                    Dump(contributions,"edge");Dump(mirrorContributions,"mirror");
                    var c=new uint[5];counts.GetData(c);File.WriteAllText(Path.Combine(directory,$"counts-{p}-{bvh}-{batch}.txt"),string.Join(",",c));
                }
            }
        }
        finally{UnityEngine.Object.DestroyImmediate(shader);}
    }
}
