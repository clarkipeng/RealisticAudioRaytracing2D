import json,sys,itertools
from pathlib import Path
import numpy as np
OUT=Path(__file__).resolve().parent;sys.path.insert(0,str(OUT/'source'));import edge_integral as edge
reports=[]
for name in sys.argv[1:]:
 p=OUT/name;m=json.loads((p/'generation.json').read_text());c=json.loads(Path(m['scene']).read_text());n=m['samples'];walls=c['walls'];edges=edge.corners(walls);planes=edge.surfaces(walls);E=len(edges);source=np.array(c['source']);points=np.array(c['points']).reshape(-1,3)[m['indices']]
 data=np.genfromtxt(p/'scalable.csv',delimiter=',',names=True,ndmin=1);draw=np.frombuffer((p/'generated.bin').read_bytes(),'<f4',offset=44+16*len(walls),count=n*5).reshape(n,5);routeDraw=np.fromfile(p/'routes.bin','<f4').reshape(n,3)
 k=2*np.pi*250/c['speedOfSound'];h=c['speedOfSound']*c['maximumDelaySeconds'];diff=[];expectedAll=[];actualAll=[]
 for row in data:
  pi,bvh,batch=map(int,(row['point'],row['bvh'],row['batch']));point=points[pi]
  if bvh==0:
   other=data[(data['point']==pi)&(data['bvh']==1)&(data['batch']==batch)];assert len(other)==1
   np.testing.assert_array_equal([row['real'],row['imag']],[other[0]['real'],other[0]['imag']]);continue
  starts=[i for i,e in enumerate(edges) if edge.visible(source,e[0],walls)];ends=[i for i,e in enumerate(edges) if edge.visible(e[0],point,walls)]
  def faces(p):
   result=[]
   for i,(a,b) in enumerate(planes):
    d=b-a;normal=np.array([d[1],-d[0]])/np.linalg.norm(d)
    if np.dot(p[:2]-a,normal)>0:result.append(i)
   return result
  sf,ef=faces(source),faces(point);one=sorted(set(starts)&set(ends));lists=[starts,ends,sf,ef,one];counts=[len(x) for x in lists]
  actualCounts=np.loadtxt(p/f'counts-{pi}-{bvh}-{batch}.txt',delimiter=',',dtype=int);np.testing.assert_array_equal(actualCounts,counts)
  sizes=np.array([len(one),len(starts)*len(ends),len(sf)*len(ends),len(starts)*len(ef)]);R=int(sizes.sum());tiles=n//batch;selected={}
  if R and R<=tiles:
   for rank in range(R):
    family=int(np.searchsorted(np.cumsum(sizes),rank,side='right'));r=rank-sizes[:family].sum();cols=len(ends) if family in (1,2) else (len(ef) if family==3 else 1);a,b=divmod(int(r),cols);samples=(tiles//R+(rank<tiles%R))*batch;selected[family,a,b]=np.arange(samples)
  elif R:
   for tile in range(tiles):
    u=routeDraw[tile];family=int(np.searchsorted(np.cumsum(sizes),np.float32(u[0]*R),side='right'));rows=len(one) if family==0 else (len(sf) if family==2 else len(starts));cols=len(ends) if family in (1,2) else (len(ef) if family==3 else 1)
    a=min(rows-1,int(np.float32(u[1]*rows)));b=min(cols-1,int(np.float32(u[2]*cols)));selected.setdefault((family,a,b),[]).extend(range(tile*batch,(tile+1)*batch))
  expected=0j
  for (family,a,b),ids in selected.items():
   src=source.copy();end=point.copy()
   if family==0:chain=[edges[one[a]]]
   elif family==1:
    a,b=starts[a],ends[b]
    if a==b or not edge.visible(edges[a][0],edges[b][0],walls):continue
    chain=[edges[a],edges[b]]
   else:
    e=edges[ends[b] if family==2 else starts[a]];plane=sf[a] if family==2 else ef[b]
    path=edge.mirror_path(src,e[0],[planes[plane]],walls) if family==2 else edge.mirror_path(e[0],end,[planes[plane]],walls)
    if path is None:continue
    p0,p1=planes[plane];normal=np.array([-(p1-p0)[1],(p1-p0)[0]])/np.linalg.norm(p1-p0)
    if family==2:src[:2]-=2*normal*np.dot(src[:2]-p0,normal)
    else:end[:2]-=2*normal*np.dot(end[:2]-p0,normal)
    chain=[e]
   value=edge.sample_chain(chain,src,end,k,h,draw[ids],proposal_scale=m['scale']);expected+=value*(len(ids)*R/n if R>tiles else 1)
  edgeParts=np.fromfile(p/f'edge-{pi}-{bvh}-{batch}.bin','<f4').reshape(n,2);measured=np.sum(edgeParts[:,0].astype(float)+1j*edgeParts[:,1]);np.testing.assert_allclose(measured,expected,rtol=.005,atol=3e-5)
  mirror=0j
  def pressure(path):return np.exp(-1j*k*path[1])/path[1] if path is not None and 0<path[1]<h else 0j
  mirror+=pressure(edge.mirror_path(source,point,[],walls))
  for a in sf:mirror+=pressure(edge.mirror_path(source,point,[planes[a]],walls))
  M=len(sf)*len(ef)
  if M<=n:
   for a,b in itertools.product(sf,ef):
    if a!=b:mirror+=pressure(edge.mirror_path(source,point,[planes[a],planes[b]],walls))
  else:
   for u in routeDraw:
    a=sf[min(len(sf)-1,int(np.float32(u[1]*len(sf))))];b=ef[min(len(ef)-1,int(np.float32(u[2]*len(ef))))]
    if a!=b:mirror+=M/n*pressure(edge.mirror_path(source,point,[planes[a],planes[b]],walls))
  mirrorParts=np.fromfile(p/f'mirror-{pi}-{bvh}-{batch}.bin','<f4').reshape(n,2);mirrorActual=np.sum(mirrorParts[:,0].astype(float)+1j*mirrorParts[:,1]);np.testing.assert_allclose(mirrorActual,mirror,rtol=.001,atol=3e-5)
  actual=row['real']+1j*row['imag'];np.testing.assert_allclose(actual,measured+mirrorActual,rtol=3e-6,atol=1e-6);np.testing.assert_allclose(actual,expected+mirror,rtol=.005,atol=3e-5)
  expectedAll.append(expected+mirror);actualAll.append(actual);print(name,pi,batch,'candidate paths',R,'relative difference',abs(actual-expected-mirror)/max(abs(expected+mirror),1e-30),flush=True)
 relative=float(np.linalg.norm(np.array(expectedAll)-actualAll)/max(np.linalg.norm(expectedAll),1e-30));assert relative<.001
 reports.append(dict(case=name,cpuRelativeDifference=relative,bvhLinearParity=True,countsParity=True))
(OUT/'checks.json').write_text(json.dumps(reports,indent=2)+'\n')
