bool Faces(uint plane,float2 p)
{
    uint side=plane%4;float d=p[PlaneAxis(plane)]-PlanePosition(plane);
    return (side==0 || side==3)?d<0:d>0;
}
[numthreads(64,1,1)]
void BuildFlags(uint id:SV_DispatchThreadID)
{
    if(id>=EdgeCount)return;
    uint a=Visible(Source,Corner(id))?1:0,b=Visible(Corner(id),Receiver)?1:0;
    Flags[id]=a|(b<<1)|((uint)Faces(id,Source)<<2)|((uint)Faces(id,Receiver)<<3)|((a&b)<<4);
}
[numthreads(1,1,1)]
void Compact(uint id:SV_DispatchThreadID)
{
    uint count[5]={0,0,0,0,0};
    for(uint i=0;i<EdgeCount;i++)for(uint j=0;j<5;j++)
        if((Flags[i]&(1u<<j))!=0)ListsOut[j*EdgeCount+count[j]++]=i;
    for(uint j=0;j<5;j++)CountsOut[j]=count[j];
}
uint Item(uint list,uint i){return Lists[list*EdgeCount+i];}
float4 CandidateCounts(){return float4(Counts[4],(float)Counts[0]*Counts[1],(float)Counts[2]*Counts[1],(float)Counts[0]*Counts[3]);}
// Small candidate sets are stratified completely; larger ones are sampled with
// independent discrete choices. No large E*E integer index or allocation.
Route Choose(uint tile,out uint begin,out Step first,out Step second)
{
    Route route=(Route)0;first=(Step)0;second=(Step)0;begin=0;
    float4 sizes=CandidateCounts();float total=dot(sizes,1);uint tiles=SampleCount/HeightBatch;
    if(total==0)return route;uint family=0,a=0,b=0;float inverse;
    if(total<=tiles)
    {
        uint count=(uint)total,base=tiles/count,extra=tiles%count,split=(base+1)*extra;
        uint rank=tile<split?tile/(base+1):extra+(tile-split)/base;
        begin=rank*base+min(rank,extra);inverse=1.0/((base+(rank<extra))*HeightBatch);
        for(uint j=0;j<3;j++){if(rank<(uint)sizes[j])break;rank-=(uint)sizes[j];family++;}
        uint columns=family==1 || family==2?Counts[1]:(family==3?Counts[3]:1);a=rank/columns;b=rank%columns;
    }
    else
    {
        float3 u=RouteDraws[tile];float x=u.x*total;float before=0;
        for(uint j=0;j<3;j++){if(x<before+sizes[j])break;before+=sizes[j];family++;}
        uint rows=family==0?Counts[4]:(family==2?Counts[2]:Counts[0]);
        uint columns=family==1 || family==2?Counts[1]:(family==3?Counts[3]:1);
        a=min(rows-1,(uint)(u.y*rows));b=min(columns-1,(uint)(u.z*columns));inverse=total/SampleCount;
        // Unrelated height samples for sampled (rather than stratified) paths.
        begin=0;
    }
    route.weight=2*inverse;
    if(family==0)
    {
        uint e=Item(4,a);first=MakeStep(e,Source,Receiver,length(Receiver-Corner(e)));route.depth=1;
    }
    else if(family==1)
    {
        a=Item(0,a);b=Item(1,b);if(a==b || !Visible(Corner(a),Corner(b)))return (Route)0;
        float last=length(Receiver-Corner(b));first=MakeStep(a,Source,Corner(b),length(Corner(b)-Corner(a))+last);
        second=MakeStep(b,Corner(a),Receiver,last);route.depth=2;
        if(a/4==b/4 && any(Corner(a)==Corner(b)))route.weight*=.5;
    }
    else
    {
        uint e=family==2?Item(1,b):Item(0,a),plane=family==2?Item(2,a):Item(3,b);float2 from=Source,to=Receiver;
        if(family==2){if(!MirrorLeg(plane,Source,Corner(e)))return (Route)0;from=Reflect(plane,Source);}
        else {if(!MirrorLeg(plane,Corner(e),Receiver))return (Route)0;to=Reflect(plane,Receiver);}
        first=MakeStep(e,from,to,length(to-Corner(e)));route.depth=1;
    }
    if(first.shape.x+first.shape.z>=Horizon || all(first.halfSine==0) || (route.depth==2 && all(second.halfSine==0)))route.depth=0;
    return route;
}
float MirrorDistance(uint a,uint b)
{
    float2 first=Reflect(a,Source),second=Reflect(b,first),hitA=0,hitB=0;
    if(a!=b && HitMirror(b,Receiver,second,hitB) && HitMirror(a,hitB,first,hitA) && Visible(Source,hitA) && Visible(hitA,hitB) && Visible(hitB,Receiver))return length(second-Receiver);
    return 0;
}
float2 Pressure(float distance)
{
    if(distance<=0 || distance>=Horizon)return 0;float2 phase;sincos(-WaveNumber*distance,phase.y,phase.x);return phase/distance;
}
[numthreads(64,1,1)]
void Mirrors(uint3 id:SV_DispatchThreadID,uint3 group:SV_GroupID,uint lane:SV_GroupIndex)
{
    float2 value=0;
    if(id.x<SampleCount){
    // First-order reflections and direct sound require only linear work.
    for(uint a=id.x;a<Counts[2];a+=SampleCount)
    {
        uint plane=Item(2,a);if(MirrorLeg(plane,Source,Receiver))value+=Pressure(length(Reflect(plane,Source)-Receiver));
    }
    if(id.x==0 && Visible(Source,Receiver))value+=Pressure(length(Receiver-Source));
    float count=(float)Counts[2]*Counts[3];
    if(count<=SampleCount)
    {
        if(id.x<(uint)count)value+=Pressure(MirrorDistance(Item(2,id.x/Counts[3]),Item(3,id.x%Counts[3])));
    }
    else
    {
        float3 u=RouteDraws[id.x];uint a=min(Counts[2]-1,(uint)(u.y*Counts[2])),b=min(Counts[3]-1,(uint)(u.z*Counts[3]));
        value+=Pressure(MirrorDistance(Item(2,a),Item(3,b)))*(count/SampleCount);
    }
    }
    if(Capture!=0 && id.x<SampleCount)MirrorContributions[id.x]=value;
    Sum[lane]=value;GroupMemoryBarrierWithGroupSync();
    for(uint stride=32;stride>0;stride>>=1){if(lane<stride)Sum[lane]+=Sum[lane+stride];GroupMemoryBarrierWithGroupSync();}
    if(lane==0)Partials[group.x]+=Sum[0];
}
// One descriptor per tile, kept in threadgroup memory, never in an E^2 buffer.
groupshared float4 TileSteps[384];
groupshared float4 TileInfo[64];
[numthreads(64,1,1)]
void IntegratePaths(uint3 id:SV_DispatchThreadID,uint3 group:SV_GroupID,uint lane:SV_GroupIndex)
{
    uint tile=id.x/HeightBatch,local=lane/HeightBatch;
    if(lane%HeightBatch==0)
    {
        Step first=(Step)0,second=(Step)0;uint begin=0;Route r=(Route)0;[branch] if(id.x<SampleCount)r=Choose(tile,begin,first,second);
        TileSteps[6*local]=first.shape;TileSteps[6*local+1]=first.sine;TileSteps[6*local+2]=first.halfSine;
        TileSteps[6*local+3]=second.shape;TileSteps[6*local+4]=second.sine;TileSteps[6*local+5]=second.halfSine;
        TileInfo[local]=float4(r.depth,r.weight,begin,0);
    }
    GroupMemoryBarrierWithGroupSync();float2 value=0;
    if(id.x<SampleCount && TileInfo[local].x>0)
    {
        Step first,second;first.shape=TileSteps[6*local];first.sine=TileSteps[6*local+1];first.halfSine=TileSteps[6*local+2];
        second.shape=TileSteps[6*local+3];second.sine=TileSteps[6*local+4];second.halfSine=TileSteps[6*local+5];
        Route r=(Route)0;r.depth=(uint)TileInfo[local].x;r.weight=TileInfo[local].y;
        value=Evaluate(r,id.x-(uint)TileInfo[local].z*HeightBatch,first,second);
    }
    if(Capture!=0 && id.x<SampleCount)Contributions[id.x]=value;
    Sum[lane]=value;GroupMemoryBarrierWithGroupSync();
    for(uint stride=32;stride>0;stride>>=1){if(lane<stride)Sum[lane]+=Sum[lane+stride];GroupMemoryBarrierWithGroupSync();}
    if(lane==0)Partials[group.x]=Sum[0];
}
