from pathlib import Path
import shutil,hashlib,json,subprocess,re,zipfile
from PIL import Image,ImageDraw,ImageFont
repo=Path.cwd();runner=repo/'.context/gpu-audio/runner';scratch=repo/'.context/church-sources';out=repo/'docs/benchmarks/church-sources-2026-10-22';out.mkdir(exist_ok=True)
paths=[Path(p) for p in ['Assets/Scenes/Church.unity','Assets/External/Church/CathedralAccents.fbx','Assets/External/Church/CathedralAccents.fbx.meta']]
for p in paths:
 shutil.copy2(runner/p,repo/p)
 if p.suffix in ['.unity','.meta']:(repo/p).write_text('\n'.join(l.rstrip() for l in (repo/p).read_text().splitlines())+'\n')
paths += [Path(p) for p in ['Assets/Scripts/Demo/AudioSourceOverlay.cs','Assets/Scripts/Demo/AudioSourceOverlay.cs.meta','Assets/Scripts/Audio/RaytracedAudioSource.cs']]
for p in paths:
 if p.suffix=='.cs':assert (runner/p).read_bytes()==(repo/p).read_bytes(),p
# Existing physical geometry, source bindings/settings and gameplay scripts retain their serialized definitions.
def blocks(text):return {int(m[1]):(int(m[0]),m[2]) for m in re.findall(r'^--- !u!(\d+) &(\d+)(.*?)(?=^--- !u!|\Z)',text,re.M|re.S)}
old=blocks(subprocess.check_output(['git','show','HEAD:Assets/Scenes/Church.unity']).decode());new=blocks((repo/'Assets/Scenes/Church.unity').read_text());colliders={64,65,135,136,143}
presetGuid=re.search(r'^guid: (\w+)',Path('Assets/Scripts/Demo/ChurchVisualPreset.cs.meta').read_text(),re.M)[1]
physics=behaviours=0
for k,(typ,body) in old.items():
 if typ in colliders or typ in [4,33,114]:
  if typ==114 and presetGuid in body:continue
  a=body;b=new[k][1]
  if typ==4:a=re.sub(r'  m_Children:.*?(?=  m_Father:)', '',a,flags=re.S);b=re.sub(r'  m_Children:.*?(?=  m_Father:)', '',b,flags=re.S)
  assert a==b,f'Existing physical/audio/gameplay component changed {k}'
  physics+=int(typ in colliders);behaviours+=int(typ==114)
assert sum(typ in colliders for typ,b in new.values())==physics
v=json.loads((scratch/'verification.json').read_text());v.update({'existingCollidersUnchanged':physics,'existingBehaviourDefinitionsUnchangedExceptPreset':behaviours,'chapelWalk':json.loads((repo/'.context/church-rooms/verification.json').read_text())})
(out/'verification.json').write_text(json.dumps(v,indent=2)+'\n')
for p in scratch.glob('*.png'):shutil.copy2(p,out/p.name)
shutil.copy2(scratch/'visible-labels.txt',out/'visible-labels.txt')
# Four real Unity views, with only labels/resizing applied to the contact sheet.
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',24)
canvas=Image.new('RGB',(1600,1204),(18,24,29));draw=ImageDraw.Draw(canvas)
for n,title,x,y in [('PolishedLowPoly-nave','Crossing ribs and candle sconces',0,38),('PolishedLowPoly-sanctuary','Rose ornament and organ lighting',800,38),('PolishedLowPoly-sources','F6: emitter positions and distances',0,640),('sources-voice','Voice marker / synthetic placement check',800,640)]:
 im=Image.open(out/(n+'.png')).resize((800,562),Image.Resampling.LANCZOS);canvas.paste(im,(x,y));draw.text((x+14,y-32),title,font=font,fill=(230,235,239))
canvas.save(out/'overview.png')
conductor=Path('/Users/clarkpeng/conductor/workspaces/realisticaudioraytracing2d/tyler/.context')
shutil.copy2(out/'PolishedLowPoly-sources.png',conductor/'church-audio-sources.png');shutil.copy2(out/'overview.png',conductor/'church-source-overview.png')
with zipfile.ZipFile(out/'authoring.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['author.py','publish.py','author.log','author-2.log','build.log','final.log']:z.write(scratch/name,name)
 z.write(runner/'Assets/Editor/ChurchSourcePolish.cs','ChurchSourcePolish.cs')
 z.write(runner/'Assets/Editor/ChurchRooms.cs','ChurchRooms.cs')
 for p in (scratch/'first-pass').glob('*.png'):z.write(p,'first-pass/'+p.name)
 for p in (repo/'.context/church-rooms').glob('*-room-route.csv'):z.write(p,p.name)
with zipfile.ZipFile(out/'authoring.zip') as z:assert z.testzip() is None
manifest={str(p):hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}
manifest.update({str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file() and p.name!='manifest.json'})
(out/'manifest.json').write_text(json.dumps({'parentCommit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'sha256':manifest},indent=2)+'\n')
print(json.dumps(v,indent=2))
