"""One-off original cathedral dressing. Coordinates are Unity metres; no runtime generator."""
import bpy, math, os, json
from mathutils import Vector
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
root='/Users/clarkpeng/UnityGames/realisticaudioraytracing2d/.context/gpu-audio/runner/Assets/External/Church'
colors={'Limestone':(.64,.60,.48,1),'Sandstone':(.43,.39,.31,1),'Slate':(.16,.23,.27,1),'Gold':(.68,.46,.18,1),'Oak':(.27,.13,.065,1),'Teal':(.035,.29,.31,1),'Crimson':(.40,.055,.055,1),'Parchment':(.75,.65,.44,1),'GlassBlue':(.055,.20,.60,1),'GlassCyan':(.07,.48,.55,1),'GlassAmber':(.83,.38,.065,1),'Flame':(1,.63,.19,1)}
mats={}
for n,c in colors.items():
 m=bpy.data.materials.new(n);m.diffuse_color=c;mats[n]=m
verts=[];faces=[];slots=[];objects=[]
def face(points,mat):
 points=[p for i,p in enumerate(points) if tuple(p)!=tuple(points[i-1])]
 if len(points)<3:return
 n=len(verts);verts.extend([(-p[0],-p[2],p[1]) for p in points]);faces.append(tuple(reversed(range(n,n+len(points)))));slots.append(list(colors).index(mat))
def box(c,s,m):
 x,y,z=c;a,b,d=[v/2 for v in s];p=[(x+i*a,y+j*b,z+k*d) for i,j,k in [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]]
 for ids in [(0,3,2,1),(4,5,6,7),(0,1,5,4),(3,7,6,2),(0,4,7,3),(1,2,6,5)]:face([p[i] for i in ids],m)
def lathe(c,profile,m,n=8):
 x,y,z=c
 for (r0,h0),(r1,h1) in zip(profile,profile[1:]):
  for i in range(n):
   a=i*math.tau/n;b=(i+1)*math.tau/n
   face([(x+r0*math.cos(a),y+h0,z+r0*math.sin(a)),(x+r1*math.cos(a),y+h1,z+r1*math.sin(a)),(x+r1*math.cos(b),y+h1,z+r1*math.sin(b)),(x+r0*math.cos(b),y+h0,z+r0*math.sin(b))],m)
def beam(a,b,w,m):
 a,b=Vector(a),Vector(b);d=(b-a).normalized();u=d.cross(Vector((0,0,1)))
 if u.length<.01:u=d.cross(Vector((0,1,0)))
 u.normalize();u*=w/2;v=d.cross(u)
 p=[a-u-v,a+u-v,a+u+v,a-u+v,b-u-v,b+u-v,b+u+v,b-u+v]
 for ids in [(0,3,2,1),(4,5,6,7),(0,1,5,4),(3,7,6,2),(0,4,7,3),(1,2,6,5)]:face([p[i] for i in ids],m)
def finish(name):
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.update();o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o)
 for m in mats.values():mesh.materials.append(m)
 for p,slot in zip(mesh.polygons,slots):p.material_index=slot
 # World planar mapping for optional PBR textures, not required by the flat-color style.
 uv=mesh.uv_layers.new(name='UVMap')
 for p in mesh.polygons:
  axis=max(range(3),key=lambda k:abs(p.normal[k]));axes=[k for k in range(3) if k!=axis]
  for li in p.loop_indices:
   v=mesh.vertices[mesh.loops[li].vertex_index].co;uv.data[li].uv=(v[axes[0]]*.3,v[axes[1]]*.3)
 # Strip unused material slots to avoid empty render batches.
 used=sorted(set(slots));old=list(mesh.materials);indices=[used.index(p.material_index) for p in mesh.polygons];mesh.materials.clear()
 for k in used:mesh.materials.append(old[k])
 for p,k in zip(mesh.polygons,indices):p.material_index=k
 objects.append(o);verts.clear();faces.clear();slots.clear();return o

def arch(cx,cz,width,spring,rise,thick=.38,depth=.5,turn=False):
 # Faceted pointed arch, structural piers reach the floor. Rotate for side wings.
 def point(x,y,z):return (cx+z,y,cz+x) if turn else (cx+x,y,cz+z)
 for sign in (-1,1):
  # Multi-ring octagonal columns and stepped capitals.
  c=point(sign*width/2,1,0)
  lathe(c,[(0,0),(.62,0),(.62,.2),(.48,.32),(.35,.42),(.35,spring-1.5),(.5,spring-1.35),(.55,spring-1), (0,spring-1)],'Limestone')
 # Two circular arcs meet at a point, using an explicit sampled quadratic for predictable silhouettes.
 path=[]
 for i in range(25):
  t=i/24;x=-width/2+width*t;y=spring+rise*(1-abs(2*t-1))**.65;path.append(Vector((x,y,0)))
 for i,(a,b) in enumerate(zip(path,path[1:])):
  def normal(k):
   d=(path[min(k+1,len(path)-1)]-path[max(k-1,0)]).normalized()
   return Vector((-d.y,d.x,0))*thick/2
  na,nb=normal(i),normal(i+1)
  pts=[]
  for z in (-depth/2,depth/2):
   pts.extend(point(p.x,p.y,z) for p in (a-na,b-nb,b+nb,a+na))
  m='Limestone' if i%3 else 'Sandstone'
  for ids in [(0,3,2,1),(4,5,6,7),(0,1,5,4),(3,7,6,2)]+([(0,4,7,3)] if i==0 else [])+([(1,2,6,5)] if i==len(path)-2 else []):face([pts[k] for k in ids],m)
 # Keystone pendant.
 c=point(0,spring+rise-.12,0);lathe(c,[(0,-.35),(.28,-.12),(.24,.35),(0,.35)],'Gold')

# Slender crossing ribs fit under the existing high nave ceiling, between the larger arcades.
for z in (-31,-24,-17,-10):
 for side in (-1,1):
  for end in (0,7):
   path=[]
   for k in range(9):
    t=k/8;path.append((side*8.45*(1-t),10+6.7*math.sin(t*math.pi/2),z+end+(3.5-end)*t))
   for a,b in zip(path,path[1:]):beam(a,b,.14,'Limestone')
 lathe((0,16.65,z+3.5),[(0,0),(.27,.12),(.27,.22),(0,.32)],'Gold')
finish('Nave vault ribs')
# Decorative sanctuary rose medallion. A colored panel, not a new aperture in the acoustic shell.
cx,cy,cz=0,13.15,21.0
for r0,r1,m in [(3.2,3.4,'Sandstone'),(3.0,3.18,'Gold'),(.45,.58,'Gold')]:
 for i in range(48):
  a=i*math.tau/48;b=(i+1)*math.tau/48
  face([(cx+r0*math.cos(a),cy+r0*math.sin(a),cz),(cx+r1*math.cos(a),cy+r1*math.sin(a),cz),(cx+r1*math.cos(b),cy+r1*math.sin(b),cz),(cx+r0*math.cos(b),cy+r0*math.sin(b),cz)][::-1],m)
for i in range(12):
 a=i*math.tau/12;b=(i+1)*math.tau/12;c=(a+b)/2
 center=(cx,cy,cz+.02);inner=(cx+.61*math.cos(c),cy+.61*math.sin(c),cz)
 tip=(cx+2.95*math.cos(c),cy+2.95*math.sin(c),cz)
 left=(cx+2.2*math.cos(a+.045),cy+2.2*math.sin(a+.045),cz)
 right=(cx+2.2*math.cos(b-.045),cy+2.2*math.sin(b-.045),cz)
 face([inner,left,tip][::-1],'GlassBlue' if i%2 else 'GlassCyan')
 face([inner,tip,right][::-1],'GlassAmber' if i%3==0 else 'GlassCyan')
 for p,q in [(inner,left),(left,tip),(tip,right),(right,inner)]:beam(p,q,.055,'Gold')
for i in range(12):
 a=i*math.tau/12;b=(i+1)*math.tau/12
 face([(0,cy,cz-.015),(.44*math.cos(a),cy+.44*math.sin(a),cz-.015),(.44*math.cos(b),cy+.44*math.sin(b),cz-.015)][::-1],'GlassAmber')
# Pointed surround emphasizes the organ facade without changing its existing collision case.
for side in (-1,1):
 x=side*3.6
 box((x,5.3,19.8),(.3,8.4,.25),'Oak');box((x,1.3,19.8),(.55,.6,.5),'Gold')
 beam((x,9.5,19.8),(0,10.9,19.8),.2,'Oak')
finish('Sanctuary rose and organ surround')
# Wall sconces above head height. Four fixtures share one mesh and the existing material palette.
for x,z in [(-8.6,-17),(8.6,-17),(-8.6,-3),(8.6,-3)]:
 side=1 if x>0 else -1
 box((x,4.3,z),(.12,1.15,.45),'Slate')
 beam((x,4.1,z),(x-side*.6,3.9,z),.09,'Gold')
 for dz in (-.22,.22):
  p=(x-side*.6,3.9,z+dz)
  lathe(p,[(0,0),(.13,0),(.13,.1),(.07,.12),(.07,.58),(0,.58)],'Parchment')
  lathe((p[0],p[1]+.58,p[2]),[(0,0),(.07,.07),(0,.27)],'Flame',5)
finish('Nave sconces')
# Art mounted on the reading room end wall: a sun/compass inset inside a pointed wooden frame.
x,z=19.8,6.1
for dz in (-1.9,1.9):beam((x,2,z+dz),(x,6.4,z+dz),.16,'Gold')
beam((x,6.4,z-1.9),(x,8.3,z),.16,'Gold');beam((x,8.3,z),(x,6.4,z+1.9),.16,'Gold')
for i in range(24):
 a=i*math.tau/24;b=(i+1)*math.tau/24
 y0,z0=4.8+1.55*math.sin(a),z+1.55*math.cos(a);y1,z1=4.8+1.55*math.sin(b),z+1.55*math.cos(b)
 face([(x-.03,4.8,z),(x-.03,y0,z0),(x-.03,y1,z1)],'Teal' if i%2 else 'Slate')
 beam((x-.06,y0,z0),(x-.06,y1,z1),.07,'Gold')
 if i%3==0:beam((x-.08,4.8,z),(x-.08,y0,z0),.065,'Gold')
finish('Reading chapel crest')
bpy.ops.object.select_all(action='DESELECT')
for o in objects:o.select_set(True)
bpy.ops.export_scene.fbx(filepath=root+'/CathedralAccents.fbx',use_selection=True,object_types={'MESH'},add_leaf_bones=False,bake_anim=False,axis_forward='-Z',axis_up='Y',path_mode='RELATIVE')
print('ACCENTS',[(o.name,len(o.data.polygons)) for o in objects])
