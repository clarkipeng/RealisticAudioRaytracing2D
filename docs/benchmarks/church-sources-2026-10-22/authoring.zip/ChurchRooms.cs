using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
public static class ChurchRooms {
 const string Output="/Users/clarkpeng/UnityGames/realisticaudioraytracing2d/.context/church-rooms";
 public static void Build() {
  if(!Application.isBatchMode)throw new Exception("Batch only");
  const string folder="Assets/Materials/ChurchPresentation/";
  const string modelPath="Assets/External/Church/CathedralRooms.fbx";
  var colors=new System.Collections.Generic.Dictionary<string,Color>{
   {"Limestone",new Color(.64f,.60f,.48f)}, {"Sandstone",new Color(.43f,.39f,.31f)}, {"Slate",new Color(.16f,.23f,.27f)},
   {"Gold",new Color(.68f,.46f,.18f)}, {"Oak",new Color(.27f,.13f,.065f)}, {"Teal",new Color(.035f,.29f,.31f)},
   {"Crimson",new Color(.40f,.055f,.055f)}, {"Parchment",new Color(.75f,.65f,.44f)},
   {"GlassBlue",new Color(.055f,.20f,.60f)}, {"GlassCyan",new Color(.07f,.48f,.55f)}, {"GlassAmber",new Color(.83f,.38f,.065f)}, {"Flame",new Color(1,.63f,.19f)}};
  var importer=(ModelImporter)AssetImporter.GetAtPath(modelPath);importer.isReadable=true;importer.importCameras=false;importer.importLights=false;importer.importAnimation=false;importer.materialImportMode=ModelImporterMaterialImportMode.ImportStandard;
  var low=new System.Collections.Generic.Dictionary<string,Material>();var real=new System.Collections.Generic.Dictionary<string,Material>();
  foreach(var pair in colors) {
   foreach(bool textured in new[]{false,true}) {
    if(textured && pair.Key!="Limestone" && pair.Key!="Sandstone" && pair.Key!="Oak"){real[pair.Key]=low[pair.Key];continue;}
    string path=folder+"Rooms-"+(textured?"PBR-":"")+pair.Key+".mat";
    var m=AssetDatabase.LoadAssetAtPath<Material>(path);
    if(m==null){m=new Material(Shader.Find("Standard"));AssetDatabase.CreateAsset(m,path);}
    m.color=pair.Value;m.SetFloat("_Glossiness",pair.Key=="Gold"?.5f:.15f);m.enableInstancing=true;
    if(pair.Key=="Gold")m.SetFloat("_Metallic",.2f);
    if(pair.Key.StartsWith("Glass") || pair.Key=="Flame"){
     m.globalIlluminationFlags=MaterialGlobalIlluminationFlags.BakedEmissive;m.EnableKeyword("_EMISSION");m.SetColor("_EmissionColor",pair.Value*(pair.Key=="Flame"?2.5f:.8f));
    }
    if(textured && (pair.Key=="Limestone" || pair.Key=="Sandstone" || pair.Key=="Oak")) {
     m.mainTexture=AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/External/Church/Textures/"+(pair.Key=="Oak"?"Wood.jpg":"marble.jpg"));
    }
    EditorUtility.SetDirty(m);(textured?real:low)[pair.Key]=m;
   }
   importer.AddRemap(new AssetImporter.SourceAssetIdentifier(typeof(Material),pair.Key),real[pair.Key]);
  }
  importer.SaveAndReimport();
  EditorSceneManager.OpenScene("Assets/Scenes/Church.unity");
  var session=UnityEngine.Object.FindAnyObjectByType<SceneSession>();var manager=session.manager;
  var visual=session.GetComponent<ChurchVisualPreset>();
  var old=manager.takeRoot.Find("Cathedral rooms");if(old!=null)UnityEngine.Object.DestroyImmediate(old.gameObject);
  var obj=(GameObject)PrefabUtility.InstantiatePrefab(AssetDatabase.LoadAssetAtPath<GameObject>(modelPath),manager.takeRoot);obj.name="Cathedral rooms";
  // Ordinary editable object hierarchy; all additions share one imported kit.
  var bindings=visual.bindings.Where(b=>b.renderer!=null).ToList();
  foreach(var r in obj.GetComponentsInChildren<MeshRenderer>()) {
   string[] keys=r.sharedMaterials.Select(m=>m.name.Replace("Rooms-PBR-","").Replace("Rooms-","")).ToArray();
   bindings.Add(new ChurchVisualPreset.Binding{renderer=r,realistic=keys.Select(k=>real[k]).ToArray(),lowPoly=keys.Select(k=>low[k]).ToArray()});
   GameObjectUtility.SetStaticEditorFlags(r.gameObject,StaticEditorFlags.BatchingStatic|StaticEditorFlags.OccluderStatic|StaticEditorFlags.OccludeeStatic);
   if(new[]{"Nave arcades","Chapel portals","Baptismal font","Baptistery ribs","Reading roof trusses"}.Contains(r.name)) {
    r.gameObject.AddComponent<MeshCollider>().sharedMesh=r.GetComponent<MeshFilter>().sharedMesh;
    var s=r.gameObject.AddComponent<AcousticSurface>();s.geometrySource=AcousticSurface.GeometrySource.Collider;
    s.material=AssetDatabase.LoadAssetAtPath<AudioMaterial>("Assets/Materials/Church "+(r.name=="Reading roof trusses"?"wood":"stone")+".asset");
   }
  }
  visual.bindings=bindings.ToArray();
  void Proxy(string name,Vector3 center,Vector3 size,string material) {
   var p=new GameObject(name);p.transform.SetParent(obj.transform,false);p.transform.localPosition=center;
   p.AddComponent<BoxCollider>().size=size;
   var s=p.AddComponent<AcousticSurface>();s.geometrySource=AcousticSurface.GeometrySource.Collider;
   s.material=AssetDatabase.LoadAssetAtPath<AudioMaterial>("Assets/Materials/Church "+material+".asset");
  }
  Proxy("South reading shelves",new Vector3(15.5f,2.75f,-1.8f),new Vector3(6.6f,3.5f,1.15f),"wood");
  Proxy("North reading shelves",new Vector3(15.5f,2.75f,9),new Vector3(6.6f,3.5f,1.15f),"wood");
  Proxy("Reading tabletop",new Vector3(15.2f,2.05f,4),new Vector3(3.3f,.18f,1.65f),"wood");
  foreach(float z in new[]{2.4f,5.6f})Proxy("Reading bench",new Vector3(15.2f,1.25f,z),new Vector3(3,.65f,.55f),"wood");
  foreach(float x in new[]{13.8f,16.6f})foreach(float z in new[]{3.4f,4.6f})Proxy("Table leg",new Vector3(x,1.5f,z),new Vector3(.18f,1,.18f),"wood");
  // Visible candle fixtures motivate local light. No per-candle light components.
  foreach(var p in new[]{new Vector3(-12.5f,4.8f,1.5f),new Vector3(13.5f,5,4)}) {
   var l=new GameObject("Chapel lamps").AddComponent<Light>();l.transform.SetParent(obj.transform,false);l.transform.localPosition=p;
   l.type=LightType.Point;l.range=11;l.color=new Color(1,.76f,.38f);l.intensity=2.8f;l.shadows=LightShadows.Soft;l.renderMode=LightRenderMode.ForcePixel;
  }
  // The low-poly windows still need their authored stained-glass pattern, not a single flat blue swatch.
  var windowLow=AssetDatabase.LoadAssetAtPath<Material>(folder+"LowPoly-glass.mat");
  var glass=AssetDatabase.LoadAssetAtPath<Material>("Assets/External/Church/Glass.mat");windowLow.CopyPropertiesFromMaterial(glass);EditorUtility.SetDirty(windowLow);
  var stone=AssetDatabase.LoadAssetAtPath<Material>(folder+"LowPoly-stone.mat");stone.color=new Color(.48f,.53f,.55f);EditorUtility.SetDirty(stone);
  visual.Apply(ChurchVisualPreset.Preset.PolishedLowPoly);
  manager.RegisterTakeObjects();EditorUtility.SetDirty(manager);EditorUtility.SetDirty(visual);
  EditorSceneManager.SaveScene(session.gameObject.scene);AssetDatabase.SaveAssets();
  Preview();
 }
 public static void Preview() {
  EditorSceneManager.OpenScene("Assets/Scenes/Church.unity");
  var session=UnityEngine.Object.FindAnyObjectByType<SceneSession>();var preset=session.GetComponent<ChurchVisualPreset>();
  var cam=session.player.GetComponentInChildren<Camera>();
  foreach(var style in new[]{ChurchVisualPreset.Preset.PolishedLowPoly,ChurchVisualPreset.Preset.Realistic}){
   preset.Apply(style);string prefix=style.ToString();
   Shot(cam,new Vector3(0,3,-28),new Vector3(0,7,15),prefix+"-nave");
   Shot(cam,new Vector3(-10,3.1f,.1f),new Vector3(-16,3.9f,4),prefix+"-baptistery");
   Shot(cam,new Vector3(10,3.1f,.1f),new Vector3(16,3.5f,4),prefix+"-reading");
   Shot(cam,new Vector3(0,4.5f,-8),new Vector3(0,5,6),prefix+"-crossing");
  }
 }
 public static void Verify() {
  if(!Application.isBatchMode)throw new Exception("Batch only");
  var old=Physics.simulationMode;Physics.simulationMode=SimulationMode.Script;
  var routes=new System.Collections.Generic.List<Vector3[]>();
  try {
   foreach(var style in new[]{ChurchVisualPreset.Preset.PolishedLowPoly,ChurchVisualPreset.Preset.Realistic}) {
    EditorSceneManager.OpenScene("Assets/Scenes/Church.unity");
    var session=UnityEngine.Object.FindAnyObjectByType<SceneSession>();var m=session.manager;
    session.GetComponent<ChurchVisualPreset>().Apply(style);
    var scene=SceneToTake.Compile(m.takeObjects,m.takeDimension,m.takeCurveTolerance,m.takeDefaultMaterial,m.takeSources.Select(s=>s.transform).ToArray(),m.takeSources.Select(s=>s.streamed?null:s.clip).ToArray(),m.takeListeners.ToArray(),out var geometry);
    string[] physical={"Nave arcades","Chapel portals","Baptismal font","Baptistery ribs","Reading roof trusses","South reading shelves","North reading shelves","Reading tabletop","Reading bench","Table leg"};
    foreach(string name in physical)if(!scene.objects.Any(o=>o.name==name && o.primitiveCount>0))throw new Exception("Missing acoustic geometry "+name);
    File.WriteAllLines(Output+"/"+style+"-acoustic.csv",new[]{"object,triangles"}.Concat(scene.objects.Select(o=>o.name+","+o.primitiveCount)));
    var player=session.player;var walker=player.GetComponent<PlayerController>();
    void Reset(Vector3 pos){player.GetComponent<CharacterController>().enabled=false;player.SetPositionAndRotation(pos,Quaternion.identity);player.GetComponentInChildren<MouseLook>().transform.localRotation=Quaternion.identity;player.GetComponent<CharacterController>().enabled=true;session.InitializeSimulation();for(int i=0;i<4;i++){session.Step(default,.02f);Physics.Simulate(.02f);}}
    Reset(new Vector3(0,1.08f,0));
    var samples=new System.Collections.Generic.List<Vector3>();
    var waypoints=new[]{new Vector2(-15.5f,0),new Vector2(-18,0),new Vector2(-18,7),new Vector2(-12,7),new Vector2(0,7),new Vector2(15.2f,7),new Vector2(18.5f,7),new Vector2(18.5f,0),new Vector2(12,0),new Vector2(0,0)};
    foreach(var target in waypoints) {
     int ticks=0;
     while(Vector2.Distance(new Vector2(player.position.x,player.position.z),target)>.13f) {
      if(++ticks>400)throw new Exception("Blocked route to "+target+" at "+player.position);
      Vector2 direction=target-new Vector2(player.position.x,player.position.z);
      session.Step(new SceneRecording.Input{movement=direction.normalized},.02f);Physics.Simulate(.02f);
      if(walker.Ground==null || player.position.y<.8f)throw new Exception("Lost floor at "+player.position);
      samples.Add(player.position);
     }
    }
    routes.Add(samples.ToArray());File.WriteAllLines(Output+"/"+style+"-room-route.csv",new[]{"x,y,z"}.Concat(samples.Select(p=>FormattableString.Invariant($"{p.x:R},{p.y:R},{p.z:R}"))));
    Reset(new Vector3(-12,1.08f,4));for(int i=0;i<80;i++){session.Step(new SceneRecording.Input{movement=Vector2.left},.02f);Physics.Simulate(.02f);}
    float fontStop=player.position.x;if(fontStop< -14 || fontStop> -12.5f)throw new Exception("Font collision failed "+player.position);
    Reset(new Vector3(11.7f,1.08f,4));for(int i=0;i<80;i++){session.Step(new SceneRecording.Input{movement=Vector2.right},.02f);Physics.Simulate(.02f);}
    float tableStop=player.position.x;if(tableStop>13.5f || tableStop<12)throw new Exception("Table collision failed "+player.position);
    Debug.Log($"ROOMS_VERIFIED {style} triangles={geometry.Length} routeTicks={samples.Count} fontStop={fontStop:R} tableStop={tableStop:R}");
   }
   if(routes[0].Length!=routes[1].Length)throw new Exception("Style route length changed");
   float delta=routes[0].Zip(routes[1],(a,b)=>Vector3.Distance(a,b)).Max();if(delta>.001f)throw new Exception("Style changed movement");
   File.WriteAllText(Output+"/verification.json",$"{{\"routeTicksPerStyle\":{routes[0].Length},\"maxStylePositionDelta\":{delta:R},\"allRouteTicksGrounded\":true,\"fontAndTableCollisions\":true,\"newPhysicalObjectsCompiled\":true}}");
  }finally{Physics.simulationMode=old;}
 }
 public static void Finish(){Preview();Verify();ChurchPresentationCapture.CaptureBoth();}
 public static void GroupFurniture() {
  if(!Application.isBatchMode)throw new Exception("Batch only");
  EditorSceneManager.OpenScene("Assets/Scenes/Church.unity");
  var session=UnityEngine.Object.FindAnyObjectByType<SceneSession>();var root=session.manager.takeRoot.Find("Cathedral rooms");
  PrefabUtility.UnpackPrefabInstance(root.gameObject,PrefabUnpackMode.Completely,InteractionMode.AutomatedAction);
  foreach(string meshName in new[]{"Reading shelves","Reading table"}) {
   var mesh=root.Find(meshName);var anchor=new GameObject(meshName+" ensemble").transform;anchor.SetParent(root,false);
   anchor.position=meshName=="Reading table"?new Vector3(15.2f,1,4):new Vector3(15.5f,1,3.7f);
   mesh.SetParent(anchor,true);
   foreach(var child in root.Cast<Transform>().ToArray()) {
    bool selected=meshName=="Reading table" ? child.name=="Reading tabletop" || child.name=="Reading bench" || child.name=="Table leg" : child.name.EndsWith("reading shelves");
    if(selected)child.SetParent(anchor,true);
   }
  }
  EditorSceneManager.SaveScene(session.gameObject.scene);
  Verify();ChurchPresentationCapture.CaptureBoth();
 }
 public static void Inspect() {
  if(!Application.isBatchMode)throw new Exception("Batch only");
  EditorSceneManager.OpenScene("Assets/Scenes/Church.unity");
  var preset=UnityEngine.Object.FindAnyObjectByType<ChurchVisualPreset>();preset.Apply(ChurchVisualPreset.Preset.PolishedLowPoly);
  File.WriteAllLines(Output+"/bounds.txt",UnityEngine.Object.FindObjectsByType<Renderer>().Select(r=>$"{r.name}: center={r.bounds.center} size={r.bounds.size}"));
  var cam=UnityEngine.Object.FindAnyObjectByType<SceneSession>().player.GetComponentInChildren<Camera>();
  Shot(cam,new Vector3(0,3,-28),new Vector3(0,8,15),"before-nave");
  Shot(cam,new Vector3(0,3,3),new Vector3(-19,5,4),"before-west");
  Shot(cam,new Vector3(0,3,3),new Vector3(19,5,4),"before-east");
  Shot(cam,new Vector3(-18,3,8),new Vector3(-10,5,-2),"before-chapel");
  Physics.SyncTransforms();
  using(var w=new StreamWriter(Output+"/floor.csv")) {
   w.WriteLine("x,z,blocked");
   for(int z=-34;z<=24;z++)for(int x=-22;x<=22;x++)
    w.WriteLine($"{x},{z},{Physics.CheckSphere(new Vector3(x,2,z),.2f,~0,QueryTriggerInteraction.Ignore)}");
  }
 }
 static void Shot(Camera cam,Vector3 pos,Vector3 target,string name) {
  cam.transform.position=pos;cam.transform.LookAt(target);cam.fieldOfView=70;cam.farClipPlane=200;
  QualitySettings.pixelLightCount=8;QualitySettings.shadowDistance=90;QualitySettings.shadows=ShadowQuality.All;
  var rt=new RenderTexture(1280,900,24){antiAliasing=4};cam.targetTexture=rt;cam.Render();RenderTexture.active=rt;
  var tex=new Texture2D(rt.width,rt.height,TextureFormat.RGB24,false);tex.ReadPixels(new Rect(0,0,rt.width,rt.height),0,0);tex.Apply();File.WriteAllBytes(Output+"/"+name+".png",tex.EncodeToPNG());
  cam.targetTexture=null;RenderTexture.active=null;UnityEngine.Object.DestroyImmediate(tex);rt.Release();UnityEngine.Object.DestroyImmediate(rt);
 }
}
