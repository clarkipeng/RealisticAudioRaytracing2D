using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;
public static class ChurchSourcePolish {
 const string Output="/Users/clarkpeng/UnityGames/realisticaudioraytracing2d/.context/church-sources";
 public static void Build(){
  if(!Application.isBatchMode)throw new Exception("Batch only");
  const string path="Assets/External/Church/CathedralAccents.fbx";
  var importer=(ModelImporter)AssetImporter.GetAtPath(path);importer.isReadable=true;importer.importAnimation=false;importer.importCameras=false;importer.importLights=false;
  foreach(string key in new[]{"Limestone","Sandstone","Slate","Gold","Oak","Teal","Crimson","Parchment","GlassBlue","GlassCyan","GlassAmber","Flame"}) {
   string m="Assets/Materials/ChurchPresentation/Rooms-"+(new[]{"Limestone","Sandstone","Oak"}.Contains(key)?"PBR-":"")+key+".mat";
   importer.AddRemap(new AssetImporter.SourceAssetIdentifier(typeof(Material),key),AssetDatabase.LoadAssetAtPath<Material>(m));
  }
  importer.SaveAndReimport();
  EditorSceneManager.OpenScene("Assets/Scenes/Church.unity");var session=UnityEngine.Object.FindAnyObjectByType<SceneSession>();var preset=session.GetComponent<ChurchVisualPreset>();
  var old=session.manager.takeRoot.Find("Cathedral accents");if(old!=null)UnityEngine.Object.DestroyImmediate(old.gameObject);
  var obj=(GameObject)PrefabUtility.InstantiatePrefab(AssetDatabase.LoadAssetAtPath<GameObject>(path),session.manager.takeRoot);obj.name="Cathedral accents";
  var bindings=preset.bindings.Where(b=>b.renderer!=null).ToList();
  foreach(var r in obj.GetComponentsInChildren<MeshRenderer>()) {
   var real=r.sharedMaterials;var low=real.Select(m=>AssetDatabase.LoadAssetAtPath<Material>("Assets/Materials/ChurchPresentation/"+m.name.Replace("PBR-","")+".mat")).ToArray();
   if(low.Any(m=>m==null))throw new Exception("Missing palette");
   bindings.Add(new ChurchVisualPreset.Binding{renderer=r,realistic=real,lowPoly=low});
  }
  preset.bindings=bindings.ToArray();
  // A restrained sanctuary light brings out the rose rim and the organ's pipe towers.
  var lamp=new GameObject("Sanctuary uplight").AddComponent<Light>();lamp.transform.SetParent(obj.transform,false);lamp.transform.localPosition=new Vector3(0,7.5f,15);
  lamp.transform.LookAt(new Vector3(0,12,22));lamp.type=LightType.Spot;lamp.spotAngle=65;lamp.range=17;lamp.intensity=2.1f;lamp.color=new Color(1,.73f,.46f);lamp.shadows=LightShadows.Soft;
  var cam=session.player.GetComponentInChildren<Camera>();
  var overlay=cam.GetComponent<AudioSourceOverlay>()??cam.gameObject.AddComponent<AudioSourceOverlay>();overlay.manager=session.manager;overlay.visible=true;
  preset.Apply(ChurchVisualPreset.Preset.PolishedLowPoly);EditorUtility.SetDirty(preset);EditorUtility.SetDirty(overlay);
  EditorSceneManager.SaveScene(session.gameObject.scene);AssetDatabase.SaveAssets();Final();
 }
 public static void Preview(){
  EditorSceneManager.OpenScene("Assets/Scenes/Church.unity");var session=UnityEngine.Object.FindAnyObjectByType<SceneSession>();var preset=session.GetComponent<ChurchVisualPreset>();var cam=session.player.GetComponentInChildren<Camera>();
  foreach(var style in new[]{ChurchVisualPreset.Preset.PolishedLowPoly,ChurchVisualPreset.Preset.Realistic}){
   preset.Apply(style);string name=style.ToString();
   Shot(cam,new Vector3(0,3,-28),new Vector3(0,9,15),name+"-nave",false);
   Shot(cam,new Vector3(-4,3,5),new Vector3(0,9,21),name+"-sanctuary",false);
   Shot(cam,new Vector3(10,3.1f,.1f),new Vector3(18,4.2f,5.5f),name+"-reading",false);
   Shot(cam,new Vector3(0,3,-8),new Vector3(0,8,19),name+"-sources",true);
  }
  var overlay=cam.GetComponent<AudioSourceOverlay>();
  Shot(cam,new Vector3(0,3,-8),new Vector3(0,3,-30),"sources-behind",true);
  // A synthetic remote emitter exercises the live pool's active/inactive filtering without networking/audio.
  var remote=session.multiplayer.remoteVoices[0];remote.transform.parent.gameObject.SetActive(true);remote.transform.parent.position=new Vector3(3,1,1);
  Shot(cam,new Vector3(0,3,-8),new Vector3(0,3,5),"sources-voice",true);
  File.WriteAllLines(Output+"/visible-labels.txt",cam.GetComponentsInChildren<Text>().Where(t=>t.gameObject.activeInHierarchy).Select(t=>t.text));
  overlay.visible=false;overlay.Refresh();if(cam.GetComponentInChildren<Canvas>().enabled)throw new Exception("Hidden overlay still enabled");
  remote.transform.parent.gameObject.SetActive(false);
 }
 public static void Verify(){
  EditorSceneManager.OpenScene("Assets/Scenes/Church.unity");var session=UnityEngine.Object.FindAnyObjectByType<SceneSession>();var m=session.manager;var cam=session.player.GetComponentInChildren<Camera>();var overlay=cam.GetComponent<AudioSourceOverlay>();
  var rt=new RenderTexture(1280,900,24);cam.targetTexture=rt;
  cam.transform.position=new Vector3(0,3,-8);cam.transform.rotation=Quaternion.identity;
  void Refresh(){overlay.Refresh();Canvas.ForceUpdateCanvases();overlay.Refresh();}
  Text[] Tags()=>cam.GetComponentsInChildren<Text>().Where(t=>t.gameObject.activeInHierarchy).ToArray();
  var organ=m.takeSources.Single(s=>s.name=="Pipe organ");var start=organ.transform.position;
  string sourceSettings=string.Join("|",m.takeSources.Select(s=>EditorJsonUtility.ToJson(s)));
  string managerSettings=EditorJsonUtility.ToJson(m);
  Refresh();if(Tags().Length!=2)throw new Exception("Expected organ/bell only; local mic or inactive slot leaked");
  organ.transform.position=cam.transform.position+cam.transform.forward*12;Refresh();
  var tag=Tags().Single(t=>t.text.Contains("Pipe organ"));
  if(!tag.text.Contains("12 m") || tag.text.Contains("behind"))throw new Exception("Moved emitter label stale");
  var anchor=((RectTransform)tag.transform.parent).anchorMin;if(Vector2.Distance(anchor,Vector2.one*.5f)>.001f)throw new Exception("Front emitter not centered");
  organ.transform.position=cam.transform.position-cam.transform.forward*20;Refresh();tag=Tags().Single(t=>t.text.Contains("Pipe organ"));
  if(!tag.text.Contains("behind") || !tag.text.Contains("20 m"))throw new Exception("Behind-camera marker incorrect");
  organ.transform.position=cam.transform.position+cam.transform.right*100+cam.transform.forward*10;Refresh();tag=Tags().Single(t=>t.text.Contains("Pipe organ"));
  if(!tag.text.Contains("→"))throw new Exception("Offscreen marker wrong direction");
  var corners=new Vector3[4];((RectTransform)tag.transform.parent).GetWorldCorners(corners);
  foreach(var corner in corners){var p=cam.WorldToViewportPoint(corner);if(p.x<0 || p.x>1 || p.y<0 || p.y>1)throw new Exception("Tag clipped outside viewport");}
  organ.transform.position=cam.transform.position+cam.transform.right*10;Refresh();tag=Tags().Single(t=>t.text.Contains("Pipe organ"));
  anchor=((RectTransform)tag.transform.parent).anchorMin;if(!float.IsFinite(anchor.x) || !float.IsFinite(anchor.y))throw new Exception("Camera-plane projection nonfinite");
  organ.enabled=false;Refresh();if(Tags().Length!=1)throw new Exception("Disabled source still displayed");organ.enabled=true;organ.transform.position=start;
  var voice=session.multiplayer.remoteVoices[0];voice.transform.parent.gameObject.SetActive(true);Refresh();if(Tags().Length!=3)throw new Exception("Active remote voice missing");voice.transform.parent.gameObject.SetActive(false);
  overlay.visible=false;Refresh();if(cam.GetComponentInChildren<Canvas>().enabled)throw new Exception("Toggle failed");overlay.visible=true;
  // Registry changes outside a capture rebuild UI without retaining detached label roots.
  var extra=new GameObject("Temporary emitter").AddComponent<RaytracedAudioSource>();m.takeSources.Add(extra);Refresh();if(Tags().Length!=3)throw new Exception("New source not displayed");m.takeSources.Remove(extra);UnityEngine.Object.DestroyImmediate(extra.gameObject);Refresh();if(Tags().Length!=2 || cam.GetComponentsInChildren<Canvas>(true).Length!=1)throw new Exception("UI roots leaked");
  if(sourceSettings!=string.Join("|",m.takeSources.Select(s=>EditorJsonUtility.ToJson(s))) || managerSettings!=EditorJsonUtility.ToJson(m))throw new Exception("Overlay mutated audio settings");
  var scene=SceneToTake.Compile(m.takeObjects,m.takeDimension,m.takeCurveTolerance,m.takeDefaultMaterial,m.takeSources.Select(s=>s.transform).ToArray(),m.takeSources.Select(s=>s.streamed?null:s.clip).ToArray(),m.takeListeners.ToArray(),out var geometry);
  if(geometry.Length!=17321)throw new Exception("Decoration entered acoustic geometry");
  File.WriteAllText(Output+"/verification.json","{\"initialVisibleEmitters\":2,\"activeRemoteVoiceVisible\":true,\"localVoiceAndInactiveSlotsHidden\":true,\"movingAndBehindCameraLabels\":true,\"offscreenTagInsideViewport\":true,\"toggleAndRegistryRebuild\":true,\"audioSettingsUnchanged\":true,\"acousticTriangles\":17321}");
  cam.targetTexture=null;rt.Release();UnityEngine.Object.DestroyImmediate(rt);
  ChurchRooms.Verify();Debug.Log("SOURCE_OVERLAY_VERIFIED");
 }
 public static void Final(){Preview();Verify();}
 static void Shot(Camera cam,Vector3 eye,Vector3 aim,string name,bool markers){
  cam.transform.position=eye;cam.transform.LookAt(aim);cam.fieldOfView=70;cam.farClipPlane=200;
  QualitySettings.pixelLightCount=8;QualitySettings.shadows=ShadowQuality.All;QualitySettings.shadowDistance=90;
  var rt=new RenderTexture(1280,900,24){antiAliasing=4};cam.targetTexture=rt;
  var overlay=cam.GetComponent<AudioSourceOverlay>();overlay.visible=markers;overlay.Refresh();Canvas.ForceUpdateCanvases();overlay.Refresh();
  cam.Render();RenderTexture.active=rt;var texture=new Texture2D(rt.width,rt.height,TextureFormat.RGB24,false);
  texture.ReadPixels(new Rect(0,0,rt.width,rt.height),0,0);texture.Apply();File.WriteAllBytes(Output+"/"+name+".png",texture.EncodeToPNG());
  cam.targetTexture=null;RenderTexture.active=null;UnityEngine.Object.DestroyImmediate(texture);rt.Release();UnityEngine.Object.DestroyImmediate(rt);
 }
}
