from pathlib import Path
import csv, hashlib, json, re, shutil, subprocess, zipfile
from PIL import Image, ImageDraw, ImageFont
root=Path.cwd(); work=root/'.context/scene-presentation'
run=sorted((work/'footage').glob('run-*/summary.json'))[-1].parent
out=root/'docs/benchmarks/church-presentation-2026-10-22'; out.mkdir(parents=True,exist_ok=True)
summary=json.loads((run/'summary.json').read_text()); assert summary['maxRouteDeltaMetres']==0
styles=['PolishedLowPoly','Realistic']; routes=[]; proof={}
for style in styles:
    rows=list(csv.DictReader((run/style/'route.csv').open(encoding='utf-8-sig'))); routes.append(rows)
    assert all(row['grounded']=='1' for row in rows)
    poses=len({row['bonePose'] for row in rows}); assert poses>100
    assert max(float(row['animationTime']) for row in rows)>3
    videos={}
    for src in (run/style).glob('*.mp4'):
        data=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(src)]))
        assert len(data['streams'])==1
        v=data['streams'][0]; assert v['codec_type']=='video' and (v['width'],v['height'])==(1280,720)
        assert v['r_frame_rate']=='24/1' and int(v['nb_frames'])==192
        assert abs(float(data['format']['duration'])-8)<.01
        shutil.copy2(src,out/src.name); videos[src.name]={'frames':192,'width':1280,'height':720,'fps':24,'seconds':8,'audioStreams':0}
    shutil.copy2(run/style/'route.csv',out/(style+'-route.csv'))
    proof[style]={'ticks':len(rows),'distinctBonePoses':poses,'allTicksGrounded':True,'videos':videos}
assert routes[0]==routes[1]
def blocks(s):
    return {m.group(2):(int(m.group(1)),'\n'.join(v.rstrip() for v in m.group(3).splitlines())) for m in re.finditer(r'^--- !u!(\d+) &(\d+)(.*?)(?=^--- !u!|\Z)',s,re.M|re.S)}
before=blocks(subprocess.check_output(['git','show','86d475a:Assets/Scenes/Church.unity'],text=True)); after=blocks((root/'Assets/Scenes/Church.unity').read_text())
checks={}
for name,classes in [('colliders',(64,65,135,136,143)),('mesh filters',(33,))]:
    ids=[k for k,v in before.items() if v[0] in classes]; assert all(before[k]==after[k] for k in ids),name
    checks[name]=len(ids)
for name in ['AcousticSurface','SceneSession','RayTraceManager','MultiplayerSession']:
    meta=next((root/'Assets/Scripts').rglob(name+'.cs.meta')); guid=re.search(r'guid: (.*)',meta.read_text()).group(1)
    ids=[k for k,v in before.items() if guid in v[1]]; assert all(before[k]==after[k] for k in ids),name
    checks[name]=len(ids)
transform_count=0
for k,(kind,body) in before.items():
    if kind!=4:continue
    for field in ['m_LocalPosition','m_LocalRotation','m_LocalScale','m_Father']:
        pattern=r'^  '+field+r':.*$'; a=re.search(pattern,body,re.M); b=re.search(pattern,after[k][1],re.M)
        if not a and not b: continue # Stripped prefab references inherit their asset transform.
        assert a and b and a[0]==b[0],(k,field)
    transform_count+=1
checks['existing transforms']=transform_count
proof.update({'sceneBaseline':'86d475a','unchangedAuthoredComponents':checks,'identicalFullRouteCsv':True,'maxRouteDeltaMetres':0,'captureRun':run.name})
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',28)
small=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',20)
canvas=Image.new('RGB',(1600,1000),'#141a20'); draw=ImageDraw.Draw(canvas)
for c,(style,label) in enumerate(zip(styles,['Low-poly style','Realistic / textured PBR'])):
    draw.text((c*800+18,10),label,font=font,fill='white')
    for r,(view,label) in enumerate([('first-person','Listener / first person'),('third-person','Animation / third person')]):
        frame=Image.open(run/(style+'-'+view+'-mid.png')).convert('RGB').resize((800,450),Image.Resampling.LANCZOS)
        canvas.paste(frame,(800*c,50+475*r)); draw.text((800*c+12,501+475*r),label,font=small,fill='#d5dce5')
canvas.save(out/'comparison.png')
conductor=Path('/Users/clarkpeng/conductor/workspaces/realisticaudioraytracing2d/tyler/.context')
shutil.copy2(out/'comparison.png',conductor/'church-styles.png')
# Keep portable artifact paths, not this machine's raw-frame directory paths.
for capture in summary['captures']:
    for key in ['framesDirectory','thirdPersonFramesDirectory']:capture.pop(key,None)
    for key in ['moviePath','thirdPersonMoviePath']:capture[key]=Path(capture[key]).name
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'verification.json').write_text(json.dumps(proof,indent=2)+'\n')
with zipfile.ZipFile(out/'investigation.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in work.glob('*.log'):z.write(p,'logs/'+p.name)
    for p in [root/'.context/gpu-audio/runner/Assets/Editor/ChurchAnimationProbe.cs',work/'publish.py']:
        z.write(p,p.name)
    for name in ['run-20261023-005540/Realistic-third-person-mid.png','run-20261023-005759/Realistic-third-person-mid.png']:
        p=work/'smoke'/name; z.write(p,'early-checks/'+name.replace('/','-'))
paths=[root/'Assets/Scenes/Church.unity',root/'Assets/Editor/ChurchPresentationCapture.cs',root/'Assets/Shaders/ChurchPresentationGrade.shader']+list((root/'Assets/Scripts/Demo').glob('Church*.cs'))
source={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.name!='manifest.json'}
(out/'manifest.json').write_text(json.dumps({'sourceBase':'86d475a','sourceSha256':source,'artifactSha256':files},indent=2)+'\n')
print(json.dumps(proof,indent=2))
print('Published',out)
