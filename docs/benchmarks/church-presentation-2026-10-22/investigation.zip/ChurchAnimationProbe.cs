using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
public static class ChurchAnimationProbe
{
    public static void Run()
    {
        ChurchPresentationCapture.Install();
        EditorSceneManager.OpenScene("Assets/Scenes/Church.unity");
        var a=Object.FindFirstObjectByType<ChurchAvatarPresenter>().animator;
        Debug.Log("ANIM_PROBE "+a.name+" enabled="+a.enabled+" active="+a.gameObject.activeInHierarchy+" avatar="+a.avatar+" valid="+(a.avatar!=null&&a.avatar.isValid)+" controller="+a.runtimeAnimatorController+" initialized="+a.isInitialized);
        foreach(var c in a.runtimeAnimatorController.animationClips)
        {
            var bindings=AnimationUtility.GetCurveBindings(c);
            Debug.Log("CLIP "+c.name+" legacy="+c.legacy+" loop="+c.isLooping+" length="+c.length+" bindings="+bindings.Length);
            for(int i=0;i<Mathf.Min(5,bindings.Length);i++)Debug.Log("BIND "+bindings[i].path+" "+bindings[i].propertyName+" exists="+(a.transform.Find(bindings[i].path)!=null));
        }
        var r=a.GetComponentInChildren<SkinnedMeshRenderer>(true);
        Debug.Log("RENDER "+r.enabled+" "+r.bounds+" root="+a.transform.position+" scale="+a.transform.lossyScale);
        a.Rebind();a.Update(0);a.SetFloat("Speed",6);
        for(int i=0;i<10;i++){a.Update(.2f);Debug.Log("POSE "+a.GetCurrentAnimatorStateInfo(0).normalizedTime+" speed="+a.GetFloat("Speed")+" initialized="+a.isInitialized+" bounds="+r.bounds+" root="+a.transform.position+" scale="+a.transform.lossyScale+" bone="+r.bones[4].localRotation);}
        foreach(var bone in r.bones)Debug.Log("BONE "+bone.name+" rot="+bone.localRotation+" pos="+bone.localPosition+" scale="+bone.localScale);
    }
}
