"""Sequential low-priority field preparation, GPU measurement and parity checks."""
import json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
import gpu_routes as gpu
budget=int(sys.argv[1]);cases=[]
for n in (1,9,25):
    name=f'planar-{n}-n{budget}';target=OUT/name
    gpu.prepare(target,ROOT/f'.context/spatial-accuracy/planar-{n}/scene.json',budget,2,17,250,cpu=budget==65536)
    cases.append(str(target.relative_to(ROOT)))
controls=json.loads((OUT/'control-cases.json').read_text()) if budget==65536 else []
subprocess.run([sys.executable,str(OUT/'run.py'),*controls,*cases],cwd=ROOT,check=True)
for case in controls+cases:gpu.check(ROOT/case)
