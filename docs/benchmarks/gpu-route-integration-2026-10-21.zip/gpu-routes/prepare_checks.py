import importlib.util,json,sys,time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
import edge_integral as edge
import gpu_routes as gpu
spec=importlib.util.spec_from_file_location('before',OUT/'edge-before.py')
before=importlib.util.module_from_spec(spec);spec.loader.exec_module(before)
c=json.loads((ROOT/'.context/spatial-accuracy/planar-1/scene.json').read_text())
points=np.array(c['points']).reshape(-1,3)[[0,504,688]]
for mode in [False,True]:
 for depth in [2,4]:
  a=before.sampled(c,points,250,64,17,depth,route_budget=mode)
  b=edge.sampled(c,points,250,64,17,depth,route_budget=mode)
  for x,y in zip(a,b):np.testing.assert_array_equal(x,y)
checks=edge.validate();gpu.save(OUT/'cpu-controls.json',dict(checks=checks,refactorBitExactCases=4,sourceSha256=gpu.sha(ROOT/'tools/edge_integral.py')))
print('CPU controls passed',len(checks),'and four bit-exact refactor cases',flush=True)
cases=[]
for name,config,depth,n,hz in [
 ('empty',dict(c,walls=[]),4,32,250),
 ('no-support',dict(c,maximumDelaySeconds=.0001),2,32,250),
 ('first-order',c,1,256,250),
 ('dc',c,2,256,0),
 ('four-edges',c,4,256,250),
 ('route-subset',json.loads((ROOT/'.context/spatial-accuracy/planar-9/scene.json').read_text()),4,64,250)]:
 path=OUT/(name+'-scene.json');gpu.save(path,config)
 gpu.prepare(OUT/name,path,n,depth,17,hz,[0,111,504],cpu=True,capture=True)
 cases.append(str((OUT/name).relative_to(ROOT)))
gpu.save(OUT/'control-cases.json',cases)
