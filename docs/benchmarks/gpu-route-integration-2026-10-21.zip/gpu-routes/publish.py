import json,shutil,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent;DEST=ROOT/'docs/benchmarks'
import sys
sys.path.insert(0,str(ROOT/'tools'));import gpu_routes as gpu
summary=json.loads((OUT/'summary.json').read_text())
latest=max(OUT.glob('gpu-*.xml'),key=lambda p:p.stat().st_mtime);test=ET.parse(latest).getroot()
assert test.get('result')=='Passed' and int(test.get('passed'))==13 and int(test.get('failed'))==0
stamp=latest.stem.removeprefix('gpu-');provenance=json.loads((OUT/f'provenance-{stamp}.json').read_text())
for p,sha in provenance['files'].items():assert gpu.sha(ROOT/p)==sha,p
cpu=json.loads((OUT/'cpu-controls.json').read_text());assert cpu['sourceSha256']==gpu.sha(ROOT/'tools/edge_integral.py')
summary.update(date='2026-10-21',sourceFiles={p:gpu.sha(ROOT/p) for p in [
    'tools/edge_integral.py','tools/gpu_routes.py','Assets/Tests/Editor/RouteIntegration.compute','Assets/Tests/Editor/RouteIntegrationChecks.cs']},
    unityValidation=dict(passed=13,failed=0,skipped=0,seconds=float(test.get('duration')),file=latest.name),
    cpuControls=cpu,numericalNote='CDF angular span uses a bounded atan series after two half-angle reductions; final 115-case GPU check: native atan2 max absolute error 1.1465947491906547e-5 rad, stable span 2.4438101942081403e-7 rad.')
gpu.save(OUT/'summary.json',summary)
stem='gpu-route-integration-2026-10-21'
shutil.copy2(OUT/'summary.json',DEST/f'{stem}.json');shutil.copy2(OUT/'gpu-route-maps.png',DEST/f'{stem}.png')
with zipfile.ZipFile(DEST/f'{stem}.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for f in sorted(OUT.rglob('*')):
        if not f.is_file() or '__pycache__' in f.parts or f.suffix=='.log':continue
        if f.name=='requests.bin' and f.stat().st_size>1024*1024:continue
        archive.write(f,'gpu-routes/'+str(f.relative_to(OUT)))
    for p in summary['sourceFiles']:archive.write(ROOT/p,'source/'+p)
quality=[];cost=[]
for c in summary['cases']:
    low,high=c['budgets'];n=c['scene'].split('-')[1]
    quality.append(f"| {n} | {c['probes']} | {low['quality']['complexL2']*100:.2f}% | {high['quality']['complexL2']*100:.2f}% | {low['quality']['within3dB']*100:.1f}% → {high['quality']['within3dB']*100:.1f}% |")
    cost.append(f"| {n} | {low['cpuPreparationSeconds']:.3f} | {low['cpuIntegrationSeconds']:.3f} | {low['preparedGpuStageSeconds']:.3f} | {high['preparedGpuStageSeconds']:.3f} | {c['sharedCpuConnectionSeconds']:.3f} |")
section=f'''## Complete-route GPU integration — 2026-10-21

**The offline pure-edge integrator is now ported to HLSL.** At 65,536 samples per receiver, its complex-pressure result matches the CPU to 0.00237–0.00244% relative L2 across all 2,854 receiver positions. CPU route planning is shared; it has not been moved to the GPU. Direct/mirror/mixed computation also remains a separate CPU stage. The live renderer is unchanged.

![Full 2D maps of the GPU port at two budgets](benchmarks/{stem}.png)

### What runs where

```text
CPU: count visible continuations; choose complete routes and their weights
CPU: prepare route geometry and shared Sobol sample coordinates
GPU: each thread samples heights along one already-selected complete route
     evaluate signed edge kernels, distance spreading, delay/phase and PDF weight
GPU: parallel reduction to one complex pressure value per receiver/frequency
CPU: add the separate direct, mirror and mixed-path field for these map comparisons
```

`tools/edge_integral.py` extracts its existing route-allocation block into one shared generator; four before/after comparisons remain bit-identical. `tools/gpu_routes.py` prepares binary inputs and checks results. The editor-only `RouteIntegration.compute` and `RouteIntegrationChecks.cs` implement the numerical GPU stage and its opt-in runner. No additional package, live component or runtime mode is introduced. The port does not implement the optional CPU control-variate/roulette modes.

The shader uses two dispatches, deterministic tree reduction and no floating-point atomics. It does not store every arrival: normal readback is eight bytes of complex pressure plus a four-byte numerical-error flag per position. Height draws are shared across routes, as in the CPU implementation. Route depth is supplied in the descriptors, not fixed to two by the shader; full fields here use depth two and numerical controls exercise depth four.

### Physical accuracy with more samples

Same existing 12 × 11 m point-source/extruded-wall layouts, rigid boxes, 250 Hz, 0.4 s support and seed 17. All routes fit these two-order field budgets, so every route is covered and its heights are sampled. No amplitude fitting, pressure clipping, shortest-path replacement or diffraction disable. CPU and GPU receive the same float-representable Sobol coordinates for parity; these differ slightly from the earlier all-double experiment. All candidate fields add the identical cached order-eight-quadrature direct/mirror/mixed field from the CPU study.

| Boxes | Receivers | Complex error, 65,536 | Complex error, 1,048,576 | Within ±3 dB: low → high |
|---:|---:|---:|---:|---:|
{chr(10).join(quality)}

More samples improve the larger layouts in this run, but they remain far from high-fidelity references. The one-box result nearly plateaus. These are one-seed full-map measurements, not a convergence proof. Two-order truncation and the unchanged physical/mixed-path approximation still limit accuracy; increasing samples cannot establish their correctness. Finite 3D, motion, broadband audio and training-data qualification remain untested.

### Performance, with the CPU costs visible

Apple M5 / Metal, Unity 6000.4.1f1, one low-priority worker, no windows or audio. Median warm GPU integration/reduction plus readback is **0.228–0.230 ms** at 65,536 samples and **0.976–1.172 ms** at 1,048,576 samples, per position at one frequency. These are synchronous wall-clock timings, not GPU timestamps or full-band real-time costs. Buffer allocations total 1.01–1.11 MiB at the lower budget and 16.13–16.23 MiB at the higher budget, including uploaded random draws and route geometry, excluding driver memory.

The following seconds cover each whole map. Prepared GPU stage includes input decoding, uploads, integration, reduction and readback. Cold compilation, allocation and the one-time random upload are outside its warm timings. CPU integration is `sample_chain` work with its per-route setup, excluding the separately timed route preparation. It is not an end-to-end speedup claim.

| Boxes | CPU preparation, 65,536 | CPU integration, 65,536 | Prepared GPU stage, 65,536 | Prepared GPU stage, 1,048,576 | Separate CPU direct/mirror/mixed |
|---:|---:|---:|---:|---:|---:|
{chr(10).join(cost)}

The last column was measured in the preceding CPU study and cached for these comparisons; it was not recomputed inside the GPU timings. CPU route preparation and the mixed-path stage now dominate larger-scene total cost. The numerical port makes additional height samples inexpensive, but does not make the entire pipeline real-time. CPU integration was not rerun at the million-sample budget.

### Validation and numerical changes

**13 final Unity cases pass, zero failed/skipped:** six prepared numerical controls, six full-field measurements and an atomic CDF-angle control with 115 arguments. Separate Python checks verify every captured sample in the six controls and all 2,854 CPU/GPU field values at 65,536 samples. Controls cover empty scenes, exhausted physical support, first-order transport, DC, four-interaction routes and route-subset probability weights. The existing **28 CPU numerical controls** and four bit-identical refactor comparisons also pass.

The initial float port failed the longer-route sample comparison. The accepted implementation uses a factored ellipse intersection, positive-weight endpoint interpolation for the truncated Cauchy draw, and a more accurate angular-span evaluation. The span reduces atan's argument twice before a 19th-order series (less than 2e-9 rad truncation error before float rounding). The independent GPU angle check measures maximum absolute errors of 1.15e-5 rad for native `atan2` and 2.44e-7 rad for the replacement on these arguments. Final per-control aggregate parity error is at most 0.00393%. This is a numerical reformulation of the same sampling distribution, not pressure clipping or a changed physical kernel.

Metal still emits a potential-uninitialized-return warning at the zero-depth early return; the empty/exhausted-support cases return exact zeros, and all measured samples pass finite-value checks. The raw compiler/test evidence is retained through the final test XML. No suppression or weakened parity tolerance was used to pass the controls.

### Reproduce

Prepare a case with NumPy/SciPy, using a fresh output directory:
```sh
python tools/gpu_routes.py prepare /tmp/route-case --scene /path/to/scene.json \\
  --samples 65536 --depth 2 --seed 17 --hz 250 --cpu
```
Put `/tmp/route-case` on a line in a case-list file. In an isolated copy of the Unity project, set `ACOUSTIC_ROUTE_CASES` to that file and run EditMode tests filtered to `TakeChecks.MeasureCompleteRoutes;TakeChecks.RouteAnglesMatchReference`, using `-batchmode -force-metal -disable-audio -job-worker-count 1`. Then run `python tools/gpu_routes.py check /tmp/route-case`. `--capture` additionally records individual sample contributions for small numerical controls.

[Measurement ledger](benchmarks/{stem}.json) · [Raw fields, control inputs, tests, source snapshots and reproduction scripts](benchmarks/{stem}.zip). Large full-grid request buffers are reproducible from the retained scene/seed/configuration and are omitted from the archive; their hashes are retained. Earlier spatial/CPU archives supply the unchanged wave and connection references. Prefer these spatial maps when presenting subsequent results.

'''
doc=ROOT/'docs/cleanup-results.md';text=doc.read_text();heading='# Cleanup validation and measured bottlenecks\n\n'
assert text.startswith(heading) and '## Complete-route GPU integration — 2026-10-21' not in text
doc.write_text(heading+section+text[len(heading):]);print('Published',stem)
