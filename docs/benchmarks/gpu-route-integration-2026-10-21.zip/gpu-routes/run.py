"""Run only the opt-in route integration fixture in the silent isolated editor."""
import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[2]; OUT=Path(__file__).resolve().parent
runner=ROOT/'.context/gpu-audio/runner'
if (runner/'Temp/UnityLockfile').exists():raise RuntimeError('Runner is open')
files=[Path('Assets/Tests/Editor')/n for n in ['RouteIntegration.compute','RouteIntegration.compute.meta','RouteIntegrationChecks.cs','RouteIntegrationChecks.cs.meta']]
for p in files:
    if (runner/p).exists():raise FileExistsError(runner/p)
cases=[str((ROOT/n).resolve()) for n in sys.argv[1:]]
if not cases:raise ValueError('Pass prepared case directories')
stamp=time.strftime('%H%M%S');casefile=OUT/f'cases-{stamp}.txt';casefile.write_text('\n'.join(cases)+'\n')
provenance=dict(cases=cases,files={str(p):hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in files},
    sourceHead=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip())
(OUT/f'provenance-{stamp}.json').write_text(json.dumps(provenance,indent=2)+'\n')
for p in files:shutil.copy2(ROOT/p,runner/p)
try:
    result=subprocess.run(['nice','-n','15','/Applications/Unity/Hub/Editor/6000.4.1f1/Unity.app/Contents/MacOS/Unity',
        '-batchmode','-force-metal','-disable-audio','-job-worker-count','1','-projectPath',str(runner),'-runTests',
        '-testPlatform','EditMode','-testFilter','TakeChecks.MeasureCompleteRoutes;TakeChecks.RouteAnglesMatchReference',
        '-testResults',str(OUT/f'gpu-{stamp}.xml'),'-logFile',str(OUT/f'gpu-{stamp}.log')],
        env=dict(os.environ,ACOUSTIC_ROUTE_CASES=str(casefile)),timeout=1200)
    test=ET.parse(OUT/f'gpu-{stamp}.xml').getroot()
    assert result.returncode==0 and test.get('result')=='Passed' and int(test.get('passed'))==len(cases)+1,test.attrib
    print('GPU cases passed',cases,flush=True)
finally:
    for p in files:(runner/p).unlink(missing_ok=True)
