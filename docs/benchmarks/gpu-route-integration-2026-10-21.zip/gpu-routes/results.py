"""Full spatial maps first; identical CPU geometric fields on both GPU budgets."""
import ast,json,shutil,zipfile
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
BASE=ROOT/'.context/spatial-accuracy';COMMON=ROOT/'.context/route-monte-carlo'
DEST=Path('/Users/clarkpeng/conductor/workspaces/realisticaudioraytracing2d/tyler/.context')
import sys
sys.path.insert(0,str(ROOT/'tools'));import gpu_routes as gpu

def metrics(value,ref):
    floor=np.sqrt(np.mean(abs(ref)**2))*1e-6
    delta=20*np.log10(np.maximum(abs(value),floor)/np.maximum(abs(ref),floor))
    return dict(complexL2=float(np.linalg.norm(value-ref)/np.linalg.norm(ref)),
        within3dB=float(np.mean(abs(delta)<=3)),medianAbsDb=float(np.median(abs(delta))))

fig,axes=plt.subplots(3,3,figsize=(13,12.5),layout='constrained')
cmap=plt.colormaps['magma'].with_extremes(over='#27c9bd',under='#050505',bad='#e5e7eb')
summary=dict(scope='Stationary rigid planar boxes, 250 Hz, seed 17, pure edges through order two. GPU integration plus identical cached CPU direct/mirror/mixed fields.',
    limitations=['CPU route selection/preparation and direct/mirror/mixed computation remain outside the GPU kernel.',
        'One frequency, no DSP, binaural, dynamic geometry or finite-3D qualification.',
        'One seed on full maps; more rays do not remove model truncation or guarantee convergence.',
        'Wave reference has previously measured mesh convergence, not a certified physical error bound.'],cases=[])
for row,n in enumerate((1,9,25)):
    name=f'planar-{n}';c=json.loads((BASE/name/'scene.json').read_text())
    reference=np.load(BASE/name/'reference-0.35-250.npz')['pressure']
    common=np.load(COMMON/f'{name}-connections-full.npz')
    cm=json.loads((COMMON/f'{name}-connections-full.json').read_text())
    assert cm['sceneSha256']==gpu.sha(BASE/name/'scene.json') and cm['hz']==250 and cm['depth']==2
    shared=common['pressure'].sum(axis=1)
    fields=[reference];item=dict(scene=name,probes=len(reference),sharedCpuConnectionSeconds=cm['seconds'],budgets=[])
    for budget in (65536,1048576):
        p=OUT/f'{name}-n{budget}';meta=json.loads((p/'metadata.json').read_text());checked=json.loads((p/'checked.json').read_text())
        assert meta['sceneSha256']==gpu.sha(BASE/name/'scene.json') and meta['depth']==2 and meta['seed']==17 and meta['hz']==250
        cpu=np.load(p/'cpu.npz');np.testing.assert_array_equal(cpu['indices'],common['indices'])
        np.testing.assert_array_equal(cpu['points'],common['points'])
        data=np.genfromtxt(p/'gpu.csv',delimiter=',',names=True);np.testing.assert_array_equal(data['point'],np.arange(len(reference)))
        value=data['real']+1j*data['imag']+shared;fields.append(value)
        info=dict(checked,quality=metrics(value,reference))
        if cpu['computed']:info['cpuQuality']=metrics(cpu['pressure']+shared,reference)
        info['preparedGpuStageSeconds']=checked['gpuSolveSeconds']+checked['uploadSeconds']+checked['inputSeconds']
        info['plannedGpuStageSeconds']=info['preparedGpuStageSeconds']+checked['cpuPreparationSeconds']
        item['budgets'].append(info)
    for col,(value,title) in enumerate(zip(fields,['Wave reference','GPU port · 65,536 samples','GPU port · 1,048,576 samples'])):
        floor=np.sqrt(np.mean(abs(reference)**2))*1e-6;level=20*np.log10(np.maximum(abs(value),floor))
        grid=np.full(len(c['x'])*len(c['y']),np.nan);grid[c['gridIndices']]=level
        ax=axes[row,col];im=ax.pcolormesh(c['x'],c['y'],grid.reshape(len(c['y']),len(c['x'])),cmap=cmap,vmin=-40,vmax=5,shading='nearest')
        for wall in c['walls']:
            center,half=np.array(wall['center'][:2]),np.array(wall['half'][:2])
            ax.add_patch(Rectangle(center-half,*(2*half),facecolor='#515962',edgecolor='white',linewidth=.6))
        ax.scatter(*c['source'][:2],marker='*',s=125,color='#00a8ff',edgecolor='black',linewidth=.6,zorder=5)
        ax.set(xlim=(-6.9,6.25),ylim=(-5.7,5.7),xlabel='x (m)',ylabel='y (m)');ax.set_aspect('equal')
        ax.set_title(f"{n} {'box' if n==1 else 'boxes'} · {title}",fontsize=11)
        if col:
            q=item['budgets'][col-1]['quality']
            ax.text(.025,.025,f"{q['complexL2']*100:.2f}% complex error · {q['within3dB']*100:.1f}% within ±3 dB",transform=ax.transAxes,fontsize=8.5,
                    bbox=dict(facecolor='white',alpha=.92,edgecolor='none',pad=3))
    fig.colorbar(im,ax=list(axes[row]),shrink=.77,pad=.02,extend='both',label='Pressure level (dB re unit pressure)')
    np.savez_compressed(OUT/f'{name}-fields.npz',pressure=fields,points=common['points'],cpu=np.load(OUT/f'{name}-n65536/cpu.npz')['pressure']+shared)
    summary['cases'].append(item)
fig.suptitle('Complete-route GPU port · 2D spatial pressure maps · 250 Hz\nSame source, pressure scale and two-interaction model; 16× more samples on the right',fontsize=15)
fig.supxlabel('Blue star: source · Grey blocks: obstacles · Turquoise: above +5 dB\n'
    'Pure-edge integration runs on GPU. All candidate maps add the same cached CPU direct/reflection/mixed field.',fontsize=10)
fig.savefig(OUT/'gpu-route-maps.png',dpi=155);plt.close(fig);shutil.copy2(OUT/'gpu-route-maps.png',DEST/'gpu-route-maps.png')
summary['controls']={name:json.loads((OUT/name/'checked.json').read_text()) for name in ['empty','no-support','first-order','dc','four-edges','route-subset']}
gpu.save(OUT/'summary.json',summary)
for item in summary['cases']:
    for b in item['budgets']:
        print(item['scene'],b['samples'],'wave error %',b['quality']['complexL2']*100,'solve ms',b['medianSolveMs'],
              'CPU prep s',b['cpuPreparationSeconds'],'GPU full grid s',b['preparedGpuStageSeconds'],'bytes',b['gpuBytes'],flush=True)
