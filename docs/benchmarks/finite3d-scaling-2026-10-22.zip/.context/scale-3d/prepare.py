import json,math
from pathlib import Path
import numpy as np
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1]
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def box(c,h,rot=0):return dict(center=list(map(float,c)),half=list(map(float,h)),rotation=[0,0,rot])
for side in (1,4,8,16,32,64):
 walls=[];hx=(side-1)*1.75+2;hy=(side-1)*1.5+2
 for x in ((np.arange(side)-(side-1)/2)*3.5):
  for y in ((np.arange(side)-(side-1)/2)*3):
   for dx in (-.95,.95):
    for dy in (-.5,.5):walls.append(box([x+dx,y+dy,1.6],[.06,.06,1.6]))
   for z in (.4,1.5,2.6):walls.append(box([x,y,z],[1.05,.6,.05]))
   walls.append(box([x-.4,y,1.75],[.23,.23,.2],20));walls.append(box([x+.35,y,2.85],[.22,.22,.2],-30))
 for c,h in (([0,0,-.15],[hx+.3,hy+.3,.15]),([0,0,4.95],[hx+.3,hy+.3,.15]),([-hx-.15,0,2.4],[.15,hy,2.4]),([hx+.15,0,2.4],[.15,hy,2.4]),([0,-hy-.15,2.4],[hx,.15,2.4]),([0,hy+.15,2.4],[hx,.15,2.4])):walls.append(box(c,h))
 source=[-hx+.4,-hy+.45,1.6];points=[[hx-.4,-hy+.45,1.6],[-hx+.45,hy-.4,1.6],[hx-.4,hy-.4,1.6],[0,-hy+.5,3.8],[0,hy-.5,.8]]
 path=OUT/f'hall-{side}';path.mkdir(exist_ok=True);save(path/'scene.json',dict(name=path.name,physicalModel='finite3d-box-interior',source=source,points=np.array(points).ravel().tolist(),walls=walls,extent=[hx*2,hy*2,4.8],rays=[256,1024],seeds=[17],maxBounces=8,sampleRate=500,fftSize=4,frequencyBins=[0,125,250],repeat=3,moveOwner=8,maximumDelaySeconds=.4))
# Reuse the independently solved finite room for spatial accuracy; same boundary mesh.
p=OUT/'room-map';p.mkdir(exist_ok=True);original=ROOT/'.context/spatial-accuracy/room-12m-25';c=json.loads((original/'renderer-scene.json').read_text());c.update(name='room-map',rays=[256,1024],seeds=[17],repeat=1,moveOwner=-1);save(p/'scene.json',c)
# Keep all receivers within the acoustic horizon in the largest geometry control.
c=json.loads((OUT/'hall-64/scene.json').read_text());c.update(name='hall-64-local',rays=[1024])
c['points']=(np.array(c['source'])+np.array([[4,0,0],[8,0,0],[0,4,0],[0,8,0],[4,4,2]])).ravel().tolist()
p=OUT/'hall-64-local';p.mkdir(exist_ok=True);save(p/'scene.json',c)
print('Prepared six finite warehouse layouts, nearby-listener control and existing finite-room accuracy map')
