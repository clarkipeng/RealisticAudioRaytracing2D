# Finite 3D geometry scaling — 22 October 2026

This archive preserves the original production 3D sampler, a material-query BVH optimization, and a pose-cache optimization. It does NOT port the newer bounded 2.5D complete-route estimator. Pressure error remains very large; read `docs/acoustic-experiment-history.md` before interpreting the speedups as audio quality.

Base checkout: `a24de93340ff6c52b08021029ea252e4ab7e6444`. Material-query commit: `2d9f3fb`. The accompanying Git commit contains the final pose cache and reports. `production/Assets/...` contains exact final tested files. Before/intermediate snapshots and SHA-256 provenance preserve stages independently of commit granularity.

## Contents and provenance

- `hall-{1,4,8,16,32,64}/scene.json`: finite warehouse geometry with six enclosure solids; 12 triangles per solid. `baseline.csv`, `accelerated.csv`, `cached.csv`: original, medium-BVH-only, and medium-BVH plus pose cache.
- `hall-64-local`: largest geometry, five probes 4–8 m from source, baseline/final only. This qualifies the fixed-horizon concern in the scale series. All probes are outside solids and have nonzero pressure, but no wave accuracy reference exists for this warehouse.
- `room-map`: existing finite-room geometry, 1,060 spatial probes and three-stage measured fields. Original wave scene, renderer mesh, two refinements at 62.5/125 Hz, reference metadata and solver source are archived under their original repo-relative paths.
- `Scale3D.cs`, `Scale3DReduce.compute`: silent batch measurement and GPU reduction. `Scale3D.before.cs` preserves the first fixture before naming output by environment variable. The numerical workload is unchanged by that filename change.
- `Transport.before.hlsl`, `Transport.accelerated.hlsl`, `DirectBvh.before.cs`, `DirectBvh.accelerated.cs`: explicit before/after implementations. `Geometry.hlsl` unchanged. Native-volume test snapshots and standalone `MediumBvhChecks.cs` match the experiment's staged test suite; the latter is now integrated into final `RayTransportChecks.cs`.
- `gpu-145426.xml` / `gpu-145534.xml`: original baseline cases. `gpu-145959.xml`: final material stage plus controls. `gpu-151812.xml`: pose-cache stage plus geometry controls. `production-152056.xml`: 14 final integrated production tests. `gpu-152250.xml` / `gpu-152405.xml`: nearby baseline/final.
- `first-trial/` plus `gpu-145750.*` / matching provenance: exploratory material-BVH trial, not included in headline totals. Its point-bounds test produced division-by-zero compiler warnings; final version compares bounds directly. Existing unrelated shader warnings remain in final logs.
- `provenance-*.json`: source/fixture/case hashes recorded before runs. Where overrides are present, `transportShaderSha256`, `nativeTestSha256`, `bvhSha256` identify effective staged versions; the `runtime` map is the pre-staging checkout. Early baseline metadata has no variant field. The `cases-*.txt` files preserve original absolute paths as provenance; regenerate for another checkout.
- `summary.json`, `room-fields.npz`, `analyze.py`, `plots.py`: numerical analysis and figure sources. PNGs and the readable ledger live in `docs/benchmarks`. `manifest.sha256.json` verifies archive members.

## Reproduction

1. Use an isolated checkout of the base revision, overlay the four `production/Assets` snapshots, and restore this archive's repo-relative `.context/scale-3d`, `.context/spatial-accuracy/room-12m-25`, `tools/room_wave.py` and figure files. Do not switch a user's open Unity checkout for this purpose.
2. Prepare a separate Unity project copy at `.context/gpu-audio/runner` with matching `Assets`, `Packages` and `ProjectSettings`. Unity 6000.4.1f1 with Metal and a valid editor license is required. Existing dependencies come from the Git checkout; this archive adds none. Close that runner before testing. The scripts verify matching source files and restore temporary overrides in `finally`.
3. Python analysis uses NumPy and matplotlib. The existing experiment environment was `.context/wave-planar/venv/bin/python`. Set `OPENBLAS_NUM_THREADS=1`, `VECLIB_MAXIMUM_THREADS=1`, `OMP_NUM_THREADS=1`, `PYTHONDONTWRITEBYTECODE=1`; use `nice -n 15`. No new wave solve is needed to reproduce analysis; generating references afresh additionally needs NGSolve 6.2.2608.
4. Copy/move the archived results to a separate evidence directory before rerunning: `run.py` refuses to overwrite a target CSV. From the repo root run, one process at a time:

```text
python .context/scale-3d/run.py hall-1 hall-4 hall-8 hall-16 hall-32 hall-64 room-map
python .context/scale-3d/run.py --accelerated --checks hall-1 hall-4 hall-8 hall-16 hall-32 hall-64 room-map
python .context/scale-3d/run.py --pose-cache --geometry-checks hall-1 hall-4 hall-8 hall-16 hall-32 hall-64 room-map
python .context/scale-3d/run.py hall-64-local
python .context/scale-3d/run.py --pose-cache hall-64-local
python .context/scale-3d/validate.py
python .context/scale-3d/analyze.py
python .context/scale-3d/plots.py
```

All Unity commands use batch mode, Metal, disabled audio, one worker and reduced priority. They do not create player windows or route sound to speakers. Adjust the hardcoded Unity executable and optional Conductor image-copy destination for other machines. Do not run heavy jobs concurrently. `prepare.py` recreates inputs; archived scene hashes let you verify regeneration. `run-baseline.py` and `report.py` are historical helpers, not necessary replay commands; the report helper is a one-time journal insertion, not idempotent.

## Interpreting timing and accuracy

The fixture computes three bins; each CSV has two nonzero-frequency rows sharing the SAME query time. Filter one frequency before aggregating performance; do not sum duplicated times. Warmed query timing includes CPU state upload/preparation, GPU trace and reduction, blocking readback and finite checks. BVH update time is included in upload time. Solver setup excludes JSON parsing and procedural mesh construction; cold dispatch is separate. GPU bytes are allocated buffers; CPU bytes count numeric buffers, not complete process memory.

Scale layouts grow in physical extent with fixed 0.4-second horizon. Large-scene distant probes can have no reachable contribution. The nearby control helps separate object-count overhead from that effect, but fixed rays/bounces still do not imply constant acoustic accuracy. One-crate movement is pose/refit benchmarking, not continuous motion/Doppler validation.

FEM data were reused, not solved during this benchmark. Their two-mesh differences are observed convergence, not certified absolute error. The 3D sampler has ~720% complex-pressure error at 125 Hz and 1,024 rays/bin. The geometry optimizations preserve this result. No broadband synthesis, microphone, multiplayer, listening test or trained upscaler was exercised.
