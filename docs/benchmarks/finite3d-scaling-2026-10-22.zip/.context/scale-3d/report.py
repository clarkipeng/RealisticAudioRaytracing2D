import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]; OUT=ROOT/'.context/scale-3d'
s=json.loads((OUT/'summary.json').read_text())
rows=[x for x in s['scaling'] if x['scene'].startswith('hall') and x['raysPerBin']==1024 and not x['moving']]
table='\n'.join(f"| {r['objects']:,} / {r['triangles']:,} | {r['old']['medianMs']:.2f} | {r['media']['medianMs']:.2f} | {r['new']['medianMs']:.2f} | {r['speedRatio']:.2f}× |" for r in rows)
intro='''# Acoustic experiments: history, 2D maps and GPU scaling

This document is the experiment journal and source material for a process video. The chronology below includes accepted and rejected approaches; the detailed entries retain their assumptions and limitations.

**Checkpoint practice**

Commit each completed experiment or independently validated improvement, and checkpoint before replacing an approach. Keep each hypothesis, settings/seeds, code revision, raw measurements, before/after figures, conclusion and rejected variants together. Small edits within a run can share a checkpoint; do not discard the unsuccessful run when saving a better result. Preserve artifact sources so figures can be regenerated. Use the existing journal and archives rather than another tracking system.

Git preserves committed code, not arbitrary chat history, ignored scratch files or footage that was never captured. Promote useful `.context` evidence into the dated archives linked here before finishing an experiment. Record live footage separately when requested; silent offline results do not imply we captured gameplay video. Inspect old code with `git show REVISION:path` without switching the Unity checkout. `git log --date=short --format='%h %ad %s' -- docs/acoustic-experiment-history.md` finds the journal checkpoints.

**Finite 3D scaling: material lookup and unchanged bounds — 22 October**

The existing production 3D renderer now reuses its BLAS/TLAS to identify the material containing a ray vertex, and skips rebuilding world bounds for unchanged instance poses. The 442,440-triangle static test falls from **339.41 → 58.47 → 12.86 ms** across the original, material-lookup-only and pose-cache stages. This is **26.39× faster in this measured workload**, with unchanged physics to floating-point precision. Runtime changes total **30 net lines across two existing files**; no runtime dependency or new runtime file was added.

This is the older finite-3D path sampler. The recently improved bounded complete-route prototype remains **2.5D** and has not been ported to arbitrary finite 3D. The production sampler still has severe spatial pressure error; faster geometry processing does not establish high fidelity or DLSS teacher quality.

![Finite warehouse test geometry](benchmarks/finite3d-scene-2026-10-22.png)

The scale series contains 15–36,870 closed solids: posts, shelves, rotated crates and an enclosure. Each solid has 12 triangles; the largest interior spans 224.5 × 193 × 4.8 m. This stresses many instances and genuine finite edges, not the surface complexity of a detailed scanned mesh. The independent room accuracy case also exercises a 1,634-triangle aggregate mesh. No playable scene or imported environment was added.

**Two changes, measured separately**

1. **Material containment:** surface rays already used BLAS/TLAS, but `MediumAt` still visited every closed volume and scanned its triangles. It now descends the existing TLAS around the query point, finds each candidate in the owner-sorted volume array, and uses the existing BLAS for the oriented boundary test. Nested media, winding and equal-volume owner priority are retained. No extra spatial index or GPU buffer. The linear fallback remains for correctness checks. GPU change checkpoint: `2d9f3fb`.
2. **Unchanged instance bounds:** after the first change, CPU pose/bounds preparation dominated the largest case. Cache the exact position/quaternion for every owner in every frame of the submitted batch; only changed owners need world-bound transforms. Any changed bounds still trigger a full TLAS refit. This accompanying checkpoint preserves both this change and all three measured stages.

```text
Before, each solve:
    transform all instance bounds; refit/upload TLAS if needed
    trace paths through BLAS/TLAS
    at each material query, scan closed volumes and their triangles

After, each solve:
    compare submitted poses with the previous batch
    transform only changed instance bounds; refit/upload TLAS if needed
    trace the same paths through BLAS/TLAS
    at each material query, use TLAS candidates and BLAS boundary intersection
    reduce pressure on GPU; read back three complex-bin results
```

The last reduction is the offline benchmark fixture, not a change to the live audio output path. It transfers 48 bytes per solve (three float4s, including diagnostic counts), and checks its sum against independent double-precision CPU summation on the smaller cases outside timed measurements.

| Solids / triangles | Original ms | Material BVH only ms | + pose cache ms | Original / final |
|---|---:|---:|---:|---:|
'''+table+'''

One source/listener pair, 1,024 rays per bin, three bins (0/125/250 Hz), up to eight bounces, seed 17, 0.4 s acoustic horizon; five probes × three repeats. The archive also includes 256 rays/bin and one-crate movement. These are host-observed medians including state preparation/submission, tracing, GPU reduction, blocking readback and finite-output checks. They exclude scene JSON/mesh generation, solver setup, cold dispatch, Unity startup, plotting, audio/DSP and networking. Shared M5 Mac, Metal, Unity 6000.4.1f1, one worker, low priority, audio disabled. No GUI/player window, microphone or speakers used.

![Measured 3D runtime and numeric-buffer memory](benchmarks/finite3d-scaling-2026-10-22.png)

At 442,440 triangles, moving one crate between queries gives **323.29 → 78.47 → 32.26 ms** (10.02× original/final). This measures a sequence of poses and BVH updates, not continuous moving-boundary acoustic accuracy. Static GPU allocations remain **94.54 MB**. Accounted CPU numeric buffers rise **30.97 → 32.00 MB**: the pose cache costs 28 bytes per owner per cached frame, 1.03 MB here. Those figures exclude general managed scene storage and Unity/driver memory. Final setup is 2.33 s and the first solve 0.278 s for this case; setup excludes procedural geometry generation.

The material-only stage's largest static CPU preparation is 42.19 ms, including 37.51 ms for bounds/BVH update. With the cache these become **4.34 ms**, including **1.52 ms**. These components overlap: do not add upload and BVH times. Stages ran sequentially on a shared machine; small-case regressions and timing variation are retained, including 2.48 → 4.44 ms at 180 triangles after adding the cache. The 256-ray cases are not consistently faster than 1,024-ray cases. These measurements do not establish universal speedups.

Scene extent grows at fixed object density, while the 0.4 s horizon stays fixed; several largest-scene receivers are outside that horizon. Therefore a separate **442,440-triangle nearby-receiver control** keeps all five probes 4–8 m from the source, outside solids. All 15 queries have nonzero output. Static median is **314.95 → 10.03 ms (31.40×)**; one-crate movement is **310.92 → 17.86 ms (17.41×)**. Pressure is bit-for-bit identical in this supplemental old/final comparison. It supports the geometry saving within the horizon; it is not a reference-accuracy test. The scale-series curve is not a formal acoustic scaling law.

**Accuracy remains the blocker**

![2D pressure slices through the finite 3D room](benchmarks/finite3d-pressure-2026-10-22.png)

These are 1,060 receiver probes on three XY height slices in a finite 12 × 8 × 6 m room with 25 obstacles, normalized-admittance 0.2 enclosure and rigid obstacles. The old and accelerated 3D fields look the same because these changes preserve the estimator. Absolute pressure scale is shared; teal denotes values above +10 dB. There is no amplitude fitting, smoothing or clipping of recorded values.

At 125 Hz and 1,024 rays/bin, relative complex-pressure L2 error is **719.89%** against the independent FEM reference; only **20.85%** of probe amplitudes lie within ±3 dB. At 256 rays/bin error is **2,488.03%**. The sampler has enormous outliers and incomplete/approximate path physics; this experiment does not isolate all causes. More speed or edge simplification alone cannot establish correctness. The bounded 2.5D integrator's better results must not be attributed to this different 3D algorithm.

The two nonzero-frequency fields are produced together: warmed full-map query time at 1,024 rays/bin is **15.64 → 13.03 → 8.65 s** for the three stages, not that amount per frequency. The existing order-4 FEM reference has 80,033 DOFs. Recorded reference costs are mesh 0.246 s plus solve 8.625 s at 62.5 Hz or 8.021 s at 125 Hz, single CPU thread. These are reused reference runs, not newly timed solves. Refinement changes are 0.080% and 0.260%, respectively; those are observed convergence, not certified error bounds or perfect physical truth. A truncated ray model and steady-state FEM solve also differ in path/time support. This is not an equal-accuracy speed comparison.

Across all main cases, the largest old/final relative pressure difference is **0.0000233%**. The pose-cache stage is bit-for-bit identical to the material-only stage. Final integrated validation passes **14 Unity test cases**: 2D/3D nested/overlapping/moving-media parity, native box/sphere/capsule volumes in BVH and linear modes, BVH/refit controls, material-speed Doppler and boundary clocks. Baseline measurement suites pass 3 + 4 cases; material acceleration 17, pose-cache measurement/controls 13, nearby controls 1 + 1. These overlap and must not be summed as unique coverage. Initial exploratory runs and shader warnings are archived too. Existing compiler warnings remain.

**Geometry preprocessing next, without a new runtime subsystem**

Yes: preprocess a dedicated acoustic representation once per unique mesh, then reuse it across instances. First remove representation noise: weld genuinely duplicate positions while retaining material/topology distinctions, exclude coplanar triangle diagonals, and merge collinear wedge segments only when both adjacent faces and materials agree. Rebuild face-to-edge adjacency and compare pressure to the unsimplified version; changing finite segment parameterization can change a sampler even when the visible shape is identical. Current edge extraction already removes coplanar diagonals; it does not implement general acoustic decimation or collinear-wedge merging.

A flat rectangular face has four boundary sides regardless of its interior render triangulation; those internal diagonals are not physical wedges. Additional lossy decimation needs a measured acoustic error budget over the intended frequency range. Preserve doorways, thin barriers, material boundaries, closed winding and meaningful wedges. Wavelength can inform the budget, but “smaller than a wavelength” is not a safe universal deletion rule. An existing mesh simplifier could handle general geometric reduction; its geometric deviation is not an acoustic-error guarantee. For example, meshoptimizer documents duplicate-vertex welding and topology/seam-aware simplification, while its sloppy variant can merge disjoint features and lose borders. No dependency has been added. [Primary implementation documentation](https://github.com/zeux/meshoptimizer#simplification).

These warehouse solids already have only 12 triangles each. Removing shelves, posts or gaps would change physical geometry, so further reduction requires accuracy measurements. Keep preprocessing an offline import/build step, retain the original geometry for comparison, and validate edge counts, memory, build time, runtime and wave-reference pressure together. It cannot repair the large current 3D estimator error by itself.

Remaining measured scaling costs are per-object state packing/comparison, full TLAS refit/upload when any bounds change, and repeated frequency work. BLAS reuse across identical mesh instances and acoustic proxies are useful next candidates, but this task does not implement them. These tests cover three bins, not full-spectrum realtime audio or trained upscaling.

[Complete numerical ledger](benchmarks/finite3d-scaling-2026-10-22.json) · [Code snapshots, scenes, raw CSVs, tests and reference data](benchmarks/finite3d-scaling-2026-10-22.zip).

---

'''
p=ROOT/'docs/acoustic-experiment-history.md';old=p.read_text().split('\n',2)[2];old=old.replace('The latest offline prototype','The preceding offline prototype',1)
old=old.replace('| Latest experiment, 22 Oct | Bounded', '| `a24de93`, 22 Oct | Bounded')
needle='The chronology is a record of accepted and rejected experiments'
pos=old.index(needle)
old=old[:pos]+old[pos:]
line='| `2d9f3fb` and this checkpoint, 22 Oct | Finite 3D material BVH queries and cached unchanged instance bounds | Largest static geometry workload is 26.39× faster; nearby-probe control 31.40×. Preserves the older 3D sampler, whose ~720% room error remains unacceptable. Three stages, code, raw data and plots archived above. |\n\n'
old=old[:pos].rstrip()+'\n'+line+old[pos:]
p.write_text(intro+old)
p=ROOT/'docs/cleanup-results.md';old=p.read_text();head,rest=old.split('\n',1)
p.write_text(head+'''\n
## Finite 3D material queries and unchanged instance bounds — 2026-10-22

[Consolidated report and 2D height-slice maps](acoustic-experiment-history.md) · [Numerical ledger](benchmarks/finite3d-scaling-2026-10-22.json) · [Reproduction archive](benchmarks/finite3d-scaling-2026-10-22.zip).

- Reuse existing BLAS/TLAS for material containment; retain linear fallback, winding and equal-volume priority. Cache exact per-frame poses to avoid unchanged world-bound transforms. Net 30 runtime lines in two existing files; no new runtime dependency.
- 36,870 solids / 442,440 triangles, 1,024 rays/bin, three bins, eight bounces: static median **339.41 → 58.47 → 12.86 ms**; one-crate movement **323.29 → 78.47 → 32.26 ms**. GPU buffers 94.54 MB unchanged; CPU pose cache adds 1.03 MB. Offline host timings, not broadband realtime figures.
- Nearby-receiver control (4–8 m) avoids the scale series' fixed-horizon limitation: static **314.95 → 10.03 ms**, moving **310.92 → 17.86 ms**, bitwise identical pressure. Raw less-favorable runs remain archived.
- Final 14 integrated Unity cases pass. Main old/new pressure discrepancy ≤0.0000233%; pose cache bitwise preserves material-only output. Compiler warnings remain.
- **No physical accuracy improvement:** existing finite-3D sampler still has 719.89% complex-pressure error at 125 Hz in the reference room. The newer bounded complete-route prototype remains 2.5D. Preprocessing/simplifying acoustic meshes is documented as a next experiment, not implemented or claimed to solve that error.
- Journal now explicitly checkpoints each completed experiment and preserves failed attempts, settings, raw evidence and plots for a future process video. Git alone does not capture ignored scratch data or gameplay footage.
'''+rest)
print('Updated existing experiment journal and cleanup report')
