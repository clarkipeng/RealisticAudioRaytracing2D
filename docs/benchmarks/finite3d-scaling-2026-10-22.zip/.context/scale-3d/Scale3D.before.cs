using System;
using System.Collections.Generic;
using System.IO;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
public partial class TakeChecks
{
    [Serializable] sealed class ScaleBox {public float[] center,half,rotation;}
    [Serializable] sealed class ScaleScene
    {
        public string name;public float[] source,points,triangles;public ScaleBox[] walls;
        public int[] triangleMaterials,rays,seeds;public int fftSize,sampleRate,maxBounces,repeat,moveOwner;
        public float maximumDelaySeconds;public AcousticTake.MaterialDefinition[] materials;
    }
    static Vector3 ScaleVector(float[] a,int i=0)=>new Vector3(a[i],a[i+1],a[i+2]);
    public static IEnumerable<string> ScaleCases()=>File.ReadAllLines(Environment.GetEnvironmentVariable("ACOUSTIC_3D_CASES"));
    [TestCaseSource(nameof(ScaleCases)),Category("QualityMeasurement")]
    public void MeasureScale3D(string output)
    {
        Assert.That(Application.isBatchMode,Is.True);AudioListener.volume=0;
        var config=JsonUtility.FromJson<ScaleScene>(File.ReadAllText(Path.Combine(output,"scene.json")));
        int owners=config.triangles==null?config.walls.Length:1;
        var scene=Scene(owners+1);scene.listeners=new[]{1};var state=States(owners+1);state[0].position=ScaleVector(config.source);
        scene.materials=config.materials??new[]{new AcousticTake.MaterialDefinition {name="rigid",frequencies=new[]{0f},absorption=new[]{0f},scattering=new[]{0f},transmission=new[]{0f}}};
        var triangles=new List<AcousticTake.Primitive>();
        for(int w=0;w<owners;w++)
        {
            int owner=w+2;state[owner].flags=AcousticTake.StateFlags.Active|AcousticTake.StateFlags.Geometry;scene.objects[owner].primitiveStart=triangles.Count;
            if(config.triangles==null)
            {
                var box=config.walls[w];state[owner].position=ScaleVector(box.center);state[owner].rotation=Quaternion.Euler(ScaleVector(box.rotation));
                foreach(var t in TransportBox(scene.dimension,owner,0,1)){var p=t;p.a=Vector3.Scale(p.a,ScaleVector(box.half));p.b=Vector3.Scale(p.b,ScaleVector(box.half));p.c=Vector3.Scale(p.c,ScaleVector(box.half));triangles.Add(p);}
            }
            else
            {
                state[owner].position=Vector3.zero;var bounds=new Bounds(ScaleVector(config.triangles),Vector3.zero);
                for(int i=0;i<config.triangleMaterials.Length;i++)
                {
                    var p=new AcousticTake.Primitive {objectIndex=owner,materialIndex=config.triangleMaterials[i],a=ScaleVector(config.triangles,9*i),b=ScaleVector(config.triangles,9*i+6),c=ScaleVector(config.triangles,9*i+3)};
                    triangles.Add(p);bounds.Encapsulate(p.a);bounds.Encapsulate(p.b);bounds.Encapsulate(p.c);
                }
                foreach(var t in TransportBox(scene.dimension,owner,0,1)){var p=t;var half=bounds.extents+Vector3.one;p.a=bounds.center+Vector3.Scale(p.a,half);p.b=bounds.center+Vector3.Scale(p.b,half);p.c=bounds.center+Vector3.Scale(p.c,half);triangles.Add(p);}
            }
            scene.objects[owner].primitiveCount=triangles.Count-scene.objects[owner].primitiveStart;
        }
        var geometry=triangles.ToArray();var shader=RequireGpu();var reduce=UnityEngine.Object.Instantiate(AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/Tests/Editor/Scale3DReduce.compute"));
        using var csv=new StreamWriter(Path.Combine(output,"results.csv"));csv.WriteLine("rays,seed,moving,repeat,point,hz,real,imag,max_arrival,arrivals,seconds,upload_seconds,bvh_seconds,setup_seconds,cold_seconds,gpu_bytes,cpu_bytes,triangles,objects,bvh_build_seconds,bvh_updates");
        try
        {
            foreach(int rays in config.rays)foreach(int seed in config.seeds)
            {
                var settings=EdgeSettings();settings.useBvh=true;settings.airAbsorption=false;settings.fftSize=config.fftSize;settings.spectralHop=config.fftSize/2;
                settings.raysPerBin=rays;settings.seed=seed;settings.maxBounces=config.maxBounces;settings.maximumDelaySeconds=config.maximumDelaySeconds;settings.minimumDistance=.01f;
                long start=System.Diagnostics.Stopwatch.GetTimestamp();using var solver=new TransportSolver(scene,geometry,settings,shader,sampleRate:config.sampleRate,readbackPaths:false);
                int bins=settings.FrequencyBins,groups=(rays+63)/64;using var partial=new ComputeBuffer(groups*bins,16);using var result=new ComputeBuffer(bins,16);var values=new Vector4[bins];
                int gather=reduce.FindKernel("Gather"),sum=reduce.FindKernel("Reduce");reduce.SetInt("Rays",rays);reduce.SetInt("Bounces",settings.maxBounces);reduce.SetInt("Bins",bins);reduce.SetInt("Groups",groups);reduce.SetFloat("Step",(float)config.sampleRate/config.fftSize);
                reduce.SetBuffer(gather,"Paths",solver.RayBuffer);reduce.SetBuffer(gather,"Partials",partial);reduce.SetBuffer(sum,"Partials",partial);reduce.SetBuffer(sum,"Result",result);double setup=TakeRender.Elapsed(start);
                void Solve(){solver.BeginSolve(state,1,false);reduce.Dispatch(gather,groups,bins,1);reduce.Dispatch(sum,bins,1,1);result.GetData(values);solver.CompleteAfterGpuAudio();foreach(var v in values)Assert.That(float.IsFinite(v.x)&&float.IsFinite(v.y)&&float.IsFinite(v.z),Is.True);}
                state[1].position=ScaleVector(config.points);start=System.Diagnostics.Stopwatch.GetTimestamp();Solve();double cold=TakeRender.Elapsed(start);
                if(geometry.Length<2000)
                {
                    var paths=new RayTransport.Path[solver.RayPathsPerFrame];solver.RayBuffer.GetData(paths);
                    for(int bin=1;bin<bins;bin++){var expected=EdgeResponse(paths,bin,(float)bin*config.sampleRate/config.fftSize);var actual=new System.Numerics.Complex(values[bin].x,values[bin].y);Assert.That((actual-expected).Magnitude,Is.LessThan(1e-4*(1+expected.Magnitude)),"GPU reduction must match independent double-precision CPU summation.");}
                }
                int movingCount=config.moveOwner>=0?2:1;Vector3 initial=config.moveOwner>=0?state[config.moveOwner+2].position:Vector3.zero;
                for(int moving=0;moving<movingCount;moving++)for(int repeat=0;repeat<config.repeat;repeat++)for(int point=0;point<config.points.Length/3;point++)
                {
                    state[1].position=ScaleVector(config.points,point*3);
                    if(moving!=0)state[config.moveOwner+2].position=initial+Vector3.up*(.1f*((point+repeat)%2));
                    double upload=solver.UploadSeconds,bvh=solver.BvhUpdateSeconds;start=System.Diagnostics.Stopwatch.GetTimestamp();Solve();double seconds=TakeRender.Elapsed(start);upload=solver.UploadSeconds-upload;bvh=solver.BvhUpdateSeconds-bvh;
                    for(int bin=1;bin<bins;bin++){var v=values[bin];csv.WriteLine(FormattableString.Invariant($"{rays},{seed},{moving},{repeat},{point},{(float)bin*config.sampleRate/config.fftSize:R},{v.x:R},{v.y:R},{v.z:R},{v.w:R},{seconds:R},{upload:R},{bvh:R},{setup:R},{cold:R},{solver.GpuBufferBytes+16L*(groups+1)*bins},{solver.CpuBufferBytes},{geometry.Length},{owners},{solver.BvhBuildSeconds:R},{solver.BvhUpdates}"));}
                }
                csv.Flush();Debug.Log($"Scale3D {config.name} rays={rays} triangles={geometry.Length} done");
            }
        }
        finally{UnityEngine.Object.DestroyImmediate(reduce);}
    }
}
