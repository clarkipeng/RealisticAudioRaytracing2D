import hashlib,json,os,shutil,subprocess,sys,time,uuid
from pathlib import Path
import xml.etree.ElementTree as ET
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];runner=ROOT/'.context/gpu-audio/runner'
assert not (runner/'Temp/UnityLockfile').exists()
cases=[OUT/name for name in sys.argv[1:]]
for p in cases:assert (p/'scene.json').exists() and not (p/'results.csv').exists(),p
hashes={}
for folder in ('Assets/Scripts','Assets/Shaders','Assets/Resources/Acoustics'):
 for p in (ROOT/folder).rglob('*'):
  if p.is_file() and p.suffix!='.meta':
   assert p.read_bytes()==(runner/p.relative_to(ROOT)).read_bytes(),p
   hashes[str(p.relative_to(ROOT))]=hashlib.sha256(p.read_bytes()).hexdigest()
files={OUT/name:runner/'Assets/Tests/Editor'/name for name in ('Scale3D.cs','Scale3DReduce.compute')}
for p,d in list(files.items()):
 meta=p.with_name(p.name+'.meta')
 if not meta.exists():meta.write_text('fileFormatVersion: 2\nguid: '+uuid.uuid4().hex+'\n')
 files[meta]=d.with_name(d.name+'.meta')
assert all(not p.exists() for p in files.values())
stamp=time.strftime('%H%M%S');casefile=OUT/f'cases-{stamp}.txt';casefile.write_text('\n'.join(map(str,cases))+'\n')
(OUT/f'provenance-{stamp}.json').write_text(json.dumps(dict(baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),runtime=hashes,fixture={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files},cases={p.name:hashlib.sha256((p/'scene.json').read_bytes()).hexdigest() for p in cases}),indent=2)+'\n')
for p,d in files.items():shutil.copy2(p,d)
try:
 cmd=['nice','-n','15','/Applications/Unity/Hub/Editor/6000.4.1f1/Unity.app/Contents/MacOS/Unity','-batchmode','-force-metal','-disable-audio','-job-worker-count','1','-projectPath',str(runner),'-runTests','-testPlatform','EditMode','-testFilter','TakeChecks.MeasureScale3D','-testResults',str(OUT/f'gpu-{stamp}.xml'),'-logFile',str(OUT/f'gpu-{stamp}.log')]
 result=subprocess.run(cmd,env=dict(os.environ,ACOUSTIC_3D_CASES=str(casefile)),timeout=900)
 test=ET.parse(OUT/f'gpu-{stamp}.xml').getroot();print(test.attrib,flush=True);assert result.returncode==0 and test.get('result')=='Passed' and int(test.get('passed'))==len(cases)
finally:
 for p in files.values():p.unlink(missing_ok=True)
