import hashlib,json,platform,shutil,subprocess,zipfile
from pathlib import Path
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'.context/scale-3d';DOC=ROOT/'docs/benchmarks'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files=json.loads((OUT/'production-152056.json').read_text())
for f,h in files.items():
 assert sha(ROOT/f)==h,f
 dst=OUT/'production'/f;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/f,dst)
refs=ROOT/'.context/spatial-accuracy/room-12m-25'
for f in refs.glob('reference-*.json'):
 meta=json.loads(f.read_text());assert sha(refs/'scene.json')==meta['sceneSha256'];assert sha(ROOT/'tools/room_wave.py')==meta['solverSha256']
# Match each measured input and effective shader/fixture version to an archived source.
source_hashes={sha(p) for p in OUT.rglob('*') if p.is_file()}
for p in OUT.glob('provenance-*.json'):
 v=json.loads(p.read_text())
 for name,h in v['cases'].items():assert sha(OUT/name/'scene.json')==h,(p,name)
 for h in v['fixture'].values():assert h in source_hashes,(p,h)
 for key in ('transportShaderSha256','nativeTestSha256','bvhSha256'):
  if key in v:assert v[key] in source_hashes,(p,key)
suites=[]
for p in sorted(OUT.glob('*.xml')):
 t=ET.parse(p).getroot();assert t.get('failed')=='0' and t.get('result')=='Passed'
 suites.append(dict(file=p.name,passed=int(t.get('passed')),durationSeconds=float(t.get('duration')),startUtc=t.get('start-time')))
summary=json.loads((OUT/'summary.json').read_text())
ledger=dict(experiment='finite3d-material-bvh-and-pose-cache',date='2026-10-22',baseCommit='a24de93340ff6c52b08021029ea252e4ab7e6444',materialQueryCommit='2d9f3fb',productionHashes=files,hardware=dict(chip='Apple M5',memoryGB=16,unity='6000.4.1f1',backend='Metal',jobWorkers=1,nice=15,audioDisabled=True),parameters=dict(raysPerBin=[256,1024],frequencyBins=3,maxBounces=8,seed=17,maximumDelaySeconds=.4,warehouseHz=[0,125,250],roomHz=[0,62.5,125],warehouseProbeCount=5,warehouseRepeats=3,roomProbeCount=1060),interpretation=dict(renderer='Existing finite-3D production path sampler; bounded complete-route 2.5D prototype not ported.',timing='Host-observed warmed state submission + trace + GPU reduction + blocking readback + finite checks. Setup/cold dispatch, Unity startup, audio/DSP excluded. Two frequency rows share one query time.',memory='Allocated GPU buffers and accounted CPU numeric buffers; excludes general managed scene data and Unity/driver memory.',horizon='Scale-series extent grows at fixed delay horizon; nearby-probe control keeps all source/receiver distances 4–8 m.',motion='One crate alternates position between queries; not continuous moving-boundary acoustic accuracy.',accuracy='~720% room complex-pressure error at 125 Hz / 1024 rays. Geometry acceleration preserves the result; not high-fidelity or DLSS-teacher validation.',waveReference='Reused order-4 finite-room FEM, 80033 DOFs; two refinements. Observed convergence is not certified error.',tests='Passing suites overlap; do not sum as unique coverage. Existing compiler warnings retained in logs.',preprocessing='Acoustic mesh/edge simplification proposed in report, not implemented.'),tests=suites,measurements=summary,figures={p.name:sha(p) for p in sorted(DOC.glob('finite3d-*-2026-10-22.png'))})
archive=DOC/'finite3d-scaling-2026-10-22.zip'
# Full evidence stays in the archive, including initial trial logs and sources.
paths=[p for p in OUT.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
paths += [p for p in refs.iterdir() if p.is_file() and (p.name.startswith('reference-') or p.name in ('scene.json','renderer-scene.json'))]
paths += [ROOT/'tools/room_wave.py']+list(DOC.glob('finite3d-*-2026-10-22.png'))
manifest={str(p.relative_to(ROOT)):sha(p) for p in sorted(paths)}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(paths):z.write(p,str(p.relative_to(ROOT)))
 z.writestr('manifest.sha256.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,h in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==h,name
ledger['archive']=dict(file=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(manifest))
(DOC/'finite3d-scaling-2026-10-22.json').write_text(json.dumps(ledger,indent=2)+'\n')
print('Verified archive',ledger['archive']);print('Production suites',suites)
