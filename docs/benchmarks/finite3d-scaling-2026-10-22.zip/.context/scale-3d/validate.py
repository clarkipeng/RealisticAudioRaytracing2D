import hashlib,json,os,subprocess,time
from pathlib import Path
import xml.etree.ElementTree as ET
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];runner=ROOT/'.context/gpu-audio/runner';assert not (runner/'Temp/UnityLockfile').exists()
files=['Assets/Shaders/Transport.hlsl','Assets/Shaders/Geometry.hlsl','Assets/Scripts/Simulation/DirectBvh.cs','Assets/Tests/Editor/RayTransportChecks.cs']
for p in files:assert (ROOT/p).read_bytes()==(runner/p).read_bytes(),p
stamp=time.strftime('%H%M%S');names=['MediumBvhParity','TransportMedia','TransportNativeVolumes','BvhChecks','InstanceBvhChecks','MaterialSpeedDoppler','MaterialBoundaryClockRate']
(OUT/f'production-{stamp}.json').write_text(json.dumps({p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in files},indent=2)+'\n')
r=subprocess.run(['nice','-n','15','/Applications/Unity/Hub/Editor/6000.4.1f1/Unity.app/Contents/MacOS/Unity','-batchmode','-force-metal','-disable-audio','-job-worker-count','1','-projectPath',str(runner),'-runTests','-testPlatform','EditMode','-testFilter',';'.join('TakeChecks.'+n for n in names),'-testResults',str(OUT/f'production-{stamp}.xml'),'-logFile',str(OUT/f'production-{stamp}.log')],timeout=600)
t=ET.parse(OUT/f'production-{stamp}.xml').getroot();print(t.attrib,flush=True);assert r.returncode==0 and t.get('result')=='Passed' and t.get('passed')=='14'
