import json
from pathlib import Path
import numpy as np
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1]
def read(p):return np.genfromtxt(p,delimiter=',',names=True,ndmin=1)
def complex_field(a):return a['real']+1j*a['imag']
rows=[];maps=[]
for name in ('hall-1','hall-4','hall-8','hall-16','hall-32','hall-64','room-map'):
 p=OUT/name;c=json.loads((p/'scene.json').read_text());a=read(p/'baseline.csv');b=read(p/'accelerated.csv');f=read(p/'cached.csv')
 for key in ('rays','seed','moving','repeat','point','hz'):
  np.testing.assert_array_equal(a[key],b[key]);np.testing.assert_array_equal(a[key],f[key])
 difference=float(np.linalg.norm(complex_field(a)-complex_field(f))/max(np.linalg.norm(complex_field(a)),1e-30));np.testing.assert_allclose(complex_field(b),complex_field(a),rtol=2e-4,atol=1e-5);np.testing.assert_array_equal(complex_field(f),complex_field(b))
 for n in c['rays']:
  for moving in (0,1) if name.startswith('hall') else (0,):
   hz=float(max(a['hz']));x=a[(a['rays']==n)&(a['moving']==moving)&(a['hz']==hz)];y=b[(b['rays']==n)&(b['moving']==moving)&(b['hz']==hz)];z=f[(f['rays']==n)&(f['moving']==moving)&(f['hz']==hz)]
   row=dict(scene=name,raysPerBin=n,bins=c['fftSize']//2+1,maxBounces=c['maxBounces'],moving=bool(moving),queries=len(x),triangles=int(x['triangles'][0]),objects=int(x['objects'][0]),pressureRelativeDifference=difference)
   for label,d in (('old',x),('media',y),('new',z)):
    row[label]=dict(medianMs=float(np.median(d['seconds'])*1000),p95Ms=float(np.percentile(d['seconds'],95)*1000),totalSeconds=float(d['seconds'].sum()),uploadMedianMs=float(np.median(d['upload_seconds'])*1000),bvhUpdateMedianMs=float(np.median(d['bvh_seconds'])*1000),gpuBytes=int(d['gpu_bytes'][0]),cpuNumericBytes=int(d['cpu_bytes'][0]),setupSeconds=float(d['setup_seconds'][0]),coldSeconds=float(d['cold_seconds'][0]),bvhBuildSeconds=float(d['bvh_build_seconds'][0]))
   row['speedRatio']=row['old']['medianMs']/row['new']['medianMs'];rows.append(row)
   print(name,n,'moved',moving,'ms',row['old']['medianMs'],row['new']['medianMs'],'ratio',row['speedRatio'],'parity',difference,flush=True)
 if name=='room-map':
  arrays={'points':np.array(c['points']).reshape(-1,3)};refdir=ROOT/'.context/spatial-accuracy/room-12m-25'
  for hz in (62.5,125):
   ref=np.load(refdir/f'reference-0.9-{hz:g}.npz')['pressure'];coarse=np.load(refdir/f'reference-1.3-{hz:g}.npz')['pressure'];meta=json.loads((refdir/f'reference-0.9-{hz:g}.json').read_text());arrays[f'reference{hz:g}']=ref
   for n in c['rays']:
    q=dict(hz=hz,raysPerBin=n,points=len(ref),referenceRefinementChangePercent=float(100*np.linalg.norm(ref-coarse)/np.linalg.norm(ref)),referenceMeshSeconds=meta['meshSeconds'],referenceSolveSeconds=meta['seconds'])
    for label,d in (('old',a),('media',b),('new',f)):
     x=d[(d['rays']==n)&(d['hz']==hz)];np.testing.assert_array_equal(x['point'],np.arange(len(ref)));field=complex_field(x);arrays[f'{label}{hz:g}n{n}']=field
     level=20*np.log10(np.maximum(abs(field),1e-30)/np.maximum(abs(ref),1e-30));q[label]=dict(errorPercent=float(100*np.linalg.norm(field-ref)/np.linalg.norm(ref)),within3dBPercent=float(100*np.mean(abs(level)<=3)),medianSolveMs=float(np.median(x['seconds'])*1000),fieldSolveSeconds=float(x['seconds'].sum()))
    maps.append(q)
  np.savez_compressed(OUT/'room-fields.npz',**arrays)
p=OUT/'hall-64-local';c=json.loads((p/'scene.json').read_text());a=read(p/'baseline.csv');b=read(p/'cached.csv')
for key in ('rays','seed','moving','repeat','point','hz'):np.testing.assert_array_equal(a[key],b[key])
np.testing.assert_allclose(complex_field(b),complex_field(a),rtol=2e-4,atol=1e-5)
points=np.array(c['points']).reshape(-1,3);distances=np.linalg.norm(points-c['source'],axis=1)
for w in c['walls']:
 angle=np.deg2rad(w['rotation'][2]);rotation=np.array([[np.cos(angle),-np.sin(angle),0],[np.sin(angle),np.cos(angle),0],[0,0,1]])
 assert not np.any(np.all(abs((points-w['center'])@rotation)<w['half'],axis=1)), 'Probe inside solid'
nearby=dict(distancesMetres=distances.tolist(),pressureRelativeDifference=float(np.linalg.norm(complex_field(a)-complex_field(b))/np.linalg.norm(complex_field(a))),measurements=[])
for moved in (0,1):
 q=dict(moving=bool(moved))
 for label,d in (('old',a),('new',b)):
  x=d[(d['moving']==moved)&(d['hz']==250)]
  q[label]=dict(queries=len(x),medianMs=float(np.median(x['seconds'])*1000),p95Ms=float(np.percentile(x['seconds'],95)*1000),nonzeroQueries=int(np.count_nonzero(abs(complex_field(x))>0)),arrivalCountRange=[float(x['arrivals'].min()),float(x['arrivals'].max())])
 q['speedRatio']=q['old']['medianMs']/q['new']['medianMs'];nearby['measurements'].append(q)
print('Nearby listeners',json.dumps(nearby,indent=2))
(OUT/'summary.json').write_text(json.dumps(dict(scaling=rows,accuracy=maps,nearbyListeners=nearby),indent=2)+'\n')
