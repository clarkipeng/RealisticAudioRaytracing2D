import json,shutil
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];DOC=ROOT/'docs/benchmarks';DEST=Path('/Users/clarkpeng/conductor/workspaces/realisticaudioraytracing2d/tyler/.context')
s=json.loads((OUT/'summary.json').read_text());plt.rcParams.update({'font.size':10,'figure.facecolor':'white','savefig.facecolor':'white'})
def save(fig,label):
 name=f'finite3d-{label}-2026-10-22.png';fig.savefig(DOC/name,dpi=145);plt.close(fig);shutil.copy2(DOC/name,DEST/name)
# Exact box geometry, with enclosure surfaces hidden only for this illustration.
c=json.loads((OUT/'hall-8/scene.json').read_text());polys=[];colors=[]
faces=[[0,2,3,1],[4,5,7,6],[0,1,5,4],[2,6,7,3],[0,4,6,2],[1,3,7,5]]
for i,w in enumerate(c['walls'][:-6]):
 v=np.array([[(-1 if j&1==0 else 1),(-1 if j&2==0 else 1),(-1 if j&4==0 else 1)] for j in range(8)])*w['half'];a=np.deg2rad(w['rotation'][2]);r=np.array([[np.cos(a),-np.sin(a),0],[np.sin(a),np.cos(a),0],[0,0,1]]);v=v@r.T+w['center'];polys.extend(v[f] for f in faces);colors.extend([['#798595','#a6c9db','#c89d64'][0 if i%9<4 else 1 if i%9<7 else 2]]*6)
fig=plt.figure(figsize=(12,7.4),layout='constrained');ax=fig.add_subplot(111,projection='3d');ax.add_collection3d(Poly3DCollection(polys,facecolors=colors,edgecolors='#536170',linewidths=.12));ax.scatter(*c['source'],marker='*',s=90,c='#e21c39',label='Source');points=np.array(c['points']).reshape(-1,3);ax.scatter(*points.T,s=25,c='#0078d4',label='Receiver probes');hx,hy,hz=np.array(c['extent'])/2
ax.set(xlim=(-hx,hx),ylim=(-hy,hy),zlim=(0,4.8),xlabel='x (m)',ylabel='y (m)',zlabel='z (m)',title='Finite 3D warehouse · 582 solids / 6,984 triangles');ax.set_box_aspect((2*hx,2*hy,8));ax.view_init(elev=35,azim=-58);ax.legend(loc='upper right');fig.supxlabel('Posts, shelves and rotated crates. Roof/walls/floor hidden here to expose the interior; all are present in the acoustic test.\nThe scaling series grows this layout to 36,870 solids and 442,440 triangles. One crate is also moved between queries.',fontsize=10);save(fig,'scene')
r=[x for x in s['scaling'] if x['scene'].startswith('hall') and x['raysPerBin']==1024 and not x['moving']];x=np.array([a['triangles'] for a in r]);fig,axes=plt.subplots(1,2,figsize=(12,5.5),layout='constrained')
for key,label in (('old','Original'),('media','BLAS/TLAS material lookup'),('new','+ cached unchanged bounds')):axes[0].loglog(x,[a[key]['medianMs'] for a in r],'o-',label=label)
axes[0].set(xlabel='Triangles',ylabel='Median query time (ms)',title='Same 3D path sampler, less geometry overhead');axes[0].legend(fontsize=8);axes[0].grid(alpha=.2,which='both')
axes[1].loglog(x,[a['new']['gpuBytes']/1e6 for a in r],'o-',label='GPU buffers');axes[1].loglog(x,[a['new']['cpuNumericBytes']/1e6 for a in r],'o-',label='Accounted CPU numeric buffers');axes[1].set(xlabel='Triangles',ylabel='Allocated MB (decimal)',title='Memory grows with geometry');axes[1].legend(fontsize=9);axes[1].grid(alpha=.2,which='both');fig.suptitle('Finite 3D scaling · 1,024 rays/bin, 3 bins, up to 8 bounces',fontsize=15);fig.supxlabel('One source/listener pair. Five probes × three repeats; static geometry. Includes pose submission, tracing, GPU reduction and blocking readback.\nSetup/first dispatch and audio synthesis excluded. CPU/GPU host timing on a shared Mac; this is not a full-spectrum realtime benchmark.',fontsize=9);save(fig,'scaling')
f=np.load(OUT/'room-fields.npz');p=f['points'];c=json.loads((OUT/'room-map/scene.json').read_text());zs=np.unique(p[:,2]);fig,axes=plt.subplots(3,3,figsize=(12,10),layout='constrained');cmap=plt.colormaps['magma'].with_extremes(over='#27c9bd',under='#050505',bad='#e5e7eb')
for row,z in enumerate(zs):
 keep=p[:,2]==z;xy=p[keep];x,y=np.unique(xy[:,0]),np.unique(xy[:,1])
 for col,(key,title) in enumerate((('reference125','Wave reference'),('old125n1024','Original 3D sampler'),('new125n1024','Same sampler + faster geometry'))):
  ax=axes[row,col];g=np.full((len(y),len(x)),np.nan);g[np.searchsorted(y,xy[:,1]),np.searchsorted(x,xy[:,0])]=20*np.log10(np.maximum(abs(f[key][keep]),1e-12));im=ax.pcolormesh(x,y,g,vmin=-40,vmax=10,cmap=cmap,shading='nearest')
  for w in c['obstacles']:
   center=np.array(w['center']);half=np.array(w['half'])
   if abs(z-center[2])<=half[2]:ax.add_patch(Rectangle(center[:2]-half[:2],*(2*half[:2]),facecolor='#515962',edgecolor='white',lw=.5))
  ax.scatter(*c['source'][:2],marker='*',s=60,c='#00a8ff',edgecolor='black',linewidth=.3);ax.set(title=f'{title}\nz = {z:g} m',xlabel='x (m)',ylabel='y (m)',xlim=(-6,6),ylim=(-4,4));ax.set_aspect('equal')
fig.colorbar(im,ax=list(axes.flat),label='Pressure level (dB re unit pressure)',extend='both',shrink=.75,pad=.01);fig.suptitle('Finite 12 × 8 × 6 m room · 25 obstacles · 125 Hz',fontsize=16);fig.supxlabel('XY slices at three heights; star = source XY projection (source z=0). 1,060 probes; teal marks values above +10 dB.\nThe older 3D diffraction sampler has ~720% complex-pressure error at this budget. Acceleration preserves it; it does not repair that error.\nWave-reference refinement changes the field by 0.26%. These are numerical reference data, not a perfect ground truth.',fontsize=9);save(fig,'pressure')
print('Saved scene, scaling and 3D height-slice figures')
