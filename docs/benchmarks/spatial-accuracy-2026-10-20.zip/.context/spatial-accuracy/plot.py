"""Static scientific figures: no browser, player, or audio device."""
import json,shutil
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
OUT=Path(__file__).resolve().parent
DEST=Path('/Users/clarkpeng/conductor/workspaces/realisticaudioraytracing2d/tyler/.context')
plt.rcParams.update({'font.size':10,'axes.titlesize':11,'figure.facecolor':'white','savefig.facecolor':'white'})
summary=json.loads((OUT/'summary.json').read_text())['cases'];lookup={c['name']:c for c in summary}

def load(name,hz,rays=256,seed=17):
 p=OUT/name;c=json.loads((p/'scene.json').read_text())
 f=sorted(p.glob(f'reference-*-{hz:g}.npz'),key=lambda f:float(f.name.split('-')[1]))[0]
 ref=np.load(f)['pressure'];rows=np.genfromtxt(p/'renderer.csv',delimiter=',',names=True)
 rows=np.sort(rows[(rows['hz']==hz)&(rows['rays']==rays)&(rows['seed']==seed)],order='point')
 assert len(rows)==len(ref)
 return c,ref,rows['real']+1j*rows['imag']

def grid(c,v,z):
 field=np.full(len(c['x'])*len(c['y'])*len(c['z']),np.nan);field[c['gridIndices']]=v
 return field.reshape(len(c['z']),len(c['y']),len(c['x']))[z]

def draw(ax,c,v,z=0,error=False):
 im=ax.pcolormesh(c['x'],c['y'],grid(c,v,z),shading='nearest',cmap='RdBu_r' if error else 'magma',vmin=-15 if error else -40,vmax=15 if error else 5,rasterized=True)
 for w in c.get('walls',c.get('obstacles',[])):
  center,half=np.array(w['center']),np.array(w['half'])
  if abs(c['z'][z]-center[2])<=half[2]:
   ax.add_patch(Rectangle(center[:2]-half[:2],*(2*half[:2]),facecolor='#3c444a',edgecolor='#c1c8ce',lw=.5))
 s=c['source'];ax.scatter(s[0],s[1],marker='*',s=90,color='#1de5e3',edgecolor='black',lw=.5,zorder=4)
 if error:
  plane=grid(c,v,z);valid=np.isfinite(plane);outside=100*np.mean(abs(plane[valid])>15)
  ax.text(.02,.02,f'{outside:.0f}% outside ±15 dB',transform=ax.transAxes,color='black',fontsize=8,bbox=dict(facecolor='white',alpha=.85,edgecolor='none'))
 ax.set_aspect('equal');ax.set_xlabel('x (m)');ax.set_ylabel('y (m)');ax.tick_params(labelsize=8)
 return im

def geometry(ax,c):
 def faces(w):
  a=np.array(w['center'])-w['half'];b=np.array(w['center'])+w['half']
  v=np.array([[a[0],a[1],a[2]],[b[0],a[1],a[2]],[b[0],b[1],a[2]],[a[0],b[1],a[2]],[a[0],a[1],b[2]],[b[0],a[1],b[2]],[b[0],b[1],b[2]],[a[0],b[1],b[2]]])
  return [v[i] for i in [[0,1,2,3],[4,5,6,7],[0,1,5,4],[1,2,6,5],[2,3,7,6],[3,0,4,7]]]
 for w in c['obstacles']:ax.add_collection3d(Poly3DCollection(faces(w),facecolors='#808f9c',edgecolors='#354451',linewidths=.4,alpha=.8))
 room=c['airVolumes'][0];half=np.array(room['half']);ax.add_collection3d(Poly3DCollection(faces(room),facecolors='#88aacc',edgecolors='#a3b6c5',alpha=.035,linewidths=.5))
 p=np.array(c['points']).reshape(-1,3);ax.scatter(*p[::11].T,s=1.8,c='#ba3561',alpha=.5)
 ax.scatter(*c['source'],marker='*',s=95,c='#16bbbb',edgecolor='black',lw=.5)
 ax.set(xlim=(-half[0],half[0]),ylim=(-half[1],half[1]),zlim=(-half[2],half[2]),xlabel='x (m)',ylabel='y (m)',zlabel='')
 ax.text2D(.02,.94,'z vertical (m)',transform=ax.transAxes,fontsize=8);ax.set_box_aspect(half);ax.view_init(elev=23,azim=-56);ax.tick_params(labelsize=7)

def levels(ref,actual):
 floor=np.sqrt(np.mean(abs(ref)**2))*1e-6
 return 20*np.log10(np.maximum(abs(ref),floor)),20*np.log10(np.maximum(abs(actual),floor)),20*np.log10(np.maximum(abs(actual),floor)/np.maximum(abs(ref),floor))

def save(fig,name):
 fig.savefig(OUT/name,dpi=150,bbox_inches='tight');plt.close(fig);shutil.copy2(OUT/name,DEST/name)

fig,axes=plt.subplots(3,3,figsize=(13,12),layout='constrained')
for row,name in enumerate(['planar-1','planar-9','planar-25']):
 c,ref,actual=load(name,250);vals=levels(ref,actual)
 for col in range(3):
  im=draw(axes[row,col],c,vals[col],error=col==2)
  axes[row,col].set_title(f"{len(c['walls'])} obstacles · "+['wave reference','live GPU, seed 17','GPU − reference level'][col])
  cb=fig.colorbar(im,ax=axes[row,col],shrink=.75);cb.set_label('dB difference' if col==2 else 'dB re unit pressure')
fig.suptitle('Larger planar acoustic fields · 250 Hz · 256 rays/bin\nSame source and amplitude scale; coloured cells are sampled receiver positions.',fontsize=15)
save(fig,'larger-2d-maps.png')

fig=plt.figure(figsize=(17,11),layout='constrained');gs=fig.add_gridspec(3,4)
for row,name in enumerate(['room-6m-4','room-12m-4','room-12m-25']):
 c,ref,actual=load(name,125);vals=levels(ref,actual)
 ax=fig.add_subplot(gs[row,0],projection='3d');geometry(ax,c);ax.set_title(name.replace('room-','').replace('m-',' m · ')+' obstacles')
 for col in range(3):
  ax=fig.add_subplot(gs[row,col+1]);im=draw(ax,c,vals[col],z=1,error=col==2)
  ax.set_title(['3D wave reference · z = 0','live GPU, seed 17 · z = 0','GPU − reference level'][col]);cb=fig.colorbar(im,ax=ax,shrink=.65);cb.set_label('dB difference' if col==2 else 'dB re unit pressure')
fig.suptitle('Finite 3D rooms · 125 Hz · 256 rays/bin\nFloor, ceiling, walls and pillars included. Dots mark three sampled height planes.',fontsize=15)
save(fig,'larger-3d-maps.png')

c,ref,actual=load('room-12m-25',125);vals=levels(ref,actual)
fig,axes=plt.subplots(3,3,figsize=(13,10),layout='constrained')
for row,z in enumerate(c['z']):
 for col in range(3):
  im=draw(axes[row,col],c,vals[col],z=row,error=col==2)
  axes[row,col].set_title(f'z = {z:g} m · '+['wave reference','live GPU, seed 17','level difference'][col]);fig.colorbar(im,ax=axes[row,col],shrink=.7)
fig.suptitle('12 × 8 × 6 m room with 25 obstacles of different heights\nOne finite 3D solve; three measured slices · 125 Hz · 256 rays/bin',fontsize=15)
save(fig,'room-3d-height-slices.png')

fig,axes=plt.subplots(2,3,figsize=(15,9),layout='constrained');colors=['#3566b5','#d16b23','#7d439a']
for row,names in enumerate([['planar-1','planar-9','planar-25'],['room-6m-4','room-12m-4','room-12m-25']]):
 for color,name in zip(colors,names):
  item=lookup[name];hz=250 if row==0 else 125;rs=[r for r in item['aggregate'] if r['hz']==hz]
  x=[r['rays'] for r in rs];y=np.array([r['meanSeedError']*100 for r in rs]);lo=np.array([r['minSeedError']*100 for r in rs]);hi=np.array([r['maxSeedError']*100 for r in rs])
  axes[row,0].plot(x,y,'o-',color=color,label=name);axes[row,0].fill_between(x,lo,hi,color=color,alpha=.12)
  axes[row,1].plot(x,[r['medianMs'] for r in rs],'o-',color=color,label=name)
  axes[row,2].plot(x,[100*r['meanFractionWithin3dB'] for r in rs],'o-',color=color,label=name)
 for col in range(3):
  ax=axes[row,col];ax.set_xscale('log',base=4);ax.set_xticks([16,64,256],['16','64','256']);ax.set_xlabel('Rays per frequency bin');ax.grid(alpha=.2);ax.legend(fontsize=8)
 axes[row,0].set_ylabel('Complex pressure error (%)');axes[row,0].set_yscale('log');axes[row,0].set_title(('Planar 250 Hz' if row==0 else '3D 125 Hz')+' · error (lower is better)')
 axes[row,1].set_ylabel('Milliseconds per receiver query');axes[row,1].set_title('Warm submission + GPU + readback; 3 bins')
 axes[row,2].set_ylabel('Receiver positions within ±3 dB (%)');axes[row,2].set_ylim(0,100);axes[row,2].set_title('Local level accuracy (higher is better)')
fig.suptitle('Measured accuracy and computation scaling · Apple M5\nFour seeds: error lines are mean individual-run errors; shading is min–max, not a confidence interval.',fontsize=15)
save(fig,'spatial-accuracy-scaling.png')
print('Saved four spatial figures',flush=True)

# Same actual samples shown in 3D; no volumetric interpolation between planes.
c,ref,actual=load('room-12m-25',125);points=np.array(c['points']).reshape(-1,3)
fig=plt.figure(figsize=(16,6),layout='constrained')
for col,v in enumerate(levels(ref,actual)):
 ax=fig.add_subplot(1,3,col+1,projection='3d');geometry(ax,c)
 for collection in list(ax.collections)[-2:]:collection.remove()
 for collection in ax.collections:collection.set_alpha(.08)
 im=ax.scatter(*points.T,c=v,s=13,cmap='RdBu_r' if col==2 else 'magma',vmin=-15 if col==2 else -40,vmax=15 if col==2 else 5,depthshade=False)
 ax.scatter(*c['source'],marker='*',s=130,c='#18cccc',edgecolor='black',lw=.6)
 ax.set_title(['Wave reference','Live GPU · 256 rays/bin','Local level error'][col]);fig.colorbar(im,ax=ax,shrink=.55,pad=.04,label='dB difference' if col==2 else 'dB re unit pressure')
fig.suptitle('Positional field in a finite 12 × 8 × 6 m room · 125 Hz\n1,060 sampled positions on three planes · 25 obstacles · seed 17',fontsize=15)
save(fig,'room-3d-positional-field.png')
