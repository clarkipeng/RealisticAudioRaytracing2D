import hashlib,json,sys,time
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'tools'))
from room_wave import RoomField
from compare_wave_field import save_json
p=Path(__file__).resolve().parent/'room-6m-4';c=json.loads((p/'scene.json').read_text());h=.9
field=RoomField(c,h,4)
for hz in c['frequencies']:
 stem=p/f'reference-{h:g}-{hz:g}'
 if Path(str(stem)+'.npz').exists():raise FileExistsError(stem)
 start=time.perf_counter();value=field.solve(hz);seconds=time.perf_counter()-start
 np.savez_compressed(str(stem)+'.npz',pressure=value,points=np.array(c['points']).reshape(-1,3))
 row=dict(field.stats,hz=hz,seconds=seconds,sceneSha256=hashlib.sha256((p/'scene.json').read_bytes()).hexdigest(),solverSha256=hashlib.sha256((root/'tools/room_wave.py').read_bytes()).hexdigest())
 save_json(Path(str(stem)+'.json'),row);print(row,flush=True)
