"""Unmodified offline edge prototype, stratified subset of larger planar fields."""
import hashlib,json,sys,time
from pathlib import Path
import numpy as np
from scipy.stats import qmc  # Load sampler before timed calls.
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
import edge_integral as edge
for name in sys.argv[1:]:
 p=OUT/name;c=json.loads((p/'scene.json').read_text());points=np.array(c['points']).reshape(-1,3)
 grid=np.array(c['gridIndices']);nx=len(c['x'])
 # Fixed coarse lattice, chosen without inspecting either field, same for all budgets/seeds.
 indices=np.flatnonzero(((grid%nx)%4==0)&((grid//nx)%3==0))
 rows=[];arrays=dict(points=points[indices],indices=indices)
 for samples in [32,128,512]:
  values=[]
  for seed in (c['seeds'] if samples==128 else [17]):
   start=time.perf_counter();stats={}
   pure,connections,routes=edge.sampled(c,points[indices],250,samples,seed,2,stats=stats,mirror_depth=2)
   seconds=time.perf_counter()-start;value=pure.sum(axis=1)+connections.sum(axis=1);values.append(value)
   row=dict(samples=samples,seed=seed,seconds=seconds,probes=len(indices),routes=int(routes.sum()),stats=stats)
   rows.append(row);print(name,row,flush=True)
  arrays[f'samples{samples}']=np.array(values)
  np.savez_compressed(p/'prototype.npz',**arrays)
  (p/'prototype.json').write_text(json.dumps(dict(rows=rows,depth=2,mirrorDepth=2,hz=250,
    sceneSha256=hashlib.sha256((p/'scene.json').read_bytes()).hexdigest(),sourceSha256=hashlib.sha256(Path(edge.__file__).read_bytes()).hexdigest()),indent=2)+'\n')
