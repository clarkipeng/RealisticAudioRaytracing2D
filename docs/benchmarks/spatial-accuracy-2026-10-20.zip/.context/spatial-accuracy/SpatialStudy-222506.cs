using System; using System.IO; using NUnit.Framework; using UnityEngine;
public partial class TakeChecks { [Test, Category("QualityMeasurement")]
public void SpatialStudy() {
 foreach(var path in File.ReadAllLines(Environment.GetEnvironmentVariable("SPATIAL_CASES"))) {
  Debug.Log("SPATIAL BEGIN "+path); Environment.SetEnvironmentVariable("ACOUSTIC_WAVE_OUTPUT",path);
  MeasureWaveField(); Debug.Log("SPATIAL COMPLETE "+path);
 }
}}
