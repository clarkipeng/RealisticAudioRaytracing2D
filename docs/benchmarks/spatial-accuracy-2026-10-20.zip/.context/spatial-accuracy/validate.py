import hashlib,json,sys,xml.etree.ElementTree as ET
from pathlib import Path
import numpy as np
out=Path(__file__).resolve().parent
cases=json.loads((out/'manifest.json').read_text())['cases']+['free-control'];checks=[]
for name in cases:
 p=out/name;c=json.loads((p/'scene.json').read_text());n=len(c['points'])//3
 a=np.genfromtxt(p/'renderer.csv',delimiter=',',names=True)
 assert len(a)==n*len(c['rays'])*len(c['seeds'])*len(c['frequencies'])
 assert all(np.isfinite(a[k]).all() for k in a.dtype.names)
 assert (a['diffraction']==1).all()
 q=out/(name+'-repeat');ids=np.array(json.loads((q/'indices.json').read_text()));b=np.genfromtxt(q/'renderer.csv',delimiter=',',names=True)
 worst=0.;comparisons=0
 for rays in c['rays']:
  for seed in c['seeds']:
   for hz in c['frequencies']:
    select=lambda x:np.sort(x[(x['rays']==rays)&(x['seed']==seed)&(x['hz']==hz)],order='point')
    full=select(a);repeat=select(b)
    np.testing.assert_array_equal(full['point'],np.arange(n));np.testing.assert_array_equal(repeat['point'],np.arange(len(ids)))
    x=full['real'][ids]+1j*full['imag'][ids];y=repeat['real']+1j*repeat['imag']
    np.testing.assert_allclose(y,x,rtol=2e-5,atol=1e-7)
    np.testing.assert_array_equal(repeat['direct_visible'],full['direct_visible'][ids])
    worst=max(worst,float(np.max(abs(x-y)/np.maximum(abs(x),1e-6))));comparisons+=len(ids)
 checks.append(dict(scene=name,rows=len(a),repeatedPressureValues=comparisons,maximumRelativeChange=worst,
                    csvSha256=hashlib.sha256((p/'renderer.csv').read_bytes()).hexdigest()))
 print(checks[-1],flush=True)
xmls=[]
for p in sorted(out.glob('gpu-*.xml')):
 r=ET.parse(p).getroot();xmls.append(dict(file=p.name,result=r.get('result'),passed=int(r.get('passed')),failed=int(r.get('failed')),duration=float(r.get('duration')),
                                      messages=[e.text for e in r.findall('.//test-case/failure/message')]))
assert any(r['passed']==17 and r['failed']==0 for r in xmls)
original=xmls[0];assert original['failed']==1 and all('Timeout value of 180000 ms' in s for s in original['messages'])
log=(out/original['file']).with_suffix('.log').read_text()
for name in cases:assert 'SPATIAL COMPLETE '+str(out/name) in log
value=dict(passed=True,note='Original combined measurement exceeded Unity timeout after completing all fields. Atomic follow-up tests passed and reproduced fixed spatial subsets; original failed XML retained.',checks=checks,testRuns=xmls)
(out/'validation.json').write_text(json.dumps(value,indent=2)+'\n')
print('Complete fields and repeat subsets validated',flush=True)
