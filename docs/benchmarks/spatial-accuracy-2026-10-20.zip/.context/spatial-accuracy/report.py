import hashlib,json,shutil,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(OUT));from analyze import gather,evaluate
sys.path.insert(0,str(ROOT/'tools'));from compare_wave_field import shadow_mask,save_json
cases=gather();byname={c['name']:c for c in cases};lines=[]
def add(s=''):lines.append(s)
def num(x):return f'{x:,.2f}' if abs(x)<1e5 else f'{x:.3g}'
add('## Larger 2D and finite 3D acoustic accuracy — 2026-10-20\n')
add('**The current GPU estimator is not a reliable wave-field approximation on this suite.** Exact direct visibility passes, but higher-order acoustic contributions can become extremely large. More rays do not reliably restore accuracy. The earlier low-error planar plots evaluated the separate CPU edge-integral prototype; those results must not be attributed to the live shader. No runtime/shader change was made for this measurement.\n')
add('### What was actually measured\n')
add('Apple M5, 16 GiB, macOS 26.5.1, Unity 6000.4.1f1 / Metal. Silent isolated batch runner, one worker, low priority. Numerical references use NGSolve 6.2.2608 with one CPU thread. One source, stationary geometry and receivers, complex scalar pressure; no HRTF, headphones/speakers, binaural localization test, source audio or DSP. These are controlled synthetic acoustic scenes, not the visual church asset.\n')
add('- Planar layouts: a 12 × 11 m receiver map with 1, 9 or 25 rigid 0.6 m square obstacles. Geometry is infinitely extruded; the wave solver integrates 2D Helmholtz solutions over longitudinal wavenumber to reproduce a **3D point source**, matching our planar acoustic convention. This is 2.5D acoustics, not a 2D line-source wave.\n- Finite rooms: 6 × 4 × 3 m and 12 × 8 × 6 m with four floor-to-ceiling pillars; another 12 × 8 × 6 m room has 25 obstacles of varying heights. Walls/floor/ceiling have dimensionless real admittance 0.2, pillars are rigid. These are actual 3D FEM solves, sampled on three XY height planes.\n- GPU: BVH on, diffraction on, air absorption off, 16/64/256 rays per frequency bin, eight interactions and 0.4 s path support. Four seeds: 17, 65554, 131091, 196628. All runs calculate three FFT bins; frequencies scored are 125/250 Hz in planar cases and 62.5/125 Hz in rooms. No amplitude fitting, normalization to the reference, clipping of recorded fields or averaging of seeds in displayed maps.\n')
add('### Accuracy by receiver position\n')
add('The percentage error below is **complex pressure L2 error**, `100 * ||ray - wave|| / ||wave||`, averaged over individual seed runs. It includes amplitude and phase: zero output would score 100% error, and error can exceed 100%. “Within ±3 dB” is the fraction of receiver positions with approximately correct local amplitude; it does not establish correct phase. Neither is a binaural angle error.\n')
add('| Scene | Hz | Probes | Complex error | Positions within ±3 dB | Median query ms |\n|---|---:|---:|---:|---:|---:|')
for c in cases:
 hz=250 if c['name'].startswith('planar') else 125;r=next(r for r in c['aggregate'] if r['hz']==hz and r['rays']==256)
 add(f"| {c['name']} | {hz} | {c['points']} | {num(100*r['meanSeedError'])}% | {100*r['meanFractionWithin3dB']:.1f}% | {r['medianMs']:.3f} |")
add('\nTiming includes warm transport submission, GPU completion/readback and solver bookkeeping for one receiver query and **three computed bins**. It excludes cold compilation, solver/BVH construction, CSV writing, CPU complex summation and audio synthesis. It is neither GPU-only timing nor a full-band real-time audio benchmark.\n')
add('![Larger planar pressure maps](benchmarks/larger-2d-maps.png)\n')
add('![Finite 3D rooms and positional maps](benchmarks/larger-3d-maps.png)\n')
add('Same pressure color scale on reference/GPU plots. Level-difference colors saturate at ±15 dB; each panel states the fraction beyond that range. Numerical metrics retain all outliers. Every shown cell is an evaluated position, with no smoothing or seed averaging. Solid grey marks obstacles; cyan stars mark the source. The three height planes are static spatial samples, not a simulated walk.\n')
add('![Three heights in the larger 3D room](benchmarks/room-3d-height-slices.png)\n')
add('![Three-dimensional sampled pressure field](benchmarks/room-3d-positional-field.png)\n')
add('### Measured scaling\n')
add('| Scene | 16 rays/bin ms | 64 rays/bin ms | 256 rays/bin ms | 16 → 256 complex error |\n|---|---:|---:|---:|---|')
for c in cases:
 hz=250 if c['name'].startswith('planar') else 125;rs=[next(r for r in c['aggregate'] if r['hz']==hz and r['rays']==n) for n in [16,64,256]]
 add(f"| {c['name']} | "+' | '.join(f"{r['medianMs']:.3f}" for r in rs)+f" | {num(100*rs[0]['meanSeedError'])}% → {num(100*rs[-1]['meanSeedError'])}% |")
add('\nThese small GPU jobs have a substantial dispatch/readback floor, so a 16× ray increase is not a 16× latency increase. It does increase attempted path work. Object count also changes occlusion, available edge paths and termination; these timings are measurements, not a proof of logarithmic BVH cost.\n')
add('![Accuracy and timing versus ray budget](benchmarks/spatial-accuracy-scaling.png)\n')
add('### Independent wave reference and its uncertainty\n')
add('| Scene | Hz | Fine mesh h (m) | Unknowns | Last mesh change | Wave solve + map s | GPU transport map s at 256 |\n|---|---:|---:|---:|---:|---:|---:|')
for c in cases:
 for hz in c['frequencies']:
  r=[r for r in c['references'] if r['hz']==hz][-1];g=next(r for r in c['aggregate'] if r['hz']==hz and r['rays']==256)
  add(f"| {c['name']} | {hz:g} | {r['meshSize']:g} | {r['dofs']} | {100*r['previousMeshChange']:.3f}% | {r['seconds']:.3f} | {g['meanMapSeconds']:.3f} |")
add('\nWave times are CPU assembly/factorization/evaluation for **one frequency and all probes**, with meshing excluded. GPU map time is the sum of measured transport queries for one seed; it computes three bins together. The implementations, frequency counts and scopes differ, so these columns are not a clean algorithmic speedup ratio. Timings are individual low-priority wave runs versus medians of many GPU queries, not precision hardware benchmarks.\n')
add('Planar reference meshes h = 0.7, 0.5 and 0.35 m use polynomial order four, a 9 m physical radius and a 3 m absorbing layer, plus 48 longitudinal quadrature nodes. Finite 3D rooms use order four and two spatial refinements, h = 0.65/0.45 m for the small room and 1.3/0.9 m for the larger rooms. The observed last mesh change is **not a certified total error bound**. References solve steady-state waves; the ray path depth/support are finite, so the renderer error includes truncation as well as estimator/model error. Materials and the exp(+iωt), exp(-ikr)/r source convention match. No measured real-world truth or broadband accuracy is claimed.\n')
small=OUT/'room-6m-4/reference-0.9-125.json';large=OUT/'room-12m-4/reference-0.9-125.json'
if small.exists():
 a,b=[json.loads(p.read_text()) for p in [small,large]]
 add(f"A separate **fixed-resolution** size comparison holds h = 0.9 m, order four and 125 Hz constant: increasing the room from 72 to 576 m³ changes unknowns from {a['dofs']:,} to {b['dofs']:,} and wave solve/map time from {a['seconds']:.3f} to {b['seconds']:.3f} s ({b['seconds']/a['seconds']:.1f}×). Two sizes do not establish an asymptotic exponent. Main-table fine meshes use different h, so their similar times alone cannot imply size-independent wave cost.\n")
add('At fixed wavelength resolution, the number of volume unknowns grows roughly with area in a 2D solve and volume in 3D; sparse factorization adds fill-in and memory costs. The planar point-source reference repeats solves across longitudinal quadrature nodes. The ray loop instead spends work on source–receiver pairs × bins × ray budget × path depth, with visibility traversal, edge proposals and divergence inside each step. Scene size in metres alone is not its cost parameter. The route-enumerating CPU prototype has combinatorial path growth with edge/mirror count and depth.\n')
add('### Controls and depth/support sensitivity\n')
control=[];p=OUT/'free-control';csv=np.genfromtxt(p/'renderer.csv',delimiter=',',names=True)
for hz in [125,250]:
 ref=np.load(p/f'reference-0-{hz:g}.npz')['pressure'];rows=csv[(csv['hz']==hz)&(csv['rays']==256)];err=float(np.linalg.norm(rows['real']+1j*rows['imag']-ref)/np.linalg.norm(ref));control.append(dict(hz=hz,complexL2=err))
add(f"Empty 3D space agrees with analytic exp(-ikr)/r to {max(c['complexL2'] for c in control)*100:.6f}% complex error. Across the main maps, direct-visibility disagreements with independent analytic pillar/box occlusion total **{sum(r['directVisibilityDisagreements'] for c in cases for r in c['rows'])}**. These controls do not validate the higher-order acoustic estimator.\n")
support=[]
add('| Scene subset | Interactions | Support s | Complex error at 256 rays/bin | Query ms |\n|---|---:|---:|---:|---:|')
for name in ['planar-1','room-12m-25']:
 base=OUT/name;c=json.loads((base/'scene.json').read_text());hz=250 if name.startswith('planar') else 125
 ref=np.load(sorted(base.glob(f'reference-*-{hz}.npz'),key=lambda p:float(p.name.split('-')[1]))[0])['pressure']
 for b,d in [(2,.4),(4,.4),(8,.4),(16,.4),(8,.8)]:
  p=OUT/f'{name}-support-b{b}-d{d:g}'
  if not (p/'renderer.csv').exists():continue
  ids=np.array(json.loads((p/'indices.json').read_text()));rows=np.genfromtxt(p/'renderer.csv',delimiter=',',names=True);errors=[]
  for seed in c['seeds']:
   a=np.sort(rows[(rows['hz']==hz)&(rows['seed']==seed)],order='point');assert len(a)==len(ids);errors.append(float(np.linalg.norm(a['real']+1j*a['imag']-ref[ids])/np.linalg.norm(ref[ids])))
  row=dict(scene=name,bounces=b,seconds=d,points=len(ids),hz=hz,meanSeedError=float(np.mean(errors)),medianMs=float(np.median(rows['solve_seconds'])*1000));support.append(row)
  add(f"| {name}, {len(ids)} probes | {b} | {d:g} | {num(row['meanSeedError']*100)}% | {row['medianMs']:.3f} |")
add('\nSubsets use every seventeenth point, selected without looking at errors. Four identical seed IDs and a fixed 256 rays/bin budget are used; changing support changes the sampling distribution, so differences include sampling noise. This is a diagnostic, not a tuned production preset or proof that two interactions are physically sufficient.\n')
add('In these two subsets the large errors appear by four interactions; increasing depth further or doubling support from 0.4 to 0.8 seconds does not fix them. This makes insufficient late-path support an inadequate explanation for the observed blow-ups. Two-interaction output still has substantial error.\n')
add('### The slower planar prototype\n')
add('This is the unchanged Python/double-precision coherent edge-integral experiment: enumerate visible routes, integrate one/two-edge diffraction with guided Sobol samples, and add unfolded mirror/mixed connections through order two. It has **not been implemented for finite 3D**. Samples are per visible route, not a global rays/bin budget; comparing equal numeric budgets to GPU rays would be misleading. A fixed coarse receiver lattice is chosen before inspecting results.\n')
add('| Layout | Probes | Samples per route | Seeds | Complex error | Shadow error | CPU seconds for subset |\n|---|---:|---:|---:|---:|---:|---:|')
for c in cases:
 for r in c.get('prototype',[]):
  add(f"| {c['name']} | {r['points']} | {r['samples']} | {4 if r['samples']==128 else 1} | {100*r['meanSeedError']:.2f}% | {100*r['meanSeedShadowError']:.2f}% | {r['meanSeconds']:.3f} |")
add('\n32/512-sample rows use seed 17 as budget checks; 128-sample rows use all four seeds. These sparse-probe errors cannot be directly ranked against full-map GPU errors. The raw archive retains probe indices for matching comparisons. No interpolation of the sparse prototype samples is treated as a dense acoustic field.\n')
add('Matched-position check at 250 Hz, four seeds, prototype 128 samples/route versus GPU 256 rays/bin. Time is for the same receiver subset; the GPU calculates three bins and the CPU prototype one frequency, so this is not compute matching.\n')
add('| Layout | Prototype error | GPU subset error | Prototype s | GPU transport s |\n|---|---:|---:|---:|---:|')
for c in cases:
 for r in c.get('prototype',[]):
  if r['samples']==128:add(f"| {c['name']} | {100*r['meanSeedError']:.2f}% | {num(100*r['gpu256SubsetMeanSeedError'])}% | {r['meanSeconds']:.3f} | {r['gpu256SubsetMeanSeconds']:.3f} |")
add()
add('### Consequence for the implementation\n')
add('1. Do not use the current larger-scene GPU output as a high-fidelity training target. More rays or an audio upscaler cannot establish that its expected pressure is correct.\n2. Keep the exact BVH intersection path. The measured geometry/visibility controls pass; changing to SDF would not address these pressure errors.\n3. Isolate one-edge, two-edge, reflection/edge and repeated-edge contributions against the existing coherent reference before increasing path depth. Check probability compensation, singular angular terms and cancellation at shadow boundaries. The present measurements locate the failure in acoustic estimation but do not prove one exact faulty line.\n4. Require larger-scene stability and agreement in matched planar fixtures before transferring the coherent prototype to finite 3D. Retain phase, finite edge extent, material reflection and an honest path-support convergence check.\n')
add('### Evidence and reproduction\n')
add('[Raw measurements and benchmark scripts](benchmarks/spatial-accuracy-2026-10-20.zip) · [Unrounded result ledger](benchmarks/spatial-accuracy-2026-10-20.json).\n')
validation=json.loads((OUT/'validation.json').read_text())
add('The original combined batch wrote all 149,028 pressure rows and completion markers, then Unity marked it failed for exceeding its 180-second test timeout. That XML is retained. A follow-up with **17 separate tests passed**; 1,736 pressure values at fixed spatial subsets reproduced exactly, and every full map passed row-count, finite-value and point-order checks. The failed wrapper is not reported as a passed test.\n')
add(f"Measured runtime commit `{json.loads((OUT/'manifest.json').read_text())['gitHead']}`. Production shader/source hashes are in the GPU provenance files. The only temporary fixture change selects diffraction-on measurements; it calls the existing transport solver. Temporary Unity fixtures are removed after each batch. All raw files live in `.context/spatial-accuracy/`: scene JSON, wave NPZ/metadata, GPU CSV/XML/log/provenance, support runs, prototype fields and timings, and plotting/report scripts. `summary.json` stores unrounded metrics; the tracked benchmark ledger includes those metrics plus controls/support results.\n")
add('Reproduce in a fresh output directory using the supplied `run.py` preparation/reference/GPU stages, then `prototype.py`, `analyze.py` and `plot.py`. The isolated runner must match the current runtime byte-for-byte and be closed. Scripts refuse to overwrite key measurement outputs. Numerical libraries are optional offline dependencies, not Unity/runtime dependencies.\n')
text='\n'.join(lines)+'\n';(OUT/'report.md').write_text(text)
report=dict(cases=cases,controls=control,support=support,validation=validation,manifest=json.loads((OUT/'manifest.json').read_text()),
    benchmarkSources={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [OUT/'run.py',OUT/'prototype.py',OUT/'analyze.py',OUT/'plot.py',OUT/'extra_reference.py']})
save_json(OUT/'report.json',report)
print('Report saved',flush=True)
