import hashlib,json,shutil,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
DEST=Path('/Users/clarkpeng/conductor/workspaces/realisticaudioraytracing2d/tyler/.context')
bench=ROOT/'docs/benchmarks'
for name in ['larger-2d-maps.png','larger-3d-maps.png','room-3d-height-slices.png','room-3d-positional-field.png','spatial-accuracy-scaling.png']:
 shutil.copy2(OUT/name,bench/name)
shutil.copy2(OUT/'report.json',bench/'spatial-accuracy-2026-10-20.json')
section=(OUT/'report.md').read_text();doc=ROOT/'docs/cleanup-results.md';text=doc.read_text()
assert section.splitlines()[0] not in text,'Preserve an already exported section'
heading,body=text.split('\n\n',1);doc.write_text(heading+'\n\n'+section+'\n'+body)
(DEST/'spatial-accuracy-report.md').write_text('# Acoustic accuracy and scaling\n\n'+section.replace('benchmarks/',str(bench)+'/'))
archive=bench/'spatial-accuracy-2026-10-20.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(OUT.rglob('*')):
  if p.is_file() and p.suffix in {'.py','.json','.npz','.csv','.xml','.cs','.log','.txt','.md'} and '__pycache__' not in p.parts:
   z.write(p,p.relative_to(ROOT))
 for name in ['edge_integral.py','planar_wave.py','room_wave.py','compare_wave_field.py']:
  z.write(ROOT/'tools'/name,'.context/spatial-accuracy/measured-tools/'+name)
 bad=z.testzip();assert bad is None,bad
print('Exported report, five figures, ledger and raw archive',round(archive.stat().st_size/1024**2,2),'MiB')
