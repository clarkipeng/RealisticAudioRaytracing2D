using System; using System.IO; using System.Collections.Generic; using NUnit.Framework; using UnityEngine;
public partial class TakeChecks {
 public static IEnumerable<string> SpatialCases() => File.ReadAllLines(Environment.GetEnvironmentVariable("SPATIAL_CASES"));
 [TestCaseSource(nameof(SpatialCases)), Category("QualityMeasurement")]
 public void SpatialStudy(string path) {
  Debug.Log("SPATIAL BEGIN "+path); Environment.SetEnvironmentVariable("ACOUSTIC_WAVE_OUTPUT",path);
  MeasureWaveField(); Debug.Log("SPATIAL COMPLETE "+path);
 }
}
