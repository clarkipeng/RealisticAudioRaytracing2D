import hashlib,json,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
from compare_wave_field import save_json,shadow_mask

def relative(a,b):return float(np.linalg.norm(a-b)/np.linalg.norm(b))
def evaluate(actual,ref,shadow):
    floor=np.sqrt(np.mean(abs(ref)**2))*1e-6
    db=20*np.log10(np.maximum(abs(actual),floor)/np.maximum(abs(ref),floor))
    return dict(complexL2=relative(actual,ref),magnitudeL2=relative(abs(actual),abs(ref)),
        shadowComplexL2=relative(actual[shadow],ref[shadow]) if shadow.any() else None,
        levelMedianAbsDb=float(np.median(abs(db))),levelP95AbsDb=float(np.quantile(abs(db),.95)),
        fractionWithin3dB=float(np.mean(abs(db)<=3)),maximumPressure=float(abs(actual).max()))

def gather():
    result=[]
    for name in json.loads((OUT/'manifest.json').read_text())['cases']:
        p=OUT/name;c=json.loads((p/'scene.json').read_text());points=np.array(c['points']).reshape(-1,3)
        walls=c.get('walls',c.get('obstacles',[]));shadow=shadow_mask(dict(c,walls=walls),points)
        item=dict(name=name,points=len(points),shadowPoints=int(shadow.sum()),objectCount=len(walls),
                  physicalModel=c['physicalModel'],frequencies=c['frequencies'],references=[],rows=[],aggregate=[])
        if (p/'renderer-scene.json').exists():
            rc=json.loads((p/'renderer-scene.json').read_text());item['primitives']=len(rc['triangleMaterials'])+12
        else:item['primitives']=4*len(walls)
        for hz in c['frequencies']:
            files=sorted(p.glob(f'reference-*-{hz:g}.npz'),key=lambda f:float(f.name.split('-')[1]),reverse=True)
            if not files:continue
            last=None
            for f in files:
                data=np.load(f);r=data['pressure'];np.testing.assert_allclose(data['points'],points)
                meta=json.loads(f.with_suffix('.json').read_text())
                assert meta['sceneSha256']==hashlib.sha256((p/'scene.json').read_bytes()).hexdigest()
                if last is not None:meta.update(previousMeshChange=relative(last,r),shadowMeshChange=relative(last[shadow],r[shadow]) if shadow.any() else None)
                meta['file']=f.name;item['references'].append(meta);last=r
            if not (p/'renderer.csv').exists():continue
            csv=np.genfromtxt(p/'renderer.csv',delimiter=',',names=True)
            ref=np.load(files[-1])['pressure']
            for rays in c['rays']:
                values=[];times=[];metrics=[]
                for seed in c['seeds']:
                    rows=csv[(csv['hz']==hz)&(csv['rays']==rays)&(csv['seed']==seed)]
                    if len(rows)!=len(points):continue
                    rows=np.sort(rows,order='point');np.testing.assert_array_equal(rows['point'],np.arange(len(points)))
                    a=rows['real']+1j*rows['imag'];assert np.isfinite(a).all()
                    checks=evaluate(a,ref,shadow);checks['directVisibilityDisagreements']=int(np.count_nonzero(rows['direct_visible'].astype(bool)!=~shadow));values.append(a);times.extend(rows['solve_seconds']);metrics.append(checks)
                    item['rows'].append(dict(hz=hz,rays=rays,seed=seed,medianMs=float(np.median(rows['solve_seconds'])*1e3),
                        mapSeconds=float(rows['solve_seconds'].sum()),**checks))
                if len(values)!=len(c['seeds']):continue
                values=np.array(values);mean=values.mean(axis=0)
                row=dict(hz=hz,rays=rays,meanSeedError=float(np.mean([m['complexL2'] for m in metrics])),
                     minSeedError=float(min(m['complexL2'] for m in metrics)),maxSeedError=float(max(m['complexL2'] for m in metrics)),
                     meanSeedMagnitudeError=float(np.mean([m['magnitudeL2'] for m in metrics])),
                     meanSeedShadowError=float(np.mean([m['shadowComplexL2'] for m in metrics])) if shadow.any() else None,
                     meanLevelMedianAbsDb=float(np.mean([m['levelMedianAbsDb'] for m in metrics])),
                     meanLevelP95AbsDb=float(np.mean([m['levelP95AbsDb'] for m in metrics])),
                     meanFractionWithin3dB=float(np.mean([m['fractionWithin3dB'] for m in metrics])),
                     fourSeedMeanError=relative(mean,ref),seedRmsOverReference=float(np.sqrt(np.mean(np.sum(abs(values-mean)**2,axis=1)))/np.linalg.norm(ref)),
                     medianMs=float(np.median(times)*1e3),p95Ms=float(np.quantile(times,.95)*1e3),meanMapSeconds=float(np.sum(times)/len(c['seeds'])))
                # Adjacent spatial residual changes; never compare the end/start of flattened rows.
                index=np.full(len(c['x'])*len(c['y'])*len(c['z']),-1);index[c['gridIndices']]=np.arange(len(points));index=index.reshape(len(c['z']),len(c['y']),len(c['x']))
                a,b=[],[]
                for u,v in [(index[:,:,:-1],index[:,:,1:]),(index[:,:-1,:],index[:,1:,:]),(index[:-1,:,:],index[1:,:,:])]:
                    mask=(u>=0)&(v>=0);a.extend(u[mask]);b.extend(v[mask])
                residual=values-ref
                row['adjacentResidualRmsOverReferenceRms']=float(np.sqrt(np.mean(abs(residual[:,a]-residual[:,b])**2))/np.sqrt(np.mean(abs(ref)**2)))
                item['aggregate'].append(row)
        if (p/'prototype.json').exists():
            proto=json.loads((p/'prototype.json').read_text());data=np.load(p/'prototype.npz');ids=data['indices'];item['prototype']=[]
            fine=sorted(p.glob('reference-*-250.npz'),key=lambda f:float(f.name.split('-')[1]))[0]
            ref=np.load(fine)['pressure'][ids]
            for n in [32,128,512]:
                key=f'samples{n}'
                if key not in data:continue
                metrics=[evaluate(a,ref,shadow[ids]) for a in data[key]]
                gpu_errors=[];gpu_times=[]
                for seed in (c['seeds'] if len(data[key])==4 else [17]):
                    rows=np.sort(csv[(csv['hz']==250)&(csv['rays']==256)&(csv['seed']==seed)],order='point')[ids]
                    gpu_errors.append(relative(rows['real']+1j*rows['imag'],ref));gpu_times.append(float(rows['solve_seconds'].sum()))
                item['prototype'].append(dict(samples=n,points=len(ids),hz=250,
                    meanSeedError=float(np.mean([r['complexL2'] for r in metrics])),
                    meanSeedShadowError=float(np.mean([r['shadowComplexL2'] for r in metrics])),
                    meanSeconds=float(np.mean([r['seconds'] for r in proto['rows'] if r['samples']==n])),
                    gpu256SubsetMeanSeedError=float(np.mean(gpu_errors)),gpu256SubsetMeanSeconds=float(np.mean(gpu_times)),
                    meanLevelMedianAbsDb=float(np.mean([r['levelMedianAbsDb'] for r in metrics]))))
        result.append(item)
    save_json(OUT/'summary.json',dict(cases=result,scope='One source, scalar pressure, stationary fields; four seeds; no fitting or normalization.'))
    for item in result:
        print(item['name'],item['points'],'points',item['primitives'],'primitives')
        for hz in item['frequencies']:
            refs=[r for r in item['references'] if r['hz']==hz]
            if refs:print(' ref',hz,'change',round(100*refs[-1].get('previousMeshChange',0),3),'%',round(refs[-1]['seconds'],3),'s')
        for r in item['aggregate']:
            print(' GPU',r['hz'],r['rays'],'error',round(r['meanSeedError']*100,2),'%',round(r['medianMs'],3),'ms', 'p95 level',round(r['meanLevelP95AbsDb'],2),'dB')
        for r in item.get('prototype',[]):print(' prototype',r)
    return result
if __name__=='__main__':gather()
