// A face may cross mesh-owner seams. Test the whole inter-edge segment against
// the union of coplanar triangles; coplanarity alone also includes real gaps.
bool CompleteFaceInterval(uint id,uint state,float3 start,float3 end,float3 normal,out float2 interval)
{
    interval=float2(0,1);Primitive p=Primitives[id];State pose=States[state+p.indices.x];
    if((pose.flags.x&3)!=3)return false;
    float3 v[3]={pose.position.xyz+Rotate(pose.rotation,p.a.xyz),
                 pose.position.xyz+Rotate(pose.rotation,p.b.xyz),
                 pose.position.xyz+Rotate(pose.rotation,p.c.xyz)};
    for(uint i=0;i<3;i++)if(abs(dot(v[i]-start,normal))>RayEpsilon)return false;
    float3 n=cross(v[1]-v[0],v[2]-v[0]);float area=length(n);if(area<=1e-12)return false;n/=area;
    for(uint i=0;i<3;i++)
    {
        float3 side=cross(n,v[(i+1)%3]-v[i]);float size=length(side);if(size<=1e-12)return false;side/=size;
        float a=dot(start-v[i],side)+RayEpsilon,b=dot(end-v[i],side)+RayEpsilon;
        if(a<0 && b<0)return false;
        if(a<0)interval.x=max(interval.x,a/(a-b));
        if(b<0)interval.y=min(interval.y,a/(a-b));
    }
    return interval.x<=interval.y;
}
bool CompleteFaceCovers(uint state,float3 start,float3 end,float3 normal)
{
    float covered=0;
    // Greedy interval union needs no per-path allocation or triangle ordering.
    // Each successful pass consumes at least one previously uncovered interval.
    for(uint pass=0;pass<PrimitiveCount;pass++)
    {
        float previous=covered;
        for(uint i=0;i<PrimitiveCount;i++)
        {
            float2 interval;
            if(CompleteFaceInterval(i,state,start,end,normal,interval) && interval.x<=covered)
                covered=max(covered,interval.y);
            if(covered>=1)return true;
        }
        if(covered==previous)return false;
    }
    return false;
}
float CompleteSolidConnectionWeight(uint first,uint second,uint state,float3 start,float3 end)
{
    Edge a=Edges[first],b=Edges[second];
    if(a.ids.y==a.ids.z && b.ids.y==b.ids.z)return 1;
    float3 an[2]={a.normal.xyz,cos(a.face.w)*a.normal.xyz-sin(a.face.w)*a.face.xyz};
    float3 bn[2]={b.normal.xyz,cos(b.face.w)*b.normal.xyz-sin(b.face.w)*b.face.xyz};
    for(uint i=0;i<2;i++)
    {
        float3 normal=Rotate(States[state+a.ids.x].rotation,an[i]);
        if(abs(dot(normal,end-start))>RayEpsilon)continue;
        for(uint j=0;j<2;j++)
            if(abs(dot(normal,Rotate(States[state+b.ids.x].rotation,bn[j])))>.99999 &&
               CompleteFaceCovers(state,start,end,normal))return .5;
    }
    return 1;
}
