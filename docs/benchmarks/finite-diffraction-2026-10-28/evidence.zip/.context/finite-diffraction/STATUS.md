# Finite 3D adaptation checkpoint — 2026-10-28

Both fixes are validated and ready for the local commit: transverse-radius peak guidance; complete finite DD exterior-limit visibility and continuous coplanar face multiplicity independent of mesh owner. 22 final correctness cases and 7 measurement cases pass. Final Unity worker1563/session22405 ended successfully; no worker remains. All source hashes match coverage-compiled/ and final/.

Full canopy error improves43.04%→40.73%; shadow123.94%; quality gate still fails. At1M samples indoor error65.6–68.3%. Physical mesh representation remains unresolved: illuminated split cube11.4% different from unsplit on both seeds; true union canopy differs substantially from separate boxes. completeRouteSamples remains opt-in0 and Church presets unchanged. No audio played, no clipping/fitting. Residual32walk unchanged.

Current docs and archived raw evidence: docs/benchmarks/finite-diffraction-2026-10-28/. Contracts and experiment history updated. Archive includes failures and rejected adjacent-endpoint proposal. Reference source in .context/two-edge/reference/. Actual authorized repo is UnityGames/realisticaudioraytracing2d, main, base564c96a. UserRecovery files untouched. No agents/noLavish. Guarded isolated runner nice19, one worker,20% work pacing,3GiB sampled parentRSS. Final run peak sampled parent RSS1.823GB. No taskpolicy -b.

Follow-on work: physical acoustic exterior-boundary construction with material ownership, then order convergence on that canonical geometry; do not claim samples alone or geometry union alone solve full-room fidelity. Current two-event adapter is not a full room solver. See README for scopes and actual measurements.
