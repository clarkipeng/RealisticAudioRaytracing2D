"""Rigid cube, exactly second diffraction order; not a full-wave reference.

Independent cylindrical beta formula and shared-face multiplicity from
EDtoolbox EDwedge2nd.m, commit 67e53c4f510c0033821c9c879f91652d1a131244.
Continuous frequency-domain integration avoids the toolbox's IR binning error.
Cube [-1,1]^3, source (-3,0,0), receiver (3,0,0), c=343, unit p*r.
Four equivalent pairs of parallel edges around the four side faces.
"""
import json
from pathlib import Path
import numpy as np
from numpy.polynomial.legendre import leggauss

NU = 2/3
THETA_SOURCE = np.arctan2(-1, -2) % (2*np.pi)
THETA_RECEIVER = np.arctan2(2, 1)

def beta(theta_s, theta_r, cosh_eta):
    phi = NU*(np.pi + np.array([theta_s+theta_r, theta_s-theta_r,
                                -theta_s+theta_r, -theta_s-theta_r]))
    ch = np.cosh(NU*np.arccosh(np.maximum(1, cosh_eta)))
    return np.sum(np.sin(phi)/(ch[..., None]-np.cos(phi)), axis=-1)

def integrand(a, b):
    m = np.sqrt(5+a*a)
    n = np.sqrt(4+(a-b)**2)
    l = np.sqrt(5+b*b)
    ba = beta(THETA_SOURCE, 0, (a*(a-b)+m*n)/(2*np.sqrt(5)))
    bb = beta(1.5*np.pi, THETA_RECEIVER, (b*(b-a)+n*l)/(2*np.sqrt(5)))
    # One half for an inter-edge leg along a solid face (EDwedge2nd multfac).
    return .5*NU**2/(16*np.pi**2)*ba*bb/(m*n*l), m+n+l

def reference(nodes, planar=False):
    z, w = leggauss(nodes)
    if planar:
        # Infinite extrusion truncated at the same 0.1 s travel horizon as GPU.
        z = np.tan(z*np.pi/2)
        w = w*np.pi/2*(1+z*z)
    gain, distance = integrand(z[:,None],z[None,:])
    gain = gain*(distance <= .1*343)*w[:,None]*w[None,:]*(2 if planar else 4)
    return {str(f): [float(x.real),float(x.imag)] for f in [0,125,250,500]
            for x in [np.sum(gain*np.exp(-2j*np.pi*f/343*distance))]}

if __name__ == '__main__':
    rows = {str(n): reference(n) for n in [16,32,64,128]}
    Path(__file__).with_name('cube-reference.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps(rows,indent=2))
