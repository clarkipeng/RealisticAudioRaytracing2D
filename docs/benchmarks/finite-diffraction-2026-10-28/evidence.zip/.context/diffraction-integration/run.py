"""Guard one isolated Unity regression run. No player or speaker output."""
import argparse,hashlib,json,os,signal,subprocess,time,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser();p.add_argument('output',type=Path);p.add_argument('--category');p.add_argument('--filter');p.add_argument('--job',type=Path);a=p.parse_args()
runner=ROOT/'.context/gpu-audio/runner';out=a.output.resolve()
if out.exists() or (runner/'Temp/UnityLockfile').exists():raise RuntimeError('Use an unused output and closed isolated runner.')
out.mkdir(parents=True)
files={}
for folder in ['Assets/Scripts','Assets/Shaders','Assets/Resources/Acoustics','Assets/Tests/Editor','Assets/Editor']:
 for src in (ROOT/folder).rglob('*'):
  if src.is_file():
   target=runner/src.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True)
   if not target.exists() or src.read_bytes()!=target.read_bytes():shutil.copy2(src,target)
   if src.suffix!='.meta':files[str(src.relative_to(ROOT))]=hashlib.sha256(src.read_bytes()).hexdigest()
(out/'provenance.json').write_text(json.dumps(files,indent=2)+'\n')
command=['nice','-n','19','/Applications/Unity/Hub/Editor/6000.4.1f1/Unity.app/Contents/MacOS/Unity','-batchmode','-force-metal','-disable-audio','-job-worker-count','1','-projectPath',str(runner),'-runTests','-testPlatform','EditMode','-testResults',str(out/'tests.xml'),'-logFile',str(out/'unity.log')]
if a.job:
 command=command[:command.index('-runTests')]+['-executeMethod','TakeBatch.Render','-takeJob',str(a.job.resolve()),'-logFile',str(out/'unity.log')]
if a.category:command+=['-testCategory',a.category]
if a.filter:command+=['-testFilter',a.filter]
worker=subprocess.Popen(command,env=dict(os.environ,ACOUSTIC_TEST_WORK_FRACTION='.2'))
awake=subprocess.Popen(['caffeinate','-i','-w',str(worker.pid)])
print(f'Regression worker {worker.pid}; nice 19, one job worker, 20% test-process CPU work budget.',flush=True)
started=time.monotonic();samples=[]
def interrupt(signum,frame):raise KeyboardInterrupt
previous={s:signal.signal(s,interrupt) for s in [signal.SIGINT,signal.SIGTERM]}
try:
 while worker.poll() is None:
  row=subprocess.run(['ps','-p',str(worker.pid),'-o','rss=,pcpu='],capture_output=True,text=True).stdout.split()
  if len(row)==2:
   samples.append(dict(seconds=time.monotonic()-started,rssBytes=int(row[0])*1024,cpuPercent=float(row[1])))
   if samples[-1]['rssBytes']>3072*1024**2:raise RuntimeError('3 GiB parent-RSS guard exceeded.')
  time.sleep(2)
finally:
 if worker.poll() is None:
  worker.terminate()
  try:worker.wait(timeout=15)
  except subprocess.TimeoutExpired:worker.kill();worker.wait()
 awake.wait(timeout=10)
 for s,h in previous.items():signal.signal(s,h)
 (out/'resources.json').write_text(json.dumps(dict(exitCode=worker.returncode,wallSeconds=time.monotonic()-started,workFraction=.2,samples=samples),indent=2)+'\n')
raise SystemExit(worker.returncode)
