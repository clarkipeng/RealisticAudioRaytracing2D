"""Archive numerical evidence and source snapshots; exclude licensed rain PCM."""
import hashlib,json,shutil,subprocess,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
work=ROOT/'.context/route-integration';out=ROOT/'docs/benchmarks/runtime-mirrors-2026-10-27'
listen=Path('/Users/clarkpeng/conductor/workspaces/realisticaudioraytracing2d/tyler/.context/runtime-rain-integration')
checks=[]
for name in ['controls-current','guard-serial','regressions-final','bounds-and-masks','event-budget']:
 p=work/name/'tests.xml';r=ET.parse(p).getroot();resources=json.loads((p.parent/'resources.json').read_text())
 checks.append(dict(run=name,result=r.get('result'),total=int(r.get('total')),passed=int(r.get('passed')),failed=int(r.get('failed')),durationSeconds=float(r.get('duration')),parentPeakRssBytes=max(s['rssBytes'] for s in resources['samples']),tests=[dict(name=t.get('fullname'),result=t.get('result'),failure=t.findtext('failure/message')) for t in r.findall('.//test-case')]))
assert checks[0]['failed']==1 and all(c['failed']==0 for c in checks[1:])
latest={}
for check in checks:
 for test in check['tests']:latest[test['name']]=test['result']
assert all(value=='Passed' for value in latest.values())
(out/'validation.json').write_text(json.dumps(dict(uniqueFinalChecks=len(latest),uniqueFinalPassed=sum(value=='Passed' for value in latest.values()),scope='Focused numerical regressions in an isolated Unity Editor; no player, microphone, speaker or network session. Test CPU work fraction 0.2, nice 19, one job worker, 3 GiB sampled parent-RSS guard.',checks=checks),indent=2)+'\n')
for name in ['report.json','waveforms.png']:shutil.copy2(listen/name,out/name)
files={}
def add(p,name):
 assert p.suffix not in ['.wav','.f32','.mp3','.mp4','.ogg']
 files[name]=p
for run in ['orders-baseline','mirrors-first','complete-first','complete-second','complete-third','controls-first','controls-integrated','controls-current','guard-debug','guard-fixed','guard-meta','guard-next','guard-serial','regressions-final','bounds-and-masks','event-budget']:
 for name in ['renderer.csv','path-orders.csv','scene.json','provenance.json','tests.xml','resources.json']:
  p=work/run/name
  if p.exists():add(p,f'{run}/{name}')
for p in (work/'rejected-complete-edges').rglob('*'):
 if p.is_file() and p.suffix!='.bytes':add(p,str(p.relative_to(work)))
for folder in ['Assets/Scripts','Assets/Shaders','Assets/Resources/Acoustics','Assets/Tests/Editor']:
 for p in (ROOT/folder).rglob('*'):
  if p.is_file() and p.suffix in ['.cs','.hlsl','.compute','.asmdef']:add(p,'accepted-sources/'+str(p.relative_to(ROOT)))
add(work/'edge-reference-subset.npz','edge-reference-subset.npz')
add(work/'orders-input/indices.json','probe-indices.json')
add(work/'check.py','check.py');add(Path(__file__),'package.py')
for run,p in [('before',ROOT/'.context/rain-research/native-canopy/r2-s0'),('integrated',work/'rain-canopy-final')]:
 add(p/'run.json',f'rain/{run}/run.json')
add(work/'rain-canopy-final.resources.json','rain/integrated/resources.json')
add(work/'rain-canopy-final.job.json','rain/integrated/job.json')
add(work/'rain-canopy-r2-s0.resources.json','rain/canceled-before-event-budget/resources.json')
add(work/'rain-canopy-r2-s0/run.json','rain/canceled-before-event-budget/incomplete-run.json')
for name in ['README.md','compare.py','view.html','report.json','rejected-edge-report.json','validation.json']:
 add(out/name,'report/'+name)
manifest={name:hashlib.sha256(p.read_bytes()).hexdigest() for name,p in sorted(files.items())}
with zipfile.ZipFile(out/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
 for name,p in files.items():z.write(p,name)
 z.writestr('sha256.json',json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(archiveFiles=len(files),archiveBytes=(out/'evidence.zip').stat().st_size,checks=[{k:c[k] for k in ['run','passed','failed']} for c in checks]),indent=2))
