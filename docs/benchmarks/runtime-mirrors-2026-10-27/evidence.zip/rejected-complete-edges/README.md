# Rejected finite-3D complete-edge candidate

This candidate must not become the production default. It extends the earlier parallel/infinite-edge height proposal to general finite 3D edges, samples complete discrete chains, conditions heights on incoming cone roots and an outgoing whole-chain guide, retains each sampled arrival, and compresses residual surface-prefix arrivals by importance resampling. It preserves exact PDFs and support through configured maxBounces; it does not clamp pressure.

The 38-probe 250 Hz diagnostic uses 32 interactions, 1.25 s support, 128 rays, and the same refined BEM field as the prior comparison. The seed-0 complex relative L2 error increased from about 489% to 1400%; seed-1 error was 416%. Median warm solve/readback increased from about 2–3 ms to 12–13 ms. These are diagnostic probes, not full-map acceptance results. The outcome rejects promotion regardless of the atomic control results.

Sources here are the isolated runner snapshot used by controls-first; runtime sources match complete-third (the measurement) before the subsequent general shared-walk filter-storage bound. Complete-first and complete-second were shader failures and provide no physical accuracy evidence. Complete-third is the valid measurement. R2+ and mixed mirror/edge complete-route families were not implemented in this candidate.
