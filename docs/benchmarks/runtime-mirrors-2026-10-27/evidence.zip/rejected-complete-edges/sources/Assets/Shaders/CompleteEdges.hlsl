// Complete finite-edge routes. Topology is selected before the height integral;
// every sample keeps its arrival, rather than reducing a broadband path to one
// complex pressure. This uses the same signed wedge integrand as Transport.hlsl.
RWStructuredBuffer<uint> CompleteEdgeNodes;
RWStructuredBuffer<RayPath> CompleteEdgeArrivals;
uint UseCompleteEdges;

float RouteAngle(float y,float x)
{
    // The offline integrator's accurate positive atan2, including narrow tails.
    float t=y/(length(float2(x,y))+abs(x));t/=sqrt(1+t*t)+1;
    float s=t*t,p=-1.0/19;
    [unroll] for(int n=8;n>=1;n--)p=(n%2==0?1.0:-1.0)/(2*n+1)+s*p;
    float a=4*t*(1+s*p);return x<0?RayPi-a:a;
}
bool RouteExterior(uint edge,uint stateOffset,float3 location,bool is2D)
{
    float3 a,axis,face,normal;float extent,angle;
    EdgeFrame(edge,stateOffset,is2D,a,axis,face,normal,extent,angle);
    return EdgeAngle(location-a,face,normal,angle)<=angle;
}
float3 RouteAnchor(uint edge,uint stateOffset,bool is2D)
{
    float3 a,axis,face,normal;float extent,angle;
    EdgeFrame(edge,stateOffset,is2D,a,axis,face,normal,extent,angle);
    return a+(is2D?0:.5*extent)*axis;
}
bool RoutePairPossible(uint first,uint second,uint stateOffset,bool is2D)
{
    if(first==second)return false;
    float3 a,axis,face,normal;float extent,angle;
    EdgeFrame(first,stateOffset,is2D,a,axis,face,normal,extent,angle);
    // A convex solid wedge excludes an entire segment only if both endpoints
    // lie strictly inside it. Never reject a finite edge from centre visibility.
    if(!RouteExterior(second,stateOffset,a,is2D) && !RouteExterior(second,stateOffset,a+axis*extent,is2D))
    {
        float3 unused;float otherExtent,otherAngle;
        EdgeFrame(second,stateOffset,is2D,unused,axis,face,normal,otherExtent,otherAngle);
        if(otherAngle>=RayPi)return false;
    }
    EdgeFrame(second,stateOffset,is2D,a,axis,face,normal,extent,angle);
    if(!RouteExterior(first,stateOffset,a,is2D) && !RouteExterior(first,stateOffset,a+axis*extent,is2D))
    {
        float3 unused;float otherExtent,otherAngle;
        EdgeFrame(first,stateOffset,is2D,unused,axis,face,normal,otherExtent,otherAngle);
        if(otherAngle>=RayPi)return false;
    }
    return true;
}
float RouteChoiceMass(uint edge,uint previous,uint remaining,uint stateOffset,float3 source,float3 end,bool is2D)
{
    if((States[stateOffset+Edges[edge].ids.x].flags.x&3)!=3)return 0;
    if(previous==0xffffffff)
    {if(!RouteExterior(edge,stateOffset,source,is2D))return 0;}
    else if(!RoutePairPossible(previous,edge,stateOffset,is2D))return 0;
    if(remaining==1 && !RouteExterior(edge,stateOffset,end,is2D))return 0;
    float3 a=previous==0xffffffff?source:RouteAnchor(previous,stateOffset,is2D);
    float3 b=RouteAnchor(edge,stateOffset,is2D);
    // A guide, not a visibility predicate: finite-edge endpoints can be visible
    // when their centres are not. The nonzero component retains that support.
    return Visible(stateOffset,a,b,is2D)?1:.125;
}
void RoutePeak(inout uint count,inout float centers[13],inout float scales[13],float center,float scale)
{
    centers[count]=center;scales[count]=max(1e-8,scale);count++;
}
float RouteHeight(uint edge,uint previous,uint stateOffset,float3 before,float3 source,float3 next,
                  float3 end,float remaining,float travelled,bool is2D,inout uint rng,out float inversePdf)
{
    inversePdf=0;
    float3 a,axis,face,normal;float extent,angle;
    EdgeFrame(edge,stateOffset,is2D,a,axis,face,normal,extent,angle);
    float3 s=source-a,r=next-a;
    float zs=dot(s,axis),zr=dot(end-a,axis),rs=length(s-zs*axis);
    float rr=max(RayEpsilon,remaining),nu=RayPi/angle;
    float budget=MaximumPathDelay*SpeedOfSound-travelled;
    float lo=is2D?zs-budget:0,hi=is2D?zs+budget:extent;
    if(rs<=RayEpsilon || budget<=rs || hi<=lo)return 0;
    float center=(zs*rr+zr*rs)/(rs+rr);
    float m=length(float2(rs,zs-center)),l=length(float2(rr,zr-center));
    float4 phi=nu*EdgeAngles(EdgeAngle(s,face,normal,angle),EdgeAngle(r,face,normal,angle));
    float centers[13],scales[13];uint count=0;
    [unroll] for(uint initialize=0;initialize<13;initialize++){centers[initialize]=0;scales[initialize]=0;}
    // Component zero is uniform on the physical support. Nonparallel edges can
    // move angular peaks; this component keeps all heights reachable.
    centers[0]=0;scales[0]=0;count=1;
    [unroll] for(uint term=0;term<4;term++)
        if(abs(sin(phi[term]*.5))>1e-6)RoutePeak(count,centers,scales,center,2*abs(sin(phi[term]*.5))*m*l/((m+l)*nu));
    if(previous!=0xffffffff)
    {
        float3 pa,pu,pf,pn;float pe,angleBefore;
        EdgeFrame(previous,stateOffset,is2D,pa,pu,pf,pn,pe,angleBefore);
        float3 incoming=before-source,d=a-source;
        float z=dot(incoming,pu),radial2=dot(incoming,incoming)-z*z;
        float c=dot(axis,pu),d0=dot(d,pu),dv=dot(d,axis),norm2=dot(d,d),length2=radial2+z*z;
        // eta=0 for the preceding wedge is a cone. Intersect it with this edge;
        // parallel axes reduce to the prototype's one incoming Cauchy peak.
        float qa=length2*c*c-z*z,qb=2*(length2*d0*c-z*z*dv),qc=length2*d0*d0-z*z*norm2;
        float roots[2]={0,0};uint rootsCount=0;
        if(abs(qa)<1e-8*max(length2,1e-8))
        {if(abs(qb)>1e-12)roots[rootsCount++]=-qc/qb;}
        else
        {
            float discriminant=qb*qb-4*qa*qc;
            if(discriminant>=0)
            {
                float q=-.5*(qb+(qb<0?-1:1)*sqrt(discriminant));
                if(q!=0){roots[rootsCount++]=q/qa;roots[rootsCount++]=qc/q;}
                else roots[rootsCount++]=-qb/(2*qa);
            }
        }
        for(uint root=0;root<rootsCount;root++)
        {
            float t=roots[root];float3 outgoing=d+t*axis;float axial=dot(outgoing,pu);
            float radius2=max(0,dot(outgoing,outgoing)-axial*axial);
            if(axial*z>RayEpsilon || radius2<=RayEpsilon*RayEpsilon)continue;
            float derivative=abs((c*dot(outgoing,outgoing)-axial*dot(outgoing,axis))/(radius2*length(outgoing)));
            if(derivative<=1e-12)continue;
            float pnu=RayPi/angleBefore;
            float4 pphi=pnu*EdgeAngles(EdgeAngle(incoming,pf,pn,angleBefore),EdgeAngle(outgoing,pf,pn,angleBefore));
            [unroll] for(uint term=0;term<4;term++)
                if(abs(sin(pphi[term]*.5))>1e-6 && count<13)
                    RoutePeak(count,centers,scales,t,2*abs(sin(pphi[term]*.5))/(pnu*derivative));
        }
    }
    float spans[13];spans[0]=hi-lo;
    for(uint i=1;i<count;i++)spans[i]=RouteAngle((hi-lo)*scales[i],scales[i]*scales[i]+(lo-centers[i])*(hi-centers[i]));
    uint component=min(count-1,(uint)(RandomRay(rng)*count));float u=clamp(RandomRay(rng),1e-7,1-1e-7);
    float height=component==0?lerp(lo,hi,u):lo+EdgeHeight(centers[component]-lo,scales[component],spans[component],hi-lo,u,false);
    float density=1/(hi-lo);
    for(uint i=1;i<count;i++)
    {float delta=height-centers[i];density+=scales[i]/((scales[i]*scales[i]+delta*delta)*spans[i]);}
    inversePdf=count/density;return height;
}
void PrepareCompleteEdges(uint index,bool is2D)
{
    if(index>=FrameCount*RaysPerBin)return;
    CompleteEdgeArrivals[index]=(RayPath)0;
    if(DiffractionFactor<=0 || EdgeCount==0)return;
    uint frame=index/RaysPerBin,ray=index%RaysPerBin,pair=RayTracePair,sourceIndex=pair/ListenerCount;
#if defined(ACOUSTIC_DEBUG)
    if(!DebugSelected(frame*PairCount+pair,DebugBin))return;
#endif
    uint debug=PrimitiveCount+1+RaysPerBin*(2+2*MaxBounces)+2*MirrorCandidateCount+ray*(MaxBounces+1);
    uint stateOffset=frame*ObjectCount,source=Sources[sourceIndex],listener=Listeners[pair%ListenerCount];
    uint emissionRow=frame*EmissionFrameStride+sourceIndex;uint4 plane=EmissionRanges[emissionRow];
    if(plane.y==0 || RayPairEnabled[frame*PairCount+pair]==0)return;
    uint site=plane.w==0?0:plane.w==2?ray%plane.y:(ray+HashRay(RaySeed^source))%plane.y;
    if(EmissionPoints[plane.x+site].w==0)return;
    uint localRay=plane.w==2?ray/plane.y:ray,samples=plane.w==2?1+(RaysPerBin-1-site)/plane.y:RaysPerBin;
    uint birth=plane.w==2?HashRay(EmissionClocks[plane.x+site].y)^HashRay(EmissionClocks[plane.x+site].z):0;
    uint rng=HashRay(localRay^birth^HashRay(pair+RaySeed)^0x632be59bu);
    float3 start=EmissionPosition(stateOffset,sourceIndex,site),end=States[stateOffset+listener].position.xyz;
    if(is2D){start.z=0;end.z=0;}
    if(MediumAt(stateOffset,start,is2D)!=AirMedium)return;
    // All configured orders retain nonzero probability. Stratification gives
    // low orders predictable coverage without allocating one DSP row per order.
    float normalizer=(float)MaxBounces/(MaxBounces+1),u=(localRay+RandomRay(rng))/samples;
    uint depth=min(MaxBounces,(uint)(1/(1-u*normalizer)));
    depth=max(1u,depth);float gain=normalizer*depth*(depth+1)/RaysPerBin;
    uint nodes=index*MaxBounces,previous=0xffffffff,identity=HashRay(0xa0000000u^localRay);
    for(uint n=0;n<depth;n++)
    {
        float total=0;uint chosen=0xffffffff;
        for(uint e=0;e<EdgeCount;e++)
        {
            float mass=RouteChoiceMass(e,previous,depth-n,stateOffset,start,end,is2D);
            if(mass==0)continue;total+=mass;
            if(RandomRay(rng)*total<mass)chosen=e;
        }
        if(chosen==0xffffffff)return;
        gain*=total/RouteChoiceMass(chosen,previous,depth-n,stateOffset,start,end,is2D);
        CompleteEdgeNodes[nodes+n]=chosen;previous=chosen;
        identity=HashRay(identity^(chosen+1));
    }
    float3 before=start,position=start,vertexVelocity=plane.w==2?float3(0,0,0):PointVelocity(stateOffset+source,start);
    float previousDistance=0,travelled=0,ratio=1;
    previous=0xffffffff;
    for(uint n=0;n<depth;n++)
    {
        uint edge=CompleteEdgeNodes[nodes+n];float3 a,axis,face,normal;float extent,angle;
        EdgeFrame(edge,stateOffset,is2D,a,axis,face,normal,extent,angle);
        float3 anchor=RouteAnchor(edge,stateOffset,is2D),next=n+1<depth?RouteAnchor(CompleteEdgeNodes[nodes+n+1],stateOffset,is2D):end;
        float remaining=0;float3 last=anchor;
        for(uint j=n+1;j<=depth;j++)
        {
            float3 p=j<depth?RouteAnchor(CompleteEdgeNodes[nodes+j],stateOffset,is2D):end;
            float3 delta=p-last;remaining+=length(delta-axis*dot(delta,axis));last=p;
        }
        float inverse;float height=RouteHeight(edge,previous,stateOffset,before,position,next,end,remaining,travelled,is2D,rng,inverse);
        if(!(inverse>0) || !isfinite(inverse))return;
        float3 location=a+height*axis,delta=location-position;float distance=length(delta);
        if(distance<=RayEpsilon || !Visible(stateOffset,position,location,is2D))return;
        float3 direction=delta/distance,velocity=PointVelocity(stateOffset+Edges[edge].ids.x,location);
        if(is2D){velocity.z=0;vertexVelocity.z=0;}
        ratio*=(SpeedOfSound-dot(velocity,direction))/(SpeedOfSound-dot(vertexVelocity,direction));
        if(previous!=0xffffffff)gain*=EdgeConnectionWeight(previous,edge)*EdgeKernel(previous,stateOffset,before,position,location,is2D)/previousDistance;
        gain*=inverse;travelled+=distance;
        DebugWrite(debug+n,2+2*ray,DebugDiffraction,Primitives[Edges[edge].ids.y].indices.y,
            position,location,(travelled-distance)/SpeedOfSound,travelled/SpeedOfSound,gain);
        if(travelled>MaximumPathDelay*SpeedOfSound)return;
        before=position;position=location;previousDistance=distance;previous=edge;vertexVelocity=velocity;
    }
    float last=length(end-position);
    if(last<=RayEpsilon || !Visible(stateOffset,position,end,is2D))return;
    float3 listenerVelocity=Velocity(stateOffset+listener);if(is2D)listenerVelocity.z=0;
    float3 outgoing=(end-position)/last;
    ratio*=(SpeedOfSound-dot(listenerVelocity,outgoing))/(SpeedOfSound-dot(vertexVelocity,outgoing));
    gain*=EdgeKernel(previous,stateOffset,before,position,end,is2D)/(previousDistance*last)*ReferenceDistance;
    RayPath result=Arrival(position,end,(travelled+last)/SpeedOfSound,gain,0,ratio,identity);
    // The scratch arrival's frequency field stores route depth until evaluation.
    result.frequencyBin=depth;CompleteEdgeArrivals[index]=result;
#if defined(ACOUSTIC_DEBUG)
    float coefficient=exp(-AirCoefficient(max(1,DebugBin*FrequencyStep))*result.delaySeconds*SpeedOfSound);
    for(uint n=0;n<depth;n++)coefficient*=DiffractionFactor*EdgeOpacity(CompleteEdgeNodes[nodes+n],DebugBin);
    result.pressureGain*=coefficient;result=ApplyEmission(result,emissionRow,site,samples);
    DebugArrival(debug+depth,2+2*ray,position,end,travelled/SpeedOfSound,result);
#endif
}
RayPath CompleteEdgePath(uint frame,uint ray,uint bin)
{
    uint index=frame*RaysPerBin+ray;RayPath path=CompleteEdgeArrivals[index];
    uint depth=path.frequencyBin;path.frequencyBin=bin;
    float weight=exp(-AirCoefficient(max(1,bin*FrequencyStep))*path.delaySeconds*SpeedOfSound);
    for(uint i=0;i<depth;i++)weight*=DiffractionFactor*EdgeOpacity(CompleteEdgeNodes[index*MaxBounces+i],bin);
    path.pressureGain*=weight;return path;
}
