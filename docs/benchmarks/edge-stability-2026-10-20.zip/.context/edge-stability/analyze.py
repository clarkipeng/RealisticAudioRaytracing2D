import json,hashlib,xml.etree.ElementTree as ET
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent;base=out.parent/'spatial-accuracy'
names=['planar-1','planar-9','planar-25','room-12m-25']
def read(p):
 a=np.genfromtxt(p,names=True,delimiter=',');assert all(np.isfinite(a[k]).all() for k in a.dtype.names)
 return a
def scores(a,g,c):
 result={}
 for hz in c['frequencies']:
  rows=a[(a['rays']==256)&(a['hz']==hz)];metrics=[]
  for seed in c['seeds']:
   r=rows[rows['seed']==seed];assert len(r)==len(g[hz]);assert np.array_equal(r['point'],np.arange(len(r)))
   v=r['real']+1j*r['imag'];db=20*np.log10(np.maximum(abs(v),1e-30)/np.maximum(abs(g[hz]),1e-30))
   metrics.append(dict(seed=seed,complexErrorPercent=100*float(np.linalg.norm(v-g[hz])/np.linalg.norm(g[hz])),within3dBPercent=100*float(np.mean(abs(db)<=3))))
  result[str(hz)]=dict(seeds=metrics,complexErrorPercent=float(np.mean([m['complexErrorPercent'] for m in metrics])),within3dBPercent=float(np.mean([m['within3dBPercent'] for m in metrics])),medianQueryMs=1000*float(np.median(rows['solve_seconds'])))
 return result
summary=dict(accepted='Stable finite-edge Cauchy interval and inverse CDF only; route proposals unchanged.',contract='integrated-edge-pressure-preview-v10',full={},diagnostic={},final={},controls=ET.parse(out/'controls.xml').getroot().attrib)
assert summary['controls']['result']=='Passed' and summary['controls']['passed']=='36'
for name in names:
 c=json.loads((base/name/'scene.json').read_text());h=.35 if name.startswith('planar') else .9
 gt={hz:np.load(base/name/f'reference-{h:g}-{hz:g}.npz')['pressure'] for hz in c['frequencies']}
 summary['full'][name]=dict(baseline=scores(read(base/name/'renderer.csv'),gt,c),rejectedIncoming=scores(read(out/(name+'-full')/'renderer.csv'),gt,c))
 dc=json.loads((out/(name+'-before')/'scene.json').read_text());dg={hz:v[dc['originalPoints']] for hz,v in gt.items()}
 summary['diagnostic'][name]={variant:scores(read(out/(name+'-'+variant)/'renderer.csv'),dg,dc) for variant in ['before','weighted','visible','incoming']}
 fc=json.loads((out/(name+'-cdf')/'scene.json').read_text());a=read(out/(name+'-cdf')/'renderer.csv')
 assert len(a)==len(fc['points'])//3*len(fc['frequencies'])*len(fc['seeds'])
 if name.startswith('planar'):
  b=read(out/(name+'-before')/'renderer.csv');same=np.array_equal(a[['real','imag','direct_visible']],b[['real','imag','direct_visible']]);assert same
  summary['final'][name]=dict(scope='Original diagnostic subset',bitIdenticalPressureAndVisibility=True,rows=len(a))
 else:summary['final'][name]=dict(scope='Full spatial map',rows=len(a),metrics=scores(a,gt,fc))
summary['sourceHashes']={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'Assets/Shaders/Transport.hlsl',root/'Assets/Tests/Editor/EdgeSampling.compute',root/'Assets/Tests/Editor/RayTransportChecks.cs']}
for p in out.glob('gpu-*.xml'):
 x=ET.parse(p).getroot();assert x.get('result')=='Passed' and x.get('passed')=='4'
summary['measurementTestsPassed']=sum(int(ET.parse(p).getroot().get('passed')) for p in out.glob('gpu-*.xml'))
summary['captureTestsPassed']=int(ET.parse(out/'capture.xml').getroot().get('passed'))
summary['finiteIntervalExample']={}
for center in [-100.,100.]:
 scale=np.float32(.0001);old=float(np.arctan((np.float32(1)-np.float32(center))/scale)-np.arctan(-np.float32(center)/scale))
 expected=float(np.arctan((1-center)/float(scale))-np.arctan(-center/float(scale)))
 summary['finiteIntervalExample'][str(center)]=dict(oldFloatSpan=old,referenceDoubleSpan=expected)
 assert old==0 and expected>0
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary['final'],indent=2))
