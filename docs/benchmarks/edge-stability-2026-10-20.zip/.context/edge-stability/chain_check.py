import sys,json,time
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'tools'))
from edge_integral import sampled
p=root/'.context/spatial-accuracy/planar-1';c=json.loads((p/'scene.json').read_text());points=np.array(c['points']).reshape(-1,3)[[983]]
for depth in [2,4,6]:
 start=time.perf_counter();v,m,r=sampled(c,points,250,4096,17,depth);print(depth,'pure',v,'total',v.sum()+m.sum(),'routes',r,'s',time.perf_counter()-start,flush=True)
