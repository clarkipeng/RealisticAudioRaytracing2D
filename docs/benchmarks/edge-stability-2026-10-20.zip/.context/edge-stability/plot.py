from pathlib import Path
import numpy as np,json,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
out=Path(__file__).resolve().parent;p=out/'planar-25-capture';c=json.loads((p/'scene.json').read_text());a=np.genfromtxt(p/'segments.csv',names=True,delimiter=',');a=a[a['path']==10];edges=a[a['kind']==4];arrivals=a[a['kind']==5]
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
fig,axes=plt.subplots(1,2,figsize=(13,5.4),layout='constrained');left,right=axes
for w in c['walls']:left.add_patch(Rectangle(np.array(w['center'][:2])-w['half'][:2],2*w['half'][0],2*w['half'][1],color='#bdc4cc'))
xy=np.array([c['source'][:2]]+[[r['ex'],r['ey']] for r in edges]);left.plot(xy[:,0],xy[:,1],'-o',color='#8a48ad',ms=4,lw=1.5)
left.plot([xy[-1,0],c['points'][0]],[xy[-1,1],c['points'][1]],'--',color='#ca4a30')
left.scatter(*c['source'][:2],marker='*',s=150,color='#007c91',label='Source',zorder=4);left.scatter(*c['points'][:2],marker='s',s=45,color='#ca4a30',label='Receiver',zorder=4)
for i,(x,y) in enumerate(xy[1:],1):
 if i==5:continue
 left.annotate('5, 7' if i==7 else str(i),(x,y),xytext=(5,7),textcoords='offset points',fontweight='bold',fontsize=10)
left.set(xlim=(-7,5),ylim=(-5,5),xlabel='x (m)',ylabel='y (m)',title='Captured route through 25 obstacles (XY projection)');left.set_aspect('equal');left.legend(loc='lower left')
right.semilogy(np.arange(1,len(edges)+1),abs(edges['pressure']),'-o',color='#8a48ad',label='Weight at the edge')
indices=[int(np.argmin(abs(edges['et']-r['st'])))+1 for r in arrivals];right.semilogy(indices,abs(arrivals['pressure']),'s--',color='#ca4a30',label='Contribution at the listener')
right.set(xlabel='Edge interaction',ylabel='Absolute estimator weight',xticks=range(1,8),title='Rare paths receive enormous probability corrections');right.grid(True,alpha=.2);right.legend(loc='upper left');right.annotate('73.8 million', (7,abs(arrivals[-1]['pressure'])),xytext=(-88,-26),textcoords='offset points',color='#ca4a30',fontweight='bold')
fig.suptitle('The remaining multi-edge sampling failure',fontsize=16,fontweight='bold')
fig.supxlabel('Baseline shader · 250 Hz · 256 rays/bin · seed 196628 · receiver 343\nWeights are Monte Carlo contributions, not physical energy carried by a ray.',fontsize=10)
fig.savefig(out/'edge-stability.png',dpi=160)
