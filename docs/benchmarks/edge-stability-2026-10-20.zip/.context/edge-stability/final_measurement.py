import importlib.util,json
from pathlib import Path
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('study',root/'.context/spatial-accuracy/run.py');study=importlib.util.module_from_spec(spec);spec.loader.exec_module(study);study.OUT=out
names=[]
for name in ['planar-1','planar-9','planar-25','room-12m-25']:
 src=out/(name+'-before') if name.startswith('planar') else root/'.context/spatial-accuracy'/name
 dst=out/(name+'-cdf');dst.mkdir();names.append(dst.name)
 for f in ['scene.json','renderer-scene.json']:
  if not (src/f).exists():continue
  c=json.loads((src/f).read_text());c.update(rays=[256],decompose=False);(dst/f).write_text(json.dumps(c))
study.gpu(names)
