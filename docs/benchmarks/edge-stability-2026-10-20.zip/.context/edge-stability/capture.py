import json,os,subprocess,time,shutil
from pathlib import Path
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent;runner=root/'.context/gpu-audio/runner'
fixture=runner/'Assets/Tests/Editor/WaveFieldMeasurement.cs';batch=runner/'Assets/Tests/Editor/SpatialStudy.cs'
assert not fixture.exists() and not batch.exists()
names=[]
for name,point,seed in [('planar-25',343,196628),('planar-1',983,131091),('room-12m-25',184,131091)]:
 path=out/(name+'-capture');path.mkdir();names.append(str(path));base=root/'.context/spatial-accuracy'/name
 for f in ['scene.json','renderer-scene.json']:
  if (base/f).exists():
   c=json.loads((base/f).read_text());c.update(points=c['points'][3*point:3*point+3],rays=[256],seeds=[seed],decompose=True);(path/f).write_text(json.dumps(c))
s=(root/'Assets/Tests/Editor/WaveFieldMeasurement.cs').read_text().replace('foreach(int diffraction in new[]{0,1})','foreach(int diffraction in new[]{1})')
s=s.replace('var paths=solver.RayPaths;double seconds=TakeRender.Elapsed(started);','''var paths=solver.RayPaths;double seconds=TakeRender.Elapsed(started);
                using(var debug=new StreamWriter(Path.Combine(output,"segments.csv"))) {
                  debug.WriteLine("kind,path,sx,sy,sz,st,ex,ey,ez,et,pressure");
                  foreach(var seg in solver.CaptureRays(state,0,settings.FrequencyBins-1))
                    if(seg.kind!=TransportSolver.RayEvent.None)debug.WriteLine(FormattableString.Invariant($"{(int)seg.kind},{seg.path},{seg.start.x:R},{seg.start.y:R},{seg.start.z:R},{seg.start.w:R},{seg.end.x:R},{seg.end.y:R},{seg.end.z:R},{seg.end.w:R},{seg.pressure:R}"));
                }''')
fixture.write_text(s);batch.write_text('''using System; using System.IO; using System.Collections.Generic; using NUnit.Framework;
public partial class TakeChecks {
 public static IEnumerable<string> SpatialCases() => File.ReadAllLines(Environment.GetEnvironmentVariable("SPATIAL_CASES"));
 [TestCaseSource(nameof(SpatialCases))] public void SpatialStudy(string path) { Environment.SetEnvironmentVariable("ACOUSTIC_WAVE_OUTPUT",path); MeasureWaveField(); }
}''')
cases=out/'capture-cases.txt';cases.write_text('\n'.join(names));shutil.copy2(fixture,out/'capture-fixture.cs')
try:
 r=subprocess.run(['nice','-n','15','/Applications/Unity/Hub/Editor/6000.4.1f1/Unity.app/Contents/MacOS/Unity','-batchmode','-force-metal','-disable-audio','-job-worker-count','1','-projectPath',str(runner),'-runTests','-testPlatform','EditMode','-testFilter','TakeChecks.SpatialStudy','-testResults',str(out/'capture.xml'),'-logFile',str(out/'capture.log')],env=dict(os.environ,SPATIAL_CASES=str(cases)),timeout=180)
 print('Exit',r.returncode)
finally:
 for f in [fixture,batch]:f.unlink(missing_ok=True);Path(str(f)+'.meta').unlink(missing_ok=True)
