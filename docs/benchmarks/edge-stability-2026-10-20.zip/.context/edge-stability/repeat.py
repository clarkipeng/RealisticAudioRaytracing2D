import importlib.util,json,sys
from pathlib import Path
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('study',root/'.context/spatial-accuracy/run.py');study=importlib.util.module_from_spec(spec);spec.loader.exec_module(study);study.OUT=out
names=[]
for p in sorted(out.glob('*-before')):
 dst=out/(p.name.removesuffix('before')+sys.argv[1]);dst.mkdir();names.append(dst.name)
 for f in ['scene.json','renderer-scene.json']:
  if (p/f).exists():(dst/f).write_bytes((p/f).read_bytes())
study.gpu(names)
