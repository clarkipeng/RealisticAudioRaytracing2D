import json,sys,numpy as np
from pathlib import Path
out=Path(__file__).resolve().parent;base=out.parent/'spatial-accuracy'
for name in ['planar-1','planar-9','planar-25','room-12m-25']:
 c=json.loads((out/(name+'-before')/'scene.json').read_text());hz=max(c['frequencies']);h=.35 if name.startswith('planar') else .9
 gt=np.load(base/name/f'reference-{h:g}-{hz:g}.npz')['pressure'][c['originalPoints']]
 print(name)
 for variant in ['before']+sys.argv[1:]:
  f=out/(name+'-'+variant)/'renderer.csv'
  if not f.exists():continue
  r=np.genfromtxt(f,names=True,delimiter=',');r=r[r['hz']==hz];err=[]
  for seed in c['seeds']:
   a=r[r['seed']==seed]
   if len(a)!=len(gt):continue
   value=a['real']+1j*a['imag'];err.append(100*np.linalg.norm(value-gt)/np.linalg.norm(gt))
  print(variant,'error',np.mean(err),'seeds',np.round(err,2),'ms',1000*np.median(r['solve_seconds']))
