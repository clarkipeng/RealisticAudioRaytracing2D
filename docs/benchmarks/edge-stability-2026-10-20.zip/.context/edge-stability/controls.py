import subprocess,shutil,sys,xml.etree.ElementTree as ET
from pathlib import Path
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent;runner=root/'.context/gpu-audio/runner'
assert not (runner/'Temp/UnityLockfile').exists()
for name in ['RayTransportChecks.cs','EdgeSampling.compute','EdgeSampling.compute.meta']:
 shutil.copy2(root/'Assets/Tests/Editor'/name,runner/'Assets/Tests/Editor'/name)
methods=['EdgeHeightSamplesMatchCauchyDistribution','EdgeIntegralMatchesRigidHalfPlane','EdgeShadowBoundaryRetainsPhaseAndContinuity','EdgeChainsMatchRigidSecondOrder','MovingEdgeUsesLocalVelocityAndCurrentPose','TransparentGeometryDoesNotGenerateEdgeSound','RayDebugPreservesArrivals','RayDebugUsesMaterialTravelTimes','RayDebugCapturesMirrorGeometry','SurfaceBranchWeightsPreservePressure','ImpedanceReflectionMatchesPlaneWave','ComplexArrivalsPreserveMaterialPhase']
if len(sys.argv)>1: methods=methods[:1]
r=subprocess.run(['nice','-n','15','/Applications/Unity/Hub/Editor/6000.4.1f1/Unity.app/Contents/MacOS/Unity','-batchmode','-force-metal','-disable-audio','-job-worker-count','1','-projectPath',str(runner),'-runTests','-testPlatform','EditMode','-testFilter',';'.join('TakeChecks.'+n for n in methods),'-testResults',str(out/'controls.xml'),'-logFile',str(out/'controls.log')],timeout=300)
x=ET.parse(out/'controls.xml').getroot();print('Controls',x.attrib,flush=True)
for node in x.iter('test-case'):
 if node.get('result')!='Passed':print(node.get('fullname'),node.findtext('failure/message'),flush=True)
assert r.returncode==0 and x.get('result')=='Passed'
assert all(any(t.get('methodname')==name for t in x.iter('test-case')) for name in methods)
