import importlib.util,json
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('study',root/'.context/spatial-accuracy/run.py');study=importlib.util.module_from_spec(spec);spec.loader.exec_module(study)
base=study.OUT; study.OUT=root/'.context/edge-stability';study.OUT.mkdir(exist_ok=True)
names=[]
for name in ['planar-1','planar-9','planar-25','room-12m-25']:
 c=json.loads((base/name/'scene.json').read_text());r=np.genfromtxt(base/name/'renderer.csv',delimiter=',',names=True)
 rows=r[(r['rays']==256)&(r['hz']==max(c['frequencies']))]
 ids=sorted(set(rows[np.argsort(abs(rows['real']+1j*rows['imag']))[-8:]]['point'].astype(int))|set(range(0,len(c['points'])//3,100)))
 out=study.OUT/(name+'-before');out.mkdir(exist_ok=True);points=np.array(c['points']).reshape(-1,3)[ids].ravel().tolist()
 for fn in ['scene.json','renderer-scene.json']:
  if not (base/name/fn).exists():continue
  cfg=json.loads((base/name/fn).read_text());cfg.update(points=points,rays=[256],decompose=True,originalPoints=list(map(int,ids)));(out/fn).write_text(json.dumps(cfg))
 names.append(out.name)
study.gpu(names)
