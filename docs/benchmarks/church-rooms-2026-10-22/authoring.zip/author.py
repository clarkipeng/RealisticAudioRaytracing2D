"""One-off original cathedral dressing. Coordinates are Unity metres; no runtime generator."""
import bpy, math, os, json
from mathutils import Vector
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
root='/Users/clarkpeng/UnityGames/realisticaudioraytracing2d/.context/gpu-audio/runner/Assets/External/Church'
colors={'Limestone':(.64,.60,.48,1),'Sandstone':(.43,.39,.31,1),'Slate':(.16,.23,.27,1),'Gold':(.68,.46,.18,1),'Oak':(.27,.13,.065,1),'Teal':(.035,.29,.31,1),'Crimson':(.40,.055,.055,1),'Parchment':(.75,.65,.44,1),'GlassBlue':(.055,.20,.60,1),'GlassCyan':(.07,.48,.55,1),'GlassAmber':(.83,.38,.065,1),'Flame':(1,.63,.19,1)}
mats={}
for n,c in colors.items():
 m=bpy.data.materials.new(n);m.diffuse_color=c;mats[n]=m
verts=[];faces=[];slots=[];objects=[]
def face(points,mat):
 points=[p for i,p in enumerate(points) if tuple(p)!=tuple(points[i-1])]
 if len(points)<3:return
 n=len(verts);verts.extend([(-p[0],-p[2],p[1]) for p in points]);faces.append(tuple(reversed(range(n,n+len(points)))));slots.append(list(colors).index(mat))
def box(c,s,m):
 x,y,z=c;a,b,d=[v/2 for v in s];p=[(x+i*a,y+j*b,z+k*d) for i,j,k in [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]]
 for ids in [(0,3,2,1),(4,5,6,7),(0,1,5,4),(3,7,6,2),(0,4,7,3),(1,2,6,5)]:face([p[i] for i in ids],m)
def lathe(c,profile,m,n=8):
 x,y,z=c
 for (r0,h0),(r1,h1) in zip(profile,profile[1:]):
  for i in range(n):
   a=i*math.tau/n;b=(i+1)*math.tau/n
   face([(x+r0*math.cos(a),y+h0,z+r0*math.sin(a)),(x+r1*math.cos(a),y+h1,z+r1*math.sin(a)),(x+r1*math.cos(b),y+h1,z+r1*math.sin(b)),(x+r0*math.cos(b),y+h0,z+r0*math.sin(b))],m)
def beam(a,b,w,m):
 a,b=Vector(a),Vector(b);d=(b-a).normalized();u=d.cross(Vector((0,0,1)))
 if u.length<.01:u=d.cross(Vector((0,1,0)))
 u.normalize();u*=w/2;v=d.cross(u)
 p=[a-u-v,a+u-v,a+u+v,a-u+v,b-u-v,b+u-v,b+u+v,b-u+v]
 for ids in [(0,3,2,1),(4,5,6,7),(0,1,5,4),(3,7,6,2),(0,4,7,3),(1,2,6,5)]:face([p[i] for i in ids],m)
def finish(name):
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.update();o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o)
 for m in mats.values():mesh.materials.append(m)
 for p,slot in zip(mesh.polygons,slots):p.material_index=slot
 # World planar mapping for optional PBR textures, not required by the flat-color style.
 uv=mesh.uv_layers.new(name='UVMap')
 for p in mesh.polygons:
  axis=max(range(3),key=lambda k:abs(p.normal[k]));axes=[k for k in range(3) if k!=axis]
  for li in p.loop_indices:
   v=mesh.vertices[mesh.loops[li].vertex_index].co;uv.data[li].uv=(v[axes[0]]*.3,v[axes[1]]*.3)
 # Strip unused material slots to avoid empty render batches.
 used=sorted(set(slots));old=list(mesh.materials);indices=[used.index(p.material_index) for p in mesh.polygons];mesh.materials.clear()
 for k in used:mesh.materials.append(old[k])
 for p,k in zip(mesh.polygons,indices):p.material_index=k
 objects.append(o);verts.clear();faces.clear();slots.clear();return o

def arch(cx,cz,width,spring,rise,thick=.38,depth=.5,turn=False):
 # Faceted pointed arch, structural piers reach the floor. Rotate for side wings.
 def point(x,y,z):return (cx+z,y,cz+x) if turn else (cx+x,y,cz+z)
 for sign in (-1,1):
  # Multi-ring octagonal columns and stepped capitals.
  c=point(sign*width/2,1,0)
  lathe(c,[(0,0),(.62,0),(.62,.2),(.48,.32),(.35,.42),(.35,spring-1.5),(.5,spring-1.35),(.55,spring-1), (0,spring-1)],'Limestone')
 # Two circular arcs meet at a point, using an explicit sampled quadratic for predictable silhouettes.
 path=[]
 for i in range(25):
  t=i/24;x=-width/2+width*t;y=spring+rise*(1-abs(2*t-1))**.65;path.append(Vector((x,y,0)))
 for i,(a,b) in enumerate(zip(path,path[1:])):
  def normal(k):
   d=(path[min(k+1,len(path)-1)]-path[max(k-1,0)]).normalized()
   return Vector((-d.y,d.x,0))*thick/2
  na,nb=normal(i),normal(i+1)
  pts=[]
  for z in (-depth/2,depth/2):
   pts.extend(point(p.x,p.y,z) for p in (a-na,b-nb,b+nb,a+na))
  m='Limestone' if i%3 else 'Sandstone'
  for ids in [(0,3,2,1),(4,5,6,7),(0,1,5,4),(3,7,6,2)]+([(0,4,7,3)] if i==0 else [])+([(1,2,6,5)] if i==len(path)-2 else []):face([pts[k] for k in ids],m)
 # Keystone pendant.
 c=point(0,spring+rise-.12,0);lathe(c,[(0,-.35),(.28,-.12),(.24,.35),(0,.35)],'Gold')

# Repeated rib bays establish scale/silhouette. Existing shell remains authoritative.
for z in (-31,-24,-17,-10,-3):arch(0,z,17.2,10,7,.48,.6)
finish('Nave arcades')
# Transept thresholds, clearly distinct low-ceilinged room entrances under the high crossing.
for x in (-10.4,10.4):arch(x,3.7,10,5.1,3.2,.4,.45,True)
finish('Chapel portals')
# Floor geometry is a thin, non-colliding inlay over the existing stone floor.
for z in range(-33,22,2):
 for x in range(-8,9,2):
  if z>10 and abs(x)>6:continue
  m='Sandstone' if (x//2+z//2)%2 else 'Limestone'
  box((x,1.003,z),(1.97,.004,1.97),m)
for x in (-1.67,1.67):box((x,1.012,-10),(.10,.008,46),'Gold')
box((0,1.008,-10),(3.2,.006,46),'Slate')
for z in range(-31,11,4):
 face([(-.46,1.017,z),(0,1.017,z+.75),(.46,1.017,z),(0,1.017,z-.75)],'Gold')
for side in (-1,1):
 for x in range(11,20,2):
  for z in range(-1,10,2):box((side*x,1.008,z),(1.97,.008,1.97),'Slate' if (x+z)//2%2 else 'Sandstone')
for cx,cz,r in [(0,3.7,3.7),(-15.5,4,3.1),(15.2,4,3.1)]:
 lathe((cx,1.022,cz),[(r,0),(r-.12,0)],'Gold',32)
 for i in range(16):
  a=i*math.tau/16;b=(i+1)*math.tau/16;mid=(a+b)/2
  face([(cx,1.025,cz),(cx+r*.93*math.cos(a),1.025,cz+r*.93*math.sin(a)),(cx+r*.43*math.cos(mid),1.025,cz+r*.43*math.sin(mid))][::-1],'Limestone' if i%2 else 'Teal')
  face([(cx,1.025,cz),(cx+r*.43*math.cos(mid),1.025,cz+r*.43*math.sin(mid)),(cx+r*.93*math.cos(b),1.025,cz+r*.93*math.sin(b))][::-1],'Sandstone' if i%2 else 'Slate')
finish('Stone floor inlays')
# Wall-height moldings and window framing break up blank wall expanses.
for side in (-1,1):
 x=side*9.1
 for z in (-27.54,-20.32,-13.22,-6.04):
  for dz in (-1.65,1.65):
   box((x,5.35,z+dz),(.25,8.7,.18),'Limestone')
  box((x,1.55,z),(.28,.28,5.7),'Sandstone')
  box((x,3.6,z),(.22,.15,5.7),'Limestone')
  # Timber wall paneling below tall windows.
  box((x,2.45,z),(.13,1.4,5.5),'Oak')
  for dz in (-2.4,-1.2,0,1.2,2.4):box((x-side*.1,2.45,z+dz),(.12,1.45,.085),'Gold')
finish('Nave wainscot')
# Heraldic banners: shaped, faceted cloth with a small inlaid sun motif.
for side in (-1,1):
 for z in (-24,-10):
  x=side*7.9;beam((x-.85,8.8,z),(x+.85,8.8,z),.09,'Gold')
  # front and reverse are both visible.
  p=[(x-.72,8.65,z),(x+.72,8.65,z),(x+.67,5.8,z-.08),(x,5.25,z-.12),(x-.67,5.8,z-.08)]
  for poly in (p,p[::-1]):face(poly,'Teal' if side<0 else 'Crimson')
  for i in range(8):
   a=i*math.tau/8;b=(i+1)*math.tau/8
   face([(x,7.15,z-.015),(x+.32*math.cos(a),7.15+.32*math.sin(a),z-.015),(x+.32*math.cos(b),7.15+.32*math.sin(b),z-.015)],'Gold')
finish('Hanging banners')
# Octagonal font, open bowl, visible layered stone profile.
lathe((-15.5,1,4),[(0,0),(1.28,0),(1.28,.16),(1.08,.30),(.62,.4),(.48,.55),(.48,1.2),(.8,1.32),(1.25,1.65),(1.28,1.87),(1.05,1.87),(.88,1.58),(0,1.52)],'Limestone')
lathe((-15.5,1,4),[(1.27,1.71),(1.27,1.77)],'Gold')
finish('Baptismal font')
lathe((-15.5,2.61,4),[(.91,0),(0,0)],'GlassCyan',16);finish('Font water')
# West shrine with three high, faceted jewel panels mounted against the wall.
for z in (1,4,7):
 x=-19.65
 box((x,4.5,z),(.25,5.8,2.3),'Oak')
 for k in range(5):
  y=2+k*.95
  for s in (-1,1):
   zz=z+s*.5
   face([(x+.14,y,zz),(x+.14,y+.42,zz+.45),(x+.14,y+.84,zz),(x+.14,y+.42,zz-.45)][::-1],['GlassBlue','GlassCyan','GlassAmber'][(k+(s+1)//2)%3])
 for dz in (-1.1,1.1):box((x+.2,4.5,z+dz),(.12,5.9,.09),'Gold')
 beam((x+.18,7.4,z-1.15),(x+.18,8.6,z),.12,'Gold');beam((x+.18,8.6,z),(x+.18,7.4,z+1.15),.12,'Gold')
finish('Baptistery triptych')
# Reading chapel: bookcases along north/south walls, a central writing table and lectern.
for z in (-1.95,9.15):
 box((15.5,2.7,z),(6.6,3.4,.62),'Oak')
 # Books face into room; contrasting recessed shelf backs.
 front=z+(.34 if z<0 else -.34)
 box((15.5,2.7,front),(6.1,3,.04),'Slate')
 for h in (1.18,2.0,2.82,3.64,4.42):box((15.5,h,front),(6.6,.12,.6),'Oak')
 for x in (12.2,14.4,16.6,18.8):box((x,2.8,front),(.12,3.5,.7),'Gold')
 for row in range(4):
  for k in range(28):
   x=12.4+k*.226;h=.46+.17*((k*7+row)%5)/4
   box((x,1.3+row*.82+h/2,front),(.17,h,.34),['Teal','Crimson','Parchment','Oak'][((k*3+row)//3)%4])
   box((x,1.44+row*.82,front+(.18 if z<0 else -.18)),(.17,.035,.025),'Gold')
finish('Reading shelves')
box((15.2,2.05,4),(3.3,.18,1.65),'Oak')
for x in (13.8,16.6):
 for z in (3.4,4.6):box((x,1.5,z),(.18,1,.18),'Oak')
# Two benches, leaving generous circulation on both sides.
for z in (2.4,5.6):
 box((15.2,1.48,z),(3,.16,.55),'Oak')
 for x in (14,16.4):box((x,1.23,z),(.2,.46,.45),'Oak')
# Open angular book and loose folio on the desk.
for s in (-1,1):
 face([(15.2,2.22,3.6),(15.2+s*.55,2.32,3.6),(15.2+s*.55,2.32,4.35),(15.2,2.22,4.35)][::(-1 if s>0 else 1)],'Parchment')
 box((15.2+s*.58,2.23,3.98),(.04,.1,.8),'Crimson')
box((16.1,2.17,4.15),(.45,.06,.7),'Teal')
finish('Reading table')
# Low-poly candle stands establish warm pools in each room; emissive flames share existing material.
for x,z in [(-18,1),(-18,7),(12.3,0),(18,7.5)]:
 lathe((x,1,z),[(0,0),(.4,0),(.4,.10),(.12,.25),(.08,1.7),(.28,1.85),(.28,1.92),(0,1.92)],'Gold')
 for dx in (-.23,0,.23):
  lathe((x+dx,2.92,z),[(0,0),(.065,0),(.065,.35),(0,.35)],'Parchment')
  lathe((x+dx,3.27,z),[(0,0),(.065,.08),(0,.25)],'Flame',5)
finish('Chapel candles')
# A ribbed timber ceiling gives the reading room a different silhouette/material identity.
for z in (-1,3.7,8.4):
 beam((11,8,z),(15.2,11,z),.25,'Oak');beam((15.2,11,z),(19.4,8,z),.25,'Oak')
 beam((11,8,z),(19.4,8,z),.22,'Oak')
 for x in (11,19.4):beam((x,1,z),(x,8,z),.26,'Oak')
beam((15.2,11,-1),(15.2,11,8.4),.3,'Oak');finish('Reading roof trusses')
for z in (-1,8.4):arch(-15.3,z,8,6.5,3.7,.3,.4)
finish('Baptistery ribs')
bpy.ops.object.select_all(action='DESELECT')
for o in objects:o.select_set(True)
bpy.ops.export_scene.fbx(filepath=root+'/CathedralRooms.fbx',use_selection=True,object_types={'MESH'},add_leaf_bones=False,bake_anim=False,axis_forward='-Z',axis_up='Y',path_mode='RELATIVE')
print('AUTHORED',[(o.name,len(o.data.polygons)) for o in objects])
open('/Users/clarkpeng/UnityGames/realisticaudioraytracing2d/.context/church-rooms/geometry.json','w').write(json.dumps({o.name:len(o.data.polygons) for o in objects},indent=2))
