from pathlib import Path
import shutil,json,subprocess,hashlib,zipfile,csv,re
from PIL import Image,ImageDraw,ImageFont
import numpy as np
repo=Path.cwd();scratch=repo/'.context/church-rooms';runner=repo/'.context/gpu-audio/runner'
output=repo/'docs/benchmarks/church-rooms-2026-10-22';output.mkdir(exist_ok=True)
full=scratch/'footage/run-20261023-012855';smoke=next((scratch/'grouped-smoke').glob('run-*'))
# Before modifying main, verify the final grouping preserved all rendered samples.
compared=0;worstMean=0;worstChannel=0;identical=0
for style in ['PolishedLowPoly','Realistic']:
 for view in ['first-person-frames','third-person-frames']:
  for p in (smoke/style/view).glob('*.png'):
   a=np.asarray(Image.open(p)).astype(float);b=np.asarray(Image.open(full/style/view/p.name)).astype(float);delta=np.abs(a-b)
   worstMean=max(worstMean,float(delta.mean()));worstChannel=max(worstChannel,float(delta.max()));identical+=int(delta.max()==0)
   assert delta.mean()<.001 and delta.max()<=2,p
   compared+=1
assert compared==16
# Explicit task-owned asset list only. Never copy scratch editor scripts or project settings.
paths=[Path('Assets/Scenes/Church.unity'),Path('Assets/External/Church/CathedralRooms.fbx'),Path('Assets/External/Church/CathedralRooms.fbx.meta')]
paths += [p.relative_to(runner) for p in (runner/'Assets/Materials/ChurchPresentation').glob('Rooms-*')]
paths += [Path('Assets/Materials/ChurchPresentation')/n for n in ['LowPoly-glass.mat','LowPoly-stone.mat']]
for p in paths:
 shutil.copy2(runner/p,repo/p)
 if p.suffix in ['.mat','.meta','.unity']:
  (repo/p).write_text('\n'.join(line.rstrip() for line in (repo/p).read_text().splitlines())+'\n')
# Preserve current results alongside prior attempts, not over them.
probes={}
for style in ['PolishedLowPoly','Realistic']:
 for view in ['first-person-gameplay','third-person-animation']:
  name=f'{style}-{view}.mp4';src=full/style/name;shutil.copy2(src,output/name)
  info=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-of','json',str(src)]))
  assert len(info['streams'])==1 and info['streams'][0]['codec_type']=='video'
  v=info['streams'][0];assert (v['width'],v['height'],v['nb_frames'],v['r_frame_rate'])==(1280,720,'192','24/1')
  probes[name]={k:v[k] for k in ['width','height','nb_frames','r_frame_rate','duration']}
 shutil.copy2(full/style/'route.csv',output/(style+'-nave-route.csv'))
 for suffix in ['room-route.csv','acoustic.csv']:
  shutil.copy2(scratch/(style+'-'+suffix),output/(style+'-'+suffix))
 for view in ['nave','baptistery','reading','crossing']:
  shutil.copy2(scratch/(style+'-'+view+'.png'),output/(style+'-'+view+'.png'))
shutil.copy2(full/'summary.json',output/'capture.json');shutil.copy2(smoke/'summary.json',output/'grouped-smoke.json')
verify=json.loads((scratch/'verification.json').read_text());verify.update({'fullCapture':probes,'groupingSmokeFramesCompared':compared,'groupingSmokeFramesPixelIdentical':identical,'groupingSmokeWorstMeanByteDelta':worstMean,'groupingSmokeWorstChannelByteDelta':worstChannel,'totalAcousticTriangles':17321,'newRuntimeLines':0})
assert (output/'PolishedLowPoly-room-route.csv').read_bytes()==(output/'Realistic-room-route.csv').read_bytes()
assert (output/'PolishedLowPoly-nave-route.csv').read_bytes()==(output/'Realistic-nave-route.csv').read_bytes()
# Ensure old gameplay/audio definitions and old collision data survived scene authoring.
def blocks(text):
 return {int(m[1]):(int(m[0]),m[2]) for m in re.findall(r'^--- !u!(\d+) &(\d+)(.*?)(?=^--- !u!|\Z)',text,re.M|re.S)}
old=blocks(subprocess.check_output(['git','show','HEAD:Assets/Scenes/Church.unity']).decode());new=blocks((repo/'Assets/Scenes/Church.unity').read_text())
colliders={64,65,135,136,143};preserved=0
for k,(typ,body) in old.items():
 if typ in colliders or typ in {4,33}:
  a=body;b=new[k][1]
  if typ==4:
   a=re.sub(r'  m_Children:.*?(?=  m_Father:)', '',a,flags=re.S);b=re.sub(r'  m_Children:.*?(?=  m_Father:)', '',b,flags=re.S)
  assert a==b,f'Existing transform/mesh/collider changed {k}'
  if typ in colliders:preserved+=1
# Compare old serialized MonoBehaviours except manager registration and preset material bindings.
def guid(p):return re.search(r'^guid: (\w+)',(repo/p).read_text(),re.M)[1]
changed={guid(Path('Assets/Scripts/Simulation/RayTraceManager.cs.meta')),guid(Path('Assets/Scripts/Demo/ChurchVisualPreset.cs.meta'))}
behaviours=0
for k,(typ,body) in old.items():
 if typ==114 and not any(g in body for g in changed):
  assert new[k]==old[k],f'Existing behaviour changed {k}';behaviours+=1
verify['existingCollidersUnchanged']=preserved;verify['existingBehavioursUnchangedExceptRegistryAndPreset']=behaviours
verify['totalColliders']=sum(t in colliders for t,b in new.values())
(output/'verification.json').write_text(json.dumps(verify,indent=2)+'\n')
# Contact sheet contains actual Unity renders with short labels, no recoloring.
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',25)
canvas=Image.new('RGB',(1600,1240),(18,24,29));d=ImageDraw.Draw(canvas)
for name,label,box in [('PolishedLowPoly-nave','Nave / pointed arches and stone inlay',(0,40,800,602)),('PolishedLowPoly-crossing','Crossing / connected side chapels',(800,40,1600,602)),('PolishedLowPoly-baptistery','Baptistery / octagonal font and jewel panels',(0,666,800,1228)),('PolishedLowPoly-reading','Reading chapel / books, desk and timber trusses',(800,666,1600,1228))]:
 im=Image.open(output/(name+'.png'));im=im.resize((box[2]-box[0],box[3]-box[1]),Image.Resampling.LANCZOS);canvas.paste(im,(box[0],box[1]));d.text((box[0]+14,box[1]-33),label,font=font,fill=(228,234,238))
canvas.save(output/'rooms.png');shutil.copy2(output/'rooms.png',Path('/Users/clarkpeng/conductor/workspaces/realisticaudioraytracing2d/tyler/.context/church-rooms.png'))
# Source of one-off authoring remains reproducible evidence, not production runtime/editor code.
with zipfile.ZipFile(output/'authoring.zip','w',zipfile.ZIP_DEFLATED) as z:
 z.write(scratch/'author.py','author.py');z.write(runner/'Assets/Editor/ChurchRooms.cs','ChurchRooms.cs');z.write(scratch/'publish.py','publish.py');z.write(scratch/'geometry.json','geometry.json')
 for p in scratch.glob('*.log'):z.write(p,'logs/'+p.name)
 for p in (scratch/'first-pass').glob('*.png'):z.write(p,'first-pass/'+p.name)
with zipfile.ZipFile(output/'authoring.zip') as z:assert z.testzip() is None
manifest={str(p):hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}
manifest.update({str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in output.iterdir() if p.is_file() and p.name!='manifest.json'})
(output/'manifest.json').write_text(json.dumps({'parentCommit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'sha256':manifest},indent=2)+'\n')
print(json.dumps(verify,indent=2))
