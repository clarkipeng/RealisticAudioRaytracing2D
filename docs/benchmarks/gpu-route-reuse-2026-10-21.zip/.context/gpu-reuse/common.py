import json,sys,time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(OUT/'source'));import edge_integral as edge;import gpu_routes as gpu
for name in ('barrier','staggered','slit','corridor'):
 scene=ROOT/f'.context/wave-study/pilot/{name}-1/scene.json';c=json.loads(scene.read_text());points=np.array(c['points']).reshape(-1,3);clock=time.perf_counter();common=edge.connections(c,points,250,8,depth=2);seconds=time.perf_counter()-clock
 np.savez_compressed(OUT/f'common-{name}.npz',pressure=common,points=points,indices=np.arange(len(points)))
 result=dict(seconds=seconds,hz=250,order=8,depth=2,sceneSha256=gpu.sha(scene));gpu.save(OUT/f'common-{name}.json',result);print(name,result,flush=True)
