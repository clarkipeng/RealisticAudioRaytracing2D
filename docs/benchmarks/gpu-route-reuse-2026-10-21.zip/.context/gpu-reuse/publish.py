import hashlib,json,subprocess,zipfile
from pathlib import Path
import xml.etree.ElementTree as ET
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];DOC=ROOT/'docs/benchmarks'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
final=OUT/'gpu-221215.xml';test=ET.parse(final).getroot();assert test.get('result')=='Passed' and test.get('passed')=='70'
provenance=json.loads((OUT/'provenance-221215.json').read_text())
for name in ('RouteGeneration.compute','RouteGenerationChecks.cs'):
 assert next(v for p,v in provenance['files'].items() if p.endswith('/'+name))==sha(OUT/name)
files=set()
for p in OUT.rglob('*'):
 if not p.is_file() or '__pycache__' in p.parts or p.name=='manifest.json' or p.suffix=='.log':continue
 if p.name=='generated.bin' and (p.parent.name.startswith('map-') or p.parent.name.startswith('seed-')):continue
 if p.name.startswith('contributions-') and not p.name.endswith('-2.bin'):continue
 files.add(p)
for meta in OUT.glob('*/generation.json'):files.add(Path(json.loads(meta.read_text())['scene']))
for n in (1,9,25):
 for name in ('scene.json','reference-0.35-250.npz','reference-0.35-250.json'):files.add(ROOT/f'.context/spatial-accuracy/planar-{n}'/name)
 for ext in ('npz','json'):files.add(ROOT/f'.context/route-monte-carlo/planar-{n}-connections-full.{ext}')
for family in ('barrier','staggered','slit','corridor'):
 for name in ('scene.json','reference-0.25-250.npz','reference-0.25-250.json'):files.add(ROOT/f'.context/wave-study/pilot/{family}-1'/name)
assert all(p.exists() for p in files)
manifest={str(p.relative_to(ROOT)):sha(p) for p in sorted(files)};save(OUT/'manifest.json',manifest);files.add(OUT/'manifest.json')
archive=DOC/'gpu-route-reuse-2026-10-21.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(files):z.write(p,p.relative_to(ROOT))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
ledger=dict(baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),scope='Offline static rigid-box point-source infinite extrusion, equal z=0, at most two interactions, 250Hz, width1. No runtime change.',
 methodNames={'0':'Generated pure routes per height sample + cached CPU common','1':'Prepared pure routes reused + cached CPU common','2':'Prepared pure and mixed routes + GPU direct/mirrors'},
 timing='Measured component sums: packing, buffer/input setup, warm graph, receiver submission, dispatch and blocking readback, plus old CPU common costs. Large CPU common costs reused from prior measurements. Excludes first compile/warmup, Unity startup, wave references, diagnostics, audio/DSP. No GPU hardware timestamps.',
 results=json.loads((OUT/'summary.json').read_text()),controls=json.loads((OUT/'checks.json').read_text()),finalSuite=dict(file=str(final.relative_to(ROOT)),sha256=sha(final),**test.attrib),
 archive=dict(file=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,files=len(files)),images={p.name:sha(p) for p in DOC.glob('gpu-reuse-*-2026-10-21.png')},
 limitations=['Dense-scene error remains large; not a qualified DLSS teacher or live renderer.', 'Low-budget geometry reuse shows little benefit; small scenes do not need one million samples.', 'Brute-force mirror/mixed geometry enumeration still scales O(E^2 W), with O(E^2) memory.', 'No pilot-guided allocation, multi-frequency sample reuse, higher-order, moving, broadband, arbitrary mesh/material or finite-3D qualification.', 'Near-degenerate mirror endpoint margin only qualified on archived scenes/controls. Existing shader warnings remain.'])
save(DOC/'gpu-route-reuse-2026-10-21.json',ledger)
print('Archived',len(files),'files,',archive.stat().st_size,'bytes',flush=True)
