import json
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1]
s=json.loads((OUT/'summary.json').read_text());r={(x['scene'],x['mode'],x['samples']):x for x in s['maps']}
p=ROOT/'docs/acoustic-experiment-history.md';text=p.read_text();old=text.split('**The history, in order**')[0]
intro='''# Acoustic experiments: history, 2D maps and GPU route generation

The latest offline experiment also moves **direct/reflected and mixed reflection–diffraction calculations onto the GPU** and reuses route geometry. At one million samples, the 9-box map improves from **32.0% to 22.3% complex-pressure error**, with measured component time falling from **30.95 to 1.51 seconds**. The 25-box map improves from **83.2% to 62.2%**, with **214.23 to 3.66 seconds**. The remaining dense-scene error is still unacceptable for a high-fidelity reference.

These are complete **single-frequency spatial-field component totals**, not live audio or full-process timings. The previous totals combine this session's GPU measurements with previously measured CPU common-field costs. Small scenes need far fewer samples; one million is slower without a useful accuracy gain there. No runtime files or dependencies changed. All new work ran silently in the isolated Unity Metal batch runner with audio disabled, one worker and reduced priority.

**Latest experiment: geometry reuse and GPU reflection/mixed paths — 21 October**

![Larger 2D pressure maps](benchmarks/gpu-reuse-large-2026-10-21.png)

![Original smaller 2D scenes](benchmarks/gpu-reuse-small-2026-10-21.png)

Each map uses seed 17, width 1, a two-interaction limit and 250 Hz. It represents a point source and infinitely extruded rigid boxes: an XY/2.5D benchmark, not finite 3D or strictly cylindrical 2D propagation. Columns share an absolute scale. “Error” is `100 × norm(complex pressure − wave reference) / norm(wave reference)` and includes phase; the ±3 dB metric measures amplitude agreement. Neither is a listening-artifact score. The independent wave solutions retain their earlier refinement qualifications; they are numerical references, not exact truth.

| Scene | Previous 65K error | Previous map time | All GPU 65K time | All GPU 1M error | All GPU 1M time |
|---|---:|---:|---:|---:|---:|
'''
labels={'1':'1 box','9':'9 boxes','25':'25 boxes','barrier':'Thick wall','staggered':'Staggered walls','slit':'Slit','corridor':'Corridor'}
for name,label in labels.items():
 a,b,c=r[name,0,65536],r[name,2,65536],r[name,2,1048576]
 intro+=f"| {label} | {a['errorPercent']:.2f}% | {a['totalComponentSeconds']:.3f} s | {b['totalComponentSeconds']:.3f} s | {c['errorPercent']:.2f}% | {c['totalComponentSeconds']:.3f} s |\n"
intro+='''
At the same 65K budget, all-GPU errors are 1.85/32.10/83.69/1.46/8.69/2.36/13.52% in table order: moving the mixed integral from CPU quadrature into the shared Monte Carlo budget slightly changes variance, and does **not** improve accuracy by itself. The time saved permits more samples. For nine boxes, **262K gives 24.03% in 0.754 s**; for 25 boxes, **262K gives 62.56% in 2.844 s**, close to the 1M result. These are useful operating points, not a claim that 1M should become a universal default.

What changed, measured separately:

1. **Geometry reuse:** prepare each pure route's distances and wedge terms once per receiver; every height sample reads them. Modes 0 and 1 produce bit-for-bit identical pressure in the measured cases. At 65K, extra dispatch cost offsets the saving: median solve/readback changes by about −0.3% to +1.0% across the three larger maps. At 1M, the old/new median-time ratio is **1.17× / 1.20× / 1.22×**. Reuse is helpful when enough height samples amortize preparation.
2. **GPU reflections and mixed paths:** GPU image-source geometry enumerates direct, one- and two-face reflections, plus one-reflection/one-edge paths. Pure and mixed diffraction routes share the fixed height-sample budget. No cached CPU acoustic field is added to the new result; the CPU only adds the two returned complex component sums. This removes the large CPU common-field calculation. The final reduction/readback could be combined later.
3. **Spend the saving on samples:** compare 65,536 / 262,144 / 1,048,576 samples without changing proposal width, gain, horizon or covered path orders. Large-scene noise decreases, while several small-scene errors plateau. No amplitude fitting, smoothing, extra physical gains or rejection of inconvenient large contributions is used.

```text
GPU, scene/source setup:
    build edge visibility graph
GPU, each receiver:
    count visible one-edge and two-edge routes
    prepare each route's distances and wedge terms once
    find valid mirror→edge and edge→mirror routes; prepare and compact them
    find valid direct / one-mirror / two-mirror distances
    distribute fixed N height samples across pure + mixed edge routes
    for each sample, in parallel:
        read its prepared geometry
        sample heights with the existing complete-route Cauchy mixture
        add signed pressure × physical phase / sampling probability
    sum sampled pressure and analytic mirror pressure
CPU:
    read back the two component sums and add them
```

This still contains an explicit two-interaction route/face enumeration. It is not a general-depth GPU ray walk. With E edges/faces and W boxes, graph construction and brute-force mirror/mixed visibility cost **O(E²W)**, with **O(E²)** persistent storage. Pure-route preparation is O(E²) candidate/count work plus the valid descriptors; sampling is O(N) bounded-depth integration with prefix-search overhead. Mixed compaction is a serial O(E²) scan. Geometry reuse removes repeated per-sample distance/angle work; it does not remove the dense visibility cost. The 25-box all-GPU 65K solve is slower per receiver than the pure-edge stage because it now includes that work. A scene BVH, sparse visibility and general-depth sampling remain separate future experiments.

**Cost accounting and repeatability**

Totals sum Python input packing, C# file read/buffer allocation/initial upload submission, warmed scene-graph work, receiver input submission, all receiver dispatches, blocking readbacks and finite-value checks. Previous methods additionally include the CPU direct/mirror/mixed calculation: archived 0.3605/30.6905/213.9573 s for the three larger maps, freshly measured 0.1785/0.6891/0.6738/0.7500 s for the four small maps. The large CPU costs were reused instead of rerunning several minutes of identical quadrature; the totals are **sums of measured components from different runs**, not one stopwatch around the old process. Shared fixture allocations include buffers unused by modes 0/1. Results are host-observed solve/readback times, not GPU hardware timestamps.

Unity startup, initial shader compilation/warmup, reference solving, diagnostic exports, plots, broadband bins, time-domain synthesis and networking are excluded. The static graph is timed once per case; receiver-dependent geometry is rebuilt at every map position. Modes rotate execution order per receiver. This is one final map pass, not a statistical hardware speed guarantee. Final Unity test execution took 46 seconds for the whole suite, separate from per-method field costs.

Four seeds were compared on the same 25 evenly spaced receiver IDs in each scene, including seed 17 from the full maps. No proposal tuning was performed on these results. In the nine-box subset, all-GPU mean error changes **31.94% → 23.50%**, and seed-to-seed RMS variation **17.04% → 2.73%** of reference RMS. For 25 boxes, subset mean error changes **108.55% → 87.22%**, and variation **59.12% → 10.68%**. Subset error is higher than full-map error because these are different receiver distributions; it must not be substituted for the full-map score. The much larger remaining discrepancy suggests sampling noise alone is insufficient to explain it, but this experiment does not identify or prove the missing physical contribution. More complete path coverage needs its own controlled comparison.

**Verification and limits**

The final suite passes **70 Unity tests**: 21 full-map cases, 42 additional-seed cases, six geometry/sampling controls and the 115-value angle-control test. All 4,842 spatial cells are evaluated at all three budgets. Independent Python checks verify visibility, mirror lengths, mixed-route eligibility and Monte Carlo pressure at 22 control positions, including empty geometry, short delay support and more routes than samples. Maximum aggregate control discrepancy is **0.00125%** relative norm. Geometry reuse is bit-for-bit identical over the entire measured suite. Across the full maps, GPU direct/mirror pressure matches independent CPU image-source pressure within the declared tolerance (max absolute difference recorded in the ledger).

The controls caught two implementation problems before the final suite: too many read/write buffer bindings on Metal, fixed by declaring integration inputs read-only; and reflections numerically landing at a face endpoint, fixed by rejecting contacts within the precision of the intersection operands. This numerical endpoint margin is not qualified for arbitrary scales or near-degenerate geometry. Initial failed runs remain in the evidence but are not counted as passing. Existing compiler warnings remain; passing tests establish only the tested numerical cases.

Keep this as a reproducible **offline prototype**, not a production renderer or DLSS teacher. It covers static rigid rectangles, source/listener z=0, 250 Hz and at most two interactions; moving geometry, other frequencies/materials, finite 3D and audible temporal continuity are unqualified. Pilot-guided allocation and reuse of sampled paths across frequency bins were **not implemented or benchmarked** in this experiment. The result supports removing the CPU common-field bottleneck and amortizing geometry at larger budgets; it does not yet support claiming realistic dense-scene audio.

[Full metrics and provenance](benchmarks/gpu-route-reuse-2026-10-21.json) · [Source, raw results, controls and pressure arrays](benchmarks/gpu-route-reuse-2026-10-21.zip). The live renderer is unchanged from the previous checkpoint; the prior offline experiment is preserved at `cb0fef8`.

'''
text=intro+text[len(old):]
text=text.replace('| This experiment, 21 Oct | Build visibility/counts', '| `cb0fef8`, 21 Oct | Build visibility/counts',1)
marker='The chronology is a record of accepted and rejected experiments'
pos=text.index(marker)
text=text[:pos]+'| Latest experiment, 21 Oct | Reuse route descriptors; compute mirror/mixed fields on GPU; sweep total sample budget | Removes the CPU common-field bottleneck. More samples improve larger maps, but errors plateau and dense-scene fidelity remains poor. Detailed comparisons above. |\n\n'+text[pos:]
# Keep the added history row inside its table.
text=text.replace('Restricted to one/two-edge rigid planar paths for this experiment. |\n\n| Latest', 'Restricted to one/two-edge rigid planar paths for this experiment. |\n| Latest')
p.write_text(text)
p=ROOT/'docs/cleanup-results.md';t=p.read_text();title=t.split('\n',1)[0]+'\n';section='''
## GPU geometry reuse and full reflection/mixed calculation — 2026-10-21

[Updated consolidated report and all seven 2D maps](acoustic-experiment-history.md). The offline prototype moves the previously cached CPU reflection/mixed field onto the GPU. At 1M samples, nine boxes improve from 32.02% to 22.29% complex-pressure error with component totals 30.95 → 1.51 s; 25 boxes improve from 83.23% to 62.23%, 214.23 → 3.66 s. Old totals include archived CPU measurements, not a new end-to-end stopwatch. Small scenes need fewer samples. Geometry reuse alone is bit-for-bit identical; at 1M it provides 1.17–1.22× median solve/readback speed ratios on the larger maps, but little benefit at 65K. Final 70-test suite and independent CPU controls pass. Dense-scene accuracy, moving audio and finite 3D remain unqualified; no live runtime change. [Source/data archive](benchmarks/gpu-route-reuse-2026-10-21.zip).
''';p.write_text(title+section+t[len(title):])
