import json,sys,hashlib
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(OUT/'source'));import gpu_routes as gpu
names=('1','9','25','barrier','staggered','slit','corridor');report=[];seeds=[]
def table(p):
 d=np.genfromtxt(p/'generated.csv',delimiter=',',names=True,ndmin=1);r=[d[d['mode']==i] for i in range(3)]
 for a in r:assert np.isfinite(a['real']).all() and np.isfinite(a['imag']).all()
 np.testing.assert_array_equal(r[0]['real'],r[1]['real']);np.testing.assert_array_equal(r[0]['imag'],r[1]['imag'])
 return r

def metrics(value,reference,shadow):
 db=20*np.log10(np.maximum(abs(value),1e-12)/np.maximum(abs(reference),1e-12))
 return dict(errorPercent=float(100*np.linalg.norm(value-reference)/np.linalg.norm(reference)),within3dBPercent=float(100*np.mean(abs(db)<=3)),medianAbsoluteLevelErrorDb=float(np.median(abs(db))),shadowErrorPercent=float(100*np.linalg.norm((value-reference)[shadow])/max(np.linalg.norm(reference[shadow]),1e-30)))

def total(rows,meta):return float(meta['preparationSeconds']+rows['setup_seconds'][0]+rows['graph_seconds'][0]+np.sum(rows['solve_seconds']+rows['input_seconds']))

for name in names:
 p=OUT/f'map-{name}-65536';m=json.loads((p/'generation.json').read_text());scene=Path(m['scene']);assert gpu.sha(scene)==m['sceneSha256'];c=json.loads(scene.read_text());points=np.array(c['points']).reshape(-1,3)
 commonpath=ROOT/f'.context/route-monte-carlo/planar-{name}-connections-full.npz' if name.isdigit() else OUT/f'common-{name}.npz';cm=json.loads(commonpath.with_suffix('.json').read_text());assert cm['sceneSha256']==m['sceneSha256'];commonfile=np.load(commonpath);common=commonfile['pressure'];np.testing.assert_array_equal(commonfile['points'],points);shared=common.sum(axis=1);shadow=abs(common[:,0])==0
 refpath=scene.parent/('reference-0.35-250.npz' if name.isdigit() else 'reference-0.25-250.npz');ref=np.load(refpath)['pressure'];fields={};cost={}
 for count in (65536,262144,1048576):
  p=OUT/f'map-{name}-{count}';m=json.loads((p/'generation.json').read_text());r=table(p);assert all(len(a)==len(points) for a in r)
  mirrors=r[2]['mirror_real']+1j*r[2]['mirror_imag'];np.testing.assert_allclose(mirrors,common[:,:3].sum(axis=1),rtol=1e-4,atol=2e-5)
  for mode in range(3):
   field=r[mode]['real']+1j*r[mode]['imag']+(mirrors if mode==2 else shared);key=f'm{mode}n{count}';fields[key]=field
   seconds=total(r[mode],m)+(cm['seconds'] if mode<2 else 0);cost[key]=seconds
   result=dict(scene=name,samples=count,mode=mode,points=len(points),**metrics(field,ref,shadow),totalComponentSeconds=seconds,gpuSolveSeconds=float(r[mode]['solve_seconds'].sum()),medianSolveMs=float(1000*np.median(r[mode]['solve_seconds'])),p95SolveMs=float(1000*np.quantile(r[mode]['solve_seconds'],.95)),geometryReuseParity=True,cpuCommonSeconds=cm['seconds'] if mode<2 else 0,preparationSeconds=m['preparationSeconds'],setupSeconds=float(r[mode]['setup_seconds'][0]),graphWarmSeconds=float(r[mode]['graph_seconds'][0]),graphColdSeconds=float(r[mode]['cold_graph_seconds'][0]),inputSeconds=float(np.sum(r[mode]['input_seconds'])),gpuBytes=int(r[mode]['gpu_bytes'][0]),mirrorMaxAbsoluteDifference=float(abs(mirrors-common[:,:3].sum(axis=1)).max()))
   report.append(result)
  print(name,count,'error',report[-1]['errorPercent'],'total seconds',report[-1]['totalComponentSeconds'],flush=True)
 np.savez_compressed(OUT/f'fields-{name}.npz',**fields,reference=ref,points=points,shadow=shadow)
 ids=np.linspace(0,len(points)-1,25,dtype=int)
 for count in (65536,1048576):
  estimates={mode:[fields[f'm{mode}n{count}'][ids]] for mode in (0,2)};extraTimes=[]
  for seed in (65554,131091,196628):
   p=OUT/f'seed-{name}-{seed}-{count}';m=json.loads((p/'generation.json').read_text());np.testing.assert_array_equal(m['indices'],ids);r=table(p)
   for mode in (0,2):
    mirror=r[2]['mirror_real']+1j*r[2]['mirror_imag'];np.testing.assert_allclose(mirror,common[ids,:3].sum(axis=1),rtol=1e-4,atol=2e-5)
    estimates[mode].append(r[mode]['real']+1j*r[mode]['imag']+(mirror if mode==2 else shared[ids]))
  for mode,v in estimates.items():
   v=np.array(v);errors=[metrics(x,ref[ids],shadow[ids])['errorPercent'] for x in v];noise=100*np.sqrt(np.mean(abs(v-v.mean(axis=0))**2))/np.sqrt(np.mean(abs(ref[ids])**2))
   seeds.append(dict(scene=name,samples=count,mode=mode,receivers=len(ids),seeds=[17,65554,131091,196628],errorPercent=errors,meanErrorPercent=float(np.mean(errors)),minErrorPercent=float(min(errors)),maxErrorPercent=float(max(errors)),repeatVariationPercent=float(noise)))
(OUT/'summary.json').write_text(json.dumps(dict(maps=report,heldout=seeds),indent=2)+'\n')
