# Offline GPU geometry reuse and mirror/mixed-path experiment

21 October 2026, based on `cb0fef8`. No production renderer changes. The archive restores project-relative `.context/` paths; the source baseline and new shaders/harness live here only. The real Unity project is not launched or staged into. Run silently with the existing isolated `.context/gpu-audio/runner`, Unity 6000.4.1f1, and `.context/wave-planar/venv` (NumPy/SciPy/matplotlib). These installed tools are not bundled.

`build.py` combines the previous route generator helpers, the original integration shader and `reuse.hlsl`. The three modes are: 0, recalculate pure-route geometry inside each sample; 1, prepare pure-route descriptors once; 2, also compute direct/mirror geometry and reflection–diffraction paths on GPU. Modes 0/1 add an independently computed CPU common field during analysis. Mode 2 includes that work in its timed GPU dispatches. The CPU adds the two returned complex sums. No new physical terms, amplitude fits or frequency-dependent tweaks are added.

The experiment is rigid axis-aligned boxes, equal source/listener z=0, infinite vertical extrusion, maximum two interactions, 250 Hz, width 1. The route and height sampler retains full PDF and shared-face weights. N must be a positive power of two. A coordinate-scaled float-precision margin rejects mirror-face endpoint contacts; this is only qualified on the archived controls/maps.

The final passing suite is `gpu-221215.xml`: 70 tests, including all 21 full maps and 42 additional-seed cases plus six controls and the angle control. `provenance-221215.json` identifies the exact staged source hashes. Earlier XML failures are retained separately as history, not passing validation. Local full Unity logs are not archived because they mostly contain environment/startup chatter. The last run used low-priority batch Metal, disabled audio and one worker, without opening a player/browser window. No hardware GPU timestamps are collected.

The archive includes raw CSVs, pressure arrays, scenes/reference arrays, common fields, source, metadata and small control inputs. Large full-map/additional-seed generated.bin files are omitted: they are reproducible packed geometry + scrambled Sobol draws + receiver coordinates, not unique observations. Their exact hashes remain in generation.json. Controls retain mirror lengths, prepared descriptors and mode-2 sample contributions; redundant mode-0/1 per-sample copies are omitted. The venv and Unity runner already need to exist. Metadata stores original absolute scene paths; remap them if restoring elsewhere.

Regenerate plots from archived results (adjust the Conductor output path in plots.py on another machine):

```sh
OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 \
  nice -n 15 .context/wave-planar/venv/bin/python .context/gpu-reuse/plots.py
```

Run a fresh case without replacing the recorded suite:

```sh
export OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
nice -n 15 .context/wave-planar/venv/bin/python .context/gpu-reuse/build.py
nice -n 15 .context/wave-planar/venv/bin/python - <<'PY'
import sys,json,numpy as np
sys.path.insert(0,'.context/gpu-reuse')
from prepare import prepare,ROOT
scene=ROOT/'.context/spatial-accuracy/planar-9/scene.json'
prepare('repeat-9',scene,np.arange(len(json.loads(scene.read_text())['points'])//3),count=262144)
PY
nice -n 15 .context/wave-planar/venv/bin/python .context/gpu-reuse/run.py repeat-9
```

To rerun the recorded controls, pass `control-1 control-9 control-25 empty subset no-support` to run.py, then to check.py. This overwrites their measurements; copy this experiment directory to another `.context/` directory first if retaining the original files. `prepare_suite.py` reproduces the 21 maps and 42 extra-seed inputs, not the six special controls. `common.py` reproduces small-scene CPU common fields; the larger arrays/timings are archived measurements. `analyze.py` verifies parity, calculates full-map metrics and compares four seeds on 25 fixed receiver IDs per scene. All 4,842 map cells are covered, with no per-field gain normalization or smoothing.

The timing ledger includes measured packing, setup, warmed scene graph, receiver dispatch/readback and old CPU common-field costs. Those old large-scene CPU costs are from prior runs, so totals sum measured components rather than claiming a fresh whole-process stopwatch. First compile/warmup, runner startup, wave-reference computation, diagnostic export, plots and all audio/DSP are excluded. Same fixture buffers are allocated for all modes, including buffers unused by modes 0/1. Multi-frequency reuse and adaptive pilot allocation were not implemented. No live/moving, finite-3D, general material or arbitrary-depth validation is claimed.
