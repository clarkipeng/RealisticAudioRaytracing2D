// Measured one/two-interaction experiment; route data stays GPU-resident.
struct Prepared { Step first, second; float4 info; }; // depth, shared-face weight, padding
RWStructuredBuffer<Prepared> PreparedRoutes;
StructuredBuffer<Prepared> PreparedInput;
StructuredBuffer<uint> MixedInput, CountsInput;
RWStructuredBuffer<uint> MixedIndices, Counts;
RWStructuredBuffer<float> MirrorLengths;
RWStructuredBuffer<float2> MirrorResult;
StructuredBuffer<float> Frequencies;
uint Mode;
uint PureCount() { return EdgeCount==0?0:Starts[EdgeCount-1]+Starts[2*EdgeCount-1]; }
uint TotalCount() { return PureCount()+(Mode>=2?CountsInput[0]:0); }
uint StoredIndex(uint rank) { uint pure=PureCount();return rank<pure?rank:EdgeCount*EdgeCount+MixedInput[rank-pure]; }
Route Describe(uint rank,out Step first,out Step second)
{
    Route route=(Route)0;first=(Step)0;second=(Step)0;
    uint one=Starts[EdgeCount-1];bool two=rank>=one;uint r=two?rank-one:rank;
    uint a=FindStart(r,two?EdgeCount:0),b=a;route.depth=two?2:1;route.weight=1;
    if(two)
    {
        r-=a==0?0:Starts[EdgeCount+a-1];uint lo=0,hi=EdgeCount;
        while(lo<hi){uint mid=(lo+hi)/2;if(r<Prefix[a*EdgeCount+mid])hi=mid;else lo=mid+1;}b=lo;
        float last=length(Receiver-Corner(b));second=MakeStep(b,Corner(a),Receiver,last);
        first=MakeStep(a,Source,Corner(b),length(Corner(b)-Corner(a))+last);
        if(a/4==b/4 && any(Corner(a)==Corner(b)))route.weight*=.5;
    }
    else first=MakeStep(a,Source,Receiver,length(Receiver-Corner(a)));
    if(first.shape.x+first.shape.z>=Horizon || all(first.halfSine==0) || (two && all(second.halfSine==0)))route.depth=0;
    return route;
}
[numthreads(64,1,1)]
void PreparePure(uint id:SV_DispatchThreadID)
{
    if(id>=PureCount())return;Prepared p;Route r=Describe(id,p.first,p.second);p.info=float4(r.depth,r.weight,0,0);PreparedRoutes[id]=p;
}
uint PlaneAxis(uint plane) {return plane%2==0?1:0;}
float PlanePosition(uint plane)
{
    float4 b=Boxes[plane/4];uint side=plane%4;return side==0?b.y:(side==1?b.z:(side==2?b.w:b.x));
}
float2 Reflect(uint plane,float2 p) { uint axis=PlaneAxis(plane);float position=PlanePosition(plane);return axis==0?float2(2*position-p.x,p.y):float2(p.x,2*position-p.y); }
bool HitMirror(uint plane,float2 from,float2 image,out float2 hit)
{
    uint axis=PlaneAxis(plane),other=1-axis;float position=PlanePosition(plane),d=image[axis]-from[axis];hit=0;if(d==0)return false;
    float t=(position-from[axis])/d;hit=from+t*(image-from);hit=axis==0?float2(position,hit.y):float2(hit.x,position);float4 box=Boxes[plane/4];
    // Reject endpoint contacts at the precision of the intersection operands.
    const float epsilon=4*1.192092896e-7;
    float margin=epsilon*max(max(abs(from[other]),abs(image[other])),max(abs(box[other]),abs(box[other+2])));
    return t>epsilon && t<1-epsilon && hit[other]>box[other]+margin && hit[other]<box[other+2]-margin;
}
bool MirrorLeg(uint plane,float2 a,float2 b)
{
    float2 hit;return HitMirror(plane,b,Reflect(plane,a),hit) && Visible(a,hit) && Visible(hit,b);
}
[numthreads(64,1,1)]
void PrepareMixed(uint id:SV_DispatchThreadID)
{
    uint square=EdgeCount*EdgeCount;if(id>=2*square)return;
    uint e=(id%square)/EdgeCount,plane=id%EdgeCount;bool before=id<square;
    float2 edge=Corner(e),a=Source,b=Receiver;bool valid;
    if(before){valid=Ends[e]!=0 && MirrorLeg(plane,Source,edge);a=Reflect(plane,Source);}
    else {valid=Graph[square+e]!=0 && MirrorLeg(plane,edge,Receiver);b=Reflect(plane,Receiver);}
    Prepared p=(Prepared)0;
    if(valid)
    {
        p.first=MakeStep(e,a,b,length(b-edge));
        p.info=float4(p.first.shape.x+p.first.shape.z<Horizon && any(p.first.halfSine!=0)?1:0,1,0,0);
    }
    PreparedRoutes[square+id]=p;
}
[numthreads(1,1,1)]
void CompactMixed(uint id:SV_DispatchThreadID)
{
    uint count=0,square=EdgeCount*EdgeCount;
    for(uint i=0;i<2*square;i++)if(PreparedRoutes[square+i].info.x!=0)MixedIndices[count++]=i;
    Counts[0]=count;
}
[numthreads(64,1,1)]
void PrepareMirrors(uint id:SV_DispatchThreadID)
{
    uint faces=EdgeCount;if(id>=1+faces+faces*faces)return;
    float distance=0;
    if(id==0) { if(Visible(Source,Receiver))distance=length(Receiver-Source); }
    else if(id<=faces)
    {
        uint plane=id-1;if(MirrorLeg(plane,Source,Receiver))distance=length(Reflect(plane,Source)-Receiver);
    }
    else
    {
        uint a=(id-1-faces)/faces,b=(id-1-faces)%faces;
        float2 first=Reflect(a,Source),second=Reflect(b,first),hitA,hitB;
        if(a!=b && HitMirror(b,Receiver,second,hitB) && HitMirror(a,hitB,first,hitA) &&
           Visible(Source,hitA) && Visible(hitA,hitB) && Visible(hitB,Receiver))distance=length(second-Receiver);
    }
    MirrorLengths[id]=distance>0 && distance<Horizon?distance:0;
}
[numthreads(64,1,1)]
void SumMirrors(uint3 group:SV_GroupID,uint lane:SV_GroupIndex)
{
    float2 value=0;uint count=1+EdgeCount+EdgeCount*EdgeCount;
    for(uint i=lane;i<count;i+=64)
    {
        float distance=MirrorLengths[i];if(distance>0){float2 phase;sincos(-Frequencies[group.x]*distance,phase.y,phase.x);value+=phase/distance;}
    }
    Sum[lane]=value;GroupMemoryBarrierWithGroupSync();
    for(uint stride=32;stride>0;stride>>=1){if(lane<stride)Sum[lane]+=Sum[lane+stride];GroupMemoryBarrierWithGroupSync();}
    if(lane==0)MirrorResult[group.x]=Sum[0];
}
Route Generate(uint index,out uint draw,out Step first,out Step second)
{
    Route route=(Route)0;draw=0;first=(Step)0;second=(Step)0;
    uint total=TotalCount();if(total==0)return route;uint rank,selected;
    if(total<=SampleCount)
    {
        uint base=SampleCount/total,extra=SampleCount%total,split=(base+1)*extra;
        rank=index<split?index/(base+1):extra+(index-split)/base;
        selected=base+(rank<extra);draw=index-(rank*base+min(rank,extra));route.weight=2.0/selected;
    }
    else {rank=min(total-1,(uint)(Draws[index*Dimensions+4]*total));draw=index;route.weight=2.0*total/SampleCount;}
    if(Mode==0){Route r=Describe(rank,first,second);route.depth=r.depth;route.weight*=r.weight;}
    else {Prepared p=PreparedInput[StoredIndex(rank)];first=p.first;second=p.second;route.depth=(uint)p.info.x;route.weight*=p.info.y;}
    return route;
}
