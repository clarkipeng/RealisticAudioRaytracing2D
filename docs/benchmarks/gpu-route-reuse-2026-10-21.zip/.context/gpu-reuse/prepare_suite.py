import json,sys
from pathlib import Path
import numpy as np
import prepare as p
scenes={str(n):p.ROOT/f'.context/spatial-accuracy/planar-{n}/scene.json' for n in (1,9,25)}
scenes.update({family:p.ROOT/f'.context/wave-study/pilot/{family}-1/scene.json' for family in ('barrier','staggered','slit','corridor')})
for name,scene in scenes.items():
 count=len(json.loads(scene.read_text())['points'])//3
 for n in (65536,262144,1048576):p.prepare(f'map-{name}-{n}',scene,np.arange(count),count=n)
 # Identical evenly spaced held-out receiver IDs and four scrambles, independent of tuning.
 for seed in (65554,131091,196628):
  for n in (65536,1048576):p.prepare(f'seed-{name}-{seed}-{n}',scene,np.linspace(0,count-1,25,dtype=int),count=n,seed=seed)
