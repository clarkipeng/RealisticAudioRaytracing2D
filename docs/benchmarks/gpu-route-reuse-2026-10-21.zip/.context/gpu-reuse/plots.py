import json,shutil
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];DOC=ROOT/'docs/benchmarks';DEST=Path('/Users/clarkpeng/conductor/workspaces/realisticaudioraytracing2d/tyler/.context')
summary=json.loads((OUT/'summary.json').read_text());rows={(r['scene'],r['mode'],r['samples']):r for r in summary['maps']}
plt.rcParams.update({'font.size':10,'figure.facecolor':'white','savefig.facecolor':'white'})
cmap=plt.colormaps['magma'].with_extremes(over='#27c9bd',under='#050505',bad='#e5e7eb')
def draw(ax,c,points,value,title,quality=None,small=False):
 x,y=np.unique(points[:,0]),np.unique(points[:,1]);g=np.full((len(y),len(x)),np.nan);g[np.searchsorted(y,points[:,1]),np.searchsorted(x,points[:,0])]=20*np.log10(np.maximum(abs(value),1e-12));im=ax.pcolormesh(x,y,g,cmap=cmap,vmin=-40,vmax=5,shading='nearest')
 for w in c['walls']:
  center,half=np.array(w['center'][:2]),np.array(w['half'][:2]);ax.add_patch(Rectangle(center-half,*(2*half),facecolor='#515962',edgecolor='white',lw=.6))
 ax.scatter(*c['source'][:2],marker='*',s=75,color='#00a8ff',edgecolor='black',linewidth=.5,zorder=5)
 ax.set(xlabel='x (m)',ylabel='y (m)',title=title,xlim=(-3.4,3.55) if small else (-6.9,6.25),ylim=(-2.75,2.75) if small else (-5.7,5.7));ax.set_aspect('equal')
 if quality:
  ax.text(.02,.025,f"{quality['errorPercent']:.1f}% error · {quality['within3dBPercent']:.0f}% within ±3 dB",transform=ax.transAxes,fontsize=8,bbox=dict(facecolor='white',alpha=.94,edgecolor='none',pad=3))
 return im
for small,names in ((False,('1','9','25')),(True,('barrier','staggered','slit','corridor'))):
 cols=[('Wave reference',None,None),('Previous · 65K',0,65536),('All GPU · 65K',2,65536),('All GPU · 1M',2,1048576)]
 fig,axes=plt.subplots(len(names),4,figsize=(14,10.5 if not small else 12.2),layout='constrained')
 for row,name in enumerate(names):
  m=json.loads((OUT/f'map-{name}-65536/generation.json').read_text());c=json.loads(Path(m['scene']).read_text());fields=np.load(OUT/f'fields-{name}.npz');label=(name+' '+('box' if name=='1' else 'boxes')) if not small else {'barrier':'Thick wall','staggered':'Staggered walls','slit':'Slit','corridor':'Corridor'}[name]
  for col,(title,mode,n) in enumerate(cols):
   q=None if mode is None else rows[name,mode,n];v=fields['reference' if mode is None else f'm{mode}n{n}'];cost='' if q is None else f" · {q['totalComponentSeconds']:.2f} s/map"
   im=draw(axes[row,col],c,fields['points'],v,(label+' · wave') if mode is None else title+cost,q,small)
 fig.colorbar(im,ax=list(axes.flat),shrink=.75,pad=.015,extend='both',label='Pressure level (dB re unit pressure)')
 fig.suptitle('2D sound maps · GPU geometry reuse + GPU reflections · 250 Hz',fontsize=16)
 fig.supxlabel('Same absolute colour scale, seed 17, width 1 and two-interaction limit. No smoothing or gain matching. Error = complex pressure L2.\nTimes sum preparation, setup, warmed solve/readback and (previous method) measured CPU reflection/mixed cost. They exclude reference solving and audio synthesis.\nRigid boxes extend infinitely out of this XY slice; this is a point-source 2.5D benchmark. Small scenes show little benefit from extra samples.',fontsize=9)
 name=f'gpu-reuse-{"small" if small else "large"}-2026-10-21.png';fig.savefig(DOC/name,dpi=145);plt.close(fig);shutil.copy2(DOC/name,DEST/name)
print('Saved both map comparisons',flush=True)
