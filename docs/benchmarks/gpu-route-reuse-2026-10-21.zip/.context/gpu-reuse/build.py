from pathlib import Path
OUT=Path(__file__).resolve().parent
base=(OUT/'source/RouteIntegration.compute').read_text()
kernels='BuildGraph BuildEnds CountRoutes ScanStarts PreparePure PrepareMixed CompactMixed PrepareMirrors SumMirrors'.split()
base=base.replace('#pragma kernel Integrate','#pragma kernel Integrate\n#pragma kernel IntegrateGenerated GENERATED\n'+'\n'.join('#pragma kernel '+k for k in kernels),1)
helper=(OUT/'generation-before.hlsl').read_text().split('Route Generate(')[0]+(OUT/'reuse.hlsl').read_text()
base=base.replace('uint Terms(Step s)',helper+'\nuint Terms(Step s)',1)
base=base.replace('    uint lowRoute = 0, highRoute = RouteCount;','''#ifdef GENERATED
    uint draw; Step first,second;Route route=Generate(index,draw,first,second);
    if(route.depth==0)return 0;
#else
    uint lowRoute = 0, highRoute = RouteCount;''',1)
base=base.replace('    float previous = 0, before','#endif\n    float previous = 0, before',1)
base=base.replace('        Step s = Steps[route.first+i];','''#ifdef GENERATED
        Step s=first;if(i>0)s=second;
#else
        Step s = Steps[route.first+i];
#endif''',1)
base=base.replace('float2 value = id.x < SampleCount ? Sample(id.x) : 0;','float2 value=0;[branch] if(id.x<SampleCount)value=Sample(id.x);')
base+='\n[numthreads(64,1,1)]\nvoid IntegrateGenerated(uint3 id:SV_DispatchThreadID,uint3 group:SV_GroupID,uint lane:SV_GroupIndex) {Integrate(id,group,lane);}\n'
(OUT/'RouteGeneration.compute').write_text(base)
