using System;
using System.Collections.Generic;
using System.IO;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
public partial class TakeChecks
{
    public static IEnumerable<string> GenerationCases()=>File.ReadAllLines(Environment.GetEnvironmentVariable("ACOUSTIC_GENERATION_CASES"));
    [TestCaseSource(nameof(GenerationCases)),Category("QualityMeasurement")]
    public void MeasureGeneratedRoutes(string directory)
    {
        Assert.That(Application.isBatchMode,Is.True);RequireGpu();
        long setup=System.Diagnostics.Stopwatch.GetTimestamp();
        using var input=new BinaryReader(File.OpenRead(Path.Combine(directory,"generated.bin")));
        Assert.That(input.ReadUInt32(),Is.EqualTo(0x52474731));
        int samples=input.ReadInt32(),depth=input.ReadInt32(),probes=input.ReadInt32(),boxes=input.ReadInt32(),capture=input.ReadInt32();
        Assert.That(depth,Is.EqualTo(2));int edges=checked(boxes*4),square=checked(edges*edges),groups=(samples+63)/64;
        float wave=input.ReadSingle(),horizon=input.ReadSingle(),scale=input.ReadSingle();
        var source=new Vector4(input.ReadSingle(),input.ReadSingle(),0,0);
        var shader=UnityEngine.Object.Instantiate(AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/Tests/Editor/RouteGeneration.compute"));
        try
        {
            int graphKernel=shader.FindKernel("BuildGraph"),endKernel=shader.FindKernel("BuildEnds"),countKernel=shader.FindKernel("CountRoutes"),scan=shader.FindKernel("ScanStarts"),integrate=shader.FindKernel("IntegrateGenerated"),reduce=shader.FindKernel("Reduce");
            int pure=shader.FindKernel("PreparePure"),mixed=shader.FindKernel("PrepareMixed"),compact=shader.FindKernel("CompactMixed"),mirrors=shader.FindKernel("PrepareMirrors"),sumMirrors=shader.FindKernel("SumMirrors");
            using var geometry=new ComputeBuffer(Math.Max(1,boxes),16);using var graph=new ComputeBuffer(Math.Max(1,square+edges),4);
            using var ends=new ComputeBuffer(Math.Max(1,edges),4);using var prefix=new ComputeBuffer(Math.Max(1,square),4);
            using var starts=new ComputeBuffer(Math.Max(1,2*edges),4);using var draws=new ComputeBuffer(samples*5,4);
            using var partial=new ComputeBuffer(groups,8);using var result=new ComputeBuffer(1,8);using var invalid=new ComputeBuffer(1,4);
            using var contributions=new ComputeBuffer(capture!=0?samples:1,8);
            using var prepared=new ComputeBuffer(Math.Max(1,3*square),112);using var mixedIndices=new ComputeBuffer(Math.Max(1,2*square),4);
            using var counts=new ComputeBuffer(1,4);
            using var lengths=new ComputeBuffer(1+edges+square,4);using var mirrorResult=new ComputeBuffer(1,8);using var frequencies=new ComputeBuffer(1,4);
            if(boxes>0)geometry.SetData(RouteRead<Vector4>(input,boxes));draws.SetData(RouteRead<float>(input,samples*5));frequencies.SetData(new[]{wave});
            counts.SetData(new uint[1]);
            shader.SetInt("BoxCount",boxes);shader.SetInt("EdgeCount",edges);shader.SetInt("Depth",depth);
            shader.SetInt("SampleCount",samples);shader.SetInt("Dimensions",5);shader.SetInt("GroupCount",groups);shader.SetInt("Capture",capture);
            shader.SetFloat("WaveNumber",wave);shader.SetFloat("Horizon",horizon);shader.SetFloat("ProposalScale",scale);shader.SetVector("Source",source);
            foreach(int kernel in new[]{graphKernel,endKernel,integrate,pure,mixed,mirrors})shader.SetBuffer(kernel,"Boxes",geometry);
            foreach(int kernel in new[]{graphKernel,countKernel,scan,mixed})shader.SetBuffer(kernel,"Graph",graph);
            foreach(int kernel in new[]{endKernel,countKernel,scan,mixed})shader.SetBuffer(kernel,"Ends",ends);
            foreach(int kernel in new[]{countKernel,scan,integrate,pure})shader.SetBuffer(kernel,"Prefix",prefix);
            foreach(int kernel in new[]{scan,integrate,pure})shader.SetBuffer(kernel,"Starts",starts);
            foreach(int kernel in new[]{pure,mixed,compact})shader.SetBuffer(kernel,"PreparedRoutes",prepared);
            foreach(int kernel in new[]{compact}){shader.SetBuffer(kernel,"MixedIndices",mixedIndices);shader.SetBuffer(kernel,"Counts",counts);}
            shader.SetBuffer(integrate,"PreparedInput",prepared);shader.SetBuffer(integrate,"MixedInput",mixedIndices);shader.SetBuffer(integrate,"CountsInput",counts);shader.SetBuffer(integrate,"Draws",draws);shader.SetBuffer(integrate,"Invalid",invalid);shader.SetBuffer(integrate,"Partials",partial);
            shader.SetBuffer(integrate,"Contributions",contributions);shader.SetBuffer(reduce,"Partials",partial);shader.SetBuffer(reduce,"Result",result);
            foreach(int kernel in new[]{mirrors,sumMirrors})shader.SetBuffer(kernel,"MirrorLengths",lengths);
            shader.SetBuffer(sumMirrors,"MirrorResult",mirrorResult);shader.SetBuffer(sumMirrors,"Frequencies",frequencies);
            var receivers=RouteRead<Vector2>(input,probes);Assert.That(input.BaseStream.Position,Is.EqualTo(input.BaseStream.Length));
            double setupSeconds=TakeRender.Elapsed(setup);var status=new uint[1];long clock=System.Diagnostics.Stopwatch.GetTimestamp();
            if(edges>0)shader.Dispatch(graphKernel,(square+edges+63)/64,1,1);graph.GetData(status,0,0,1);
            double coldGraphSeconds=TakeRender.Elapsed(clock);clock=System.Diagnostics.Stopwatch.GetTimestamp();
            if(edges>0)shader.Dispatch(graphKernel,(square+edges+63)/64,1,1);graph.GetData(status,0,0,1);
            double graphSeconds=TakeRender.Elapsed(clock);var graphValues=new uint[square+edges];if(edges>0)graph.GetData(graphValues);
            using(var debugGraph=new BinaryWriter(File.Create(Path.Combine(directory,"graph.bin"))))foreach(uint v in graphValues)debugGraph.Write(v);
            long bytes=(long)geometry.count*16+(long)(graph.count+ends.count+prefix.count+starts.count+draws.count+1+mixedIndices.count+counts.count+lengths.count+frequencies.count)*4+(long)(partial.count+result.count+contributions.count+mirrorResult.count)*8+(long)prepared.count*112;
            using var csv=new StreamWriter(Path.Combine(directory,"generated.csv"));csv.WriteLine("point,mode,real,imag,mirror_real,mirror_imag,solve_seconds,graph_seconds,gpu_bytes,routes_one,routes_two,routes_mixed,cold_graph_seconds,input_seconds,setup_seconds");
            var value=new Vector2[1];var mirrorValue=new Vector2[1];var routeTotals=new uint[3];
            void Solve(int mode)
            {
                status[0]=0;invalid.SetData(status);
                if(edges>0)
                {
                    shader.Dispatch(endKernel,(edges+63)/64,1,1);shader.Dispatch(countKernel,(edges+63)/64,1,1);shader.Dispatch(scan,1,1,1);
                    if(mode>=1)shader.Dispatch(pure,(square+63)/64,1,1);
                    if(mode>=2){shader.Dispatch(mixed,(2*square+63)/64,1,1);shader.Dispatch(compact,1,1,1);}
                }
                if(mode>=2){shader.Dispatch(mirrors,(1+edges+square+63)/64,1,1);shader.Dispatch(sumMirrors,1,1,1);}
                shader.Dispatch(integrate,groups,1,1);shader.Dispatch(reduce,1,1,1);result.GetData(value);invalid.GetData(status);
                mirrorValue[0]=Vector2.zero;if(mode>=2)mirrorResult.GetData(mirrorValue);
                Assert.That(status[0],Is.Zero);Assert.That(float.IsFinite(value[0].x)&&float.IsFinite(value[0].y)&&float.IsFinite(mirrorValue[0].x)&&float.IsFinite(mirrorValue[0].y),Is.True);
            }
            for(int p=0;p<probes;p++) for(int rotation=0;rotation<3;rotation++)
            {
                int mode=(p+rotation)%3;clock=System.Diagnostics.Stopwatch.GetTimestamp();
                shader.SetVector("Receiver",new Vector4(receivers[p].x,receivers[p].y,0,0));shader.SetInt("Mode",mode);
                double inputSeconds=TakeRender.Elapsed(clock);
                if(p==0)Solve(mode);clock=System.Diagnostics.Stopwatch.GetTimestamp();Solve(mode);double seconds=TakeRender.Elapsed(clock);
                if(edges>0){starts.GetData(routeTotals,0,edges-1,1);starts.GetData(routeTotals,1,2*edges-1,1);}counts.GetData(routeTotals,2,0,1);
                csv.WriteLine(FormattableString.Invariant($"{p},{mode},{value[0].x:R},{value[0].y:R},{mirrorValue[0].x:R},{mirrorValue[0].y:R},{seconds:R},{graphSeconds:R},{bytes},{routeTotals[0]},{routeTotals[1]},{routeTotals[2]},{coldGraphSeconds:R},{inputSeconds:R},{setupSeconds:R}"));
                if(capture!=0)
                {
                    using var debug=new BinaryWriter(File.Create(Path.Combine(directory,$"contributions-{p}-{mode}.bin")));
                    var v=new Vector2[samples];contributions.GetData(v);foreach(var z in v){debug.Write(z.x);debug.Write(z.y);}
                    if(mode==2)
                    {
                        using var debugLengths=new BinaryWriter(File.Create(Path.Combine(directory,$"mirrors-{p}.bin")));var d=new float[lengths.count];lengths.GetData(d);foreach(float x in d)debugLengths.Write(x);
                        using var debugPrepared=new BinaryWriter(File.Create(Path.Combine(directory,$"prepared-{p}.bin")));var f=new Vector4[prepared.count*7];prepared.GetData(f);foreach(var x in f){debugPrepared.Write(x.x);debugPrepared.Write(x.y);debugPrepared.Write(x.z);debugPrepared.Write(x.w);}
                    }
                }
            }
        }
        finally{UnityEngine.Object.DestroyImmediate(shader);}
    }
}
