import json,sys,itertools,time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(OUT/'source'));import edge_integral as edge
reports=[]
for name in sys.argv[1:]:
 p=OUT/name;m=json.loads((p/'generation.json').read_text());c=json.loads(Path(m['scene']).read_text());n=m['samples'];walls=c['walls'];edges=edge.corners(walls);planes=edge.surfaces(walls);E=len(edges);square=E*E
 data=np.genfromtxt(p/'generated.csv',delimiter=',',names=True,ndmin=1);values=[data[data['mode']==i] for i in range(3)];a,b=values[:2]
 np.testing.assert_array_equal(a['real'],b['real']);np.testing.assert_array_equal(a['imag'],b['imag'])
 src=np.array(c['source']);points=np.array(c['points']).reshape(-1,3)[m['indices']];k=2*np.pi*250/c['speedOfSound'];h=c['maximumDelaySeconds']*c['speedOfSound']
 draw=np.frombuffer((p/'generated.bin').read_bytes(),'<f4',offset=44+16*len(walls),count=n*5).reshape(n,5)
 graph=np.array([[int(i!=j and edge.visible(a[0],b[0],walls)) for j,b in enumerate(edges)] for i,a in enumerate(edges)]).reshape(E,E)
 start=np.array([int(edge.visible(src,e[0],walls)) for e in edges]);np.testing.assert_array_equal(np.fromfile(p/'graph.bin','<u4'),np.r_[graph.ravel(),start])
 neighbor=[list(np.flatnonzero(row)) for row in graph];starts=list(np.flatnonzero(start));diff=[]
 for pi,point in enumerate(points):
  mirror=np.zeros(1+E+square)
  ids=[()]+[(a,) for a in range(E)]+list(itertools.product(range(E),repeat=2))
  for i,chain in enumerate(ids):
   if len(chain)==2 and chain[0]==chain[1]:continue
   path=edge.mirror_path(src,point,[planes[j] for j in chain],walls)
   if path is not None and 0<path[1]<h:mirror[i]=path[1]
  actual=np.fromfile(p/f'mirrors-{pi}.bin','<f4');np.testing.assert_allclose(actual,mirror,rtol=2e-6,atol=2e-5)
  expectedMirror=np.sum(np.exp(-1j*k*mirror[mirror>0])/mirror[mirror>0]);row=values[2][pi];np.testing.assert_allclose(row['mirror_real']+1j*row['mirror_imag'],expectedMirror,rtol=1e-4,atol=2e-5)
  # All eligible pure paths in exactly the existing independent CPU rank order.
  pure=[([edges[e] for e in path],src,point) for path,_,_ in edge.route_samples(edges,neighbor,starts,point,walls,2,max(1,square),[])];routes=list(pure)
  prepared=np.fromfile(p/f'prepared-{pi}.bin','<f4').reshape(-1,28);valid=[]
  for before in (True,False):
   for ei,e in enumerate(edges):
    for j,plane in enumerate(planes):
     a,b=src.copy(),point.copy();xy=e[0]
     path=edge.mirror_path(a,xy,[plane],walls) if before else edge.mirror_path(xy,b,[plane],walls)
     ok=path is not None and edge.visible(xy,b if before else a,walls)
     if ok:
      q0,q1=plane;normal=np.array([-(q1-q0)[1],(q1-q0)[0]]);normal/=np.linalg.norm(normal)
      if before:a[:2]-=2*normal*np.dot(a[:2]-q0,normal)
      else:b[:2]-=2*normal*np.dot(b[:2]-q0,normal)
      ok=np.linalg.norm(a[:2]-xy)+np.linalg.norm(b[:2]-xy)<h and np.any(abs(np.sin(edge.angles(e,a,b)/2))>1e-12)
     idx=(0 if before else square)+ei*E+j
     assert bool(prepared[square+idx,24])==bool(ok),(name,pi,'mixed eligibility',idx,prepared[square+idx,24],ok)
     if ok:valid.append(idx);routes.append(([e],a,b))
  assert len(valid)==row['routes_mixed'];assert len(pure)==row['routes_one']+row['routes_two'];R=len(routes);expected=0j
  if R<=n:
   for r,(chain,a,b) in enumerate(routes):
    count=n//R+(r<n%R);expected+=edge.sample_chain(chain,a,b,k,h,draw[:count],proposal_scale=m['scale'])
  else:
   for i,d in enumerate(draw):
    r=min(R-1,int(d[4]*R));chain,a,b=routes[r];expected+=R/n*edge.sample_chain(chain,a,b,k,h,d[None,:],proposal_scale=m['scale'])
  measured=row['real']+1j*row['imag'];np.testing.assert_allclose(measured,expected,rtol=.005,atol=2e-5);diff.append([float(abs(measured-expected)),float(abs(expected))])
  print(name,pi,'pure',len(pure),'mixed',len(valid),'MC difference',abs(measured-expected),flush=True)
 diff=np.array(diff);relative=float(np.linalg.norm(diff[:,0])/max(np.linalg.norm(diff[:,1]),1e-30));assert relative<.001
 reports.append(dict(case=name,geometryReuseBitwiseEqual=True,mirrorLengthParity=True,mixedEligibilityParity=True,fullSampledFieldRelativeDifference=relative))
(OUT/'checks.json').write_text(json.dumps(reports,indent=2)+'\n');print(reports,flush=True)
