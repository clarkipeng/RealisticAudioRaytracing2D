using System;
using System.IO;
using UnityEditor;
using UnityEngine;

// Isolated numeric replay only. Does not open a scene, play audio or change assets.
public static class SeededEmissionProbe
{
    public static void Run()
    {
        if(!Application.isBatchMode || Application.isPlaying)throw new InvalidOperationException("Offline only.");
        string root=Environment.GetEnvironmentVariable("ACOUSTIC_BURST_PROBE");
        using var original=AcousticTake.Open(root+"/../rain-plane/take");
        var scene=JsonUtility.FromJson<AcousticTake.Scene>(JsonUtility.ToJson(original.Metadata.scene));
        int rate=original.Metadata.sampleRate;var pcm=new float[scene.clips.Length][];
        for(int c=0;c<pcm.Length;c++)pcm[c]=original.ReadClip(c);
        var plane=scene.planes[0];plane.generatorVersion=1;plane.burstPeriodSamples=rate/8;plane.burstDurationSamples=rate/8;plane.samples=16;
        double energy=0;foreach(float value in pcm[scene.sources[plane.source].clipIndex])energy+=(double)value*value;
        float rms=(float)Math.Sqrt(energy/pcm[scene.sources[plane.source].clipIndex].Length);
        string path=root+"/church-take";var state=new AcousticTake.State[scene.objects.Length];
        using(var writer=new AcousticTake.Writer(path,rate,scene,original.Geometry,pcm))
        {
            for(int frame=0;frame<original.Metadata.frameCount;frame++){original.ReadStoredFrame(frame,state);writer.Append(original.FrameSample(frame),state);}
            foreach(var recorded in original.Events){var e=recorded;if(e.sourceIndex==plane.source)e.gain*=rms;writer.Append(e);}
            writer.Complete();
        }
        using var take=AcousticTake.Open(path);
        var settings=new TakeRender.Settings{transport=TakeRender.Transport.Raytraced,synthesis=TakeRender.Synthesis.Spectral,audioBackend=TakeRender.AudioBackend.Gpu,
            fftSize=128,spectralHop=32,responseStepSamples=2048,maximumResponsesPerBatch=4,raysPerBin=16,maxBounces=2,
            maximumDelaySeconds=.5f,tailSamples=rate/2+4352,useBvh=true,diffractionFactor=0};
        var shader=AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/Shaders/Transport.compute");
        var report=TakeRender.RenderDirect(take,settings,root+"/church-render",shader:shader);
        if(!report.complete || original.Geometry.Length!=17321)throw new InvalidOperationException("Incomplete Church replay.");
        File.WriteAllText(root+"/church-probe.json",JsonUtility.ToJson(new Result{sourceVersion=original.Metadata.version,version=take.Metadata.version,
            sampleRate=rate,geometryCount=original.Geometry.Length,clipRms=rms,sourceCount=scene.sources.Length,frameCount=original.Metadata.frameCount,
            durationSamples=original.Metadata.durationSamples,period=plane.burstPeriodSamples,duration=plane.burstDurationSamples,capacity=plane.samples},true));
        Debug.Log("SEEDED_EMISSION_CHURCH_COMPLETE");
    }
    [Serializable] sealed class Result
    {
        public int sourceVersion,version,sampleRate,geometryCount,sourceCount,frameCount,period,duration,capacity;
        public long durationSamples;public float clipRms;
    }
}
