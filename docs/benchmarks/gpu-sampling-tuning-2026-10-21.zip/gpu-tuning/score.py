import json,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'));import gpu_routes as gpu
def quality(value,ref):
    floor=np.sqrt(np.mean(abs(ref)**2))*1e-6
    db=20*np.log10(np.maximum(abs(value),floor)/np.maximum(abs(ref),floor))
    return dict(complexL2=float(np.linalg.norm(value-ref)/np.linalg.norm(ref)),within3dB=float(np.mean(abs(db)<=3)),medianAbsDb=float(np.median(abs(db))))
rows=[];summaries=[]
for n in (1,9,25):
    scene=ROOT/f'.context/spatial-accuracy/planar-{n}/scene.json'
    reference=np.load(scene.parent/'reference-0.35-250.npz')['pressure']
    common=np.load(ROOT/f'.context/route-monte-carlo/planar-{n}-connections-full.npz')
    cm=json.loads((ROOT/f'.context/route-monte-carlo/planar-{n}-connections-full.json').read_text())
    assert cm['sceneSha256']==gpu.sha(scene)
    for scale in (1.,.25):
        fields=[];times=[];local=[]
        for seed in (17,65554,131091,196628):
            p=OUT/f'heldout-{n}-s{scale}-seed{seed}';meta=json.loads((p/'metadata.json').read_text())
            assert meta['sceneSha256']==gpu.sha(scene) and meta['proposalScale']==scale
            ids=np.array(meta['indices']);data=np.genfromtxt(p/'gpu.csv',delimiter=',',names=True)
            np.testing.assert_array_equal(np.load(p/'cpu.npz')['points'],common['points'][ids])
            value=data['real']+1j*data['imag']+common['pressure'][ids].sum(axis=1)
            fields.append(value);times.extend(data['solve_seconds'])
            row=dict(scene=n,scale=scale,seed=seed,**quality(value,reference[ids]),**json.loads((p/'checked.json').read_text()))
            local.append(row);rows.append(row)
        fields=np.array(fields);ref=reference[ids]
        item=dict(scene=n,scale=scale,probes=len(ids),meanComplexL2=float(np.mean([r['complexL2'] for r in local])),
            minComplexL2=float(min(r['complexL2'] for r in local)),maxComplexL2=float(max(r['complexL2'] for r in local)),
            meanWithin3dB=float(np.mean([r['within3dB'] for r in local])),
            freshSeedComplexL2=float(np.mean([r['complexL2'] for r in local if r['seed'] in (131091,196628)])),
            repeatNoise=float(np.sqrt(np.sum(abs(fields-fields.mean(axis=0))**2)/(len(fields)-1))/np.linalg.norm(ref)),
            medianSolveMs=float(np.median(times)*1000),p95SolveMs=float(np.quantile(times,.95)*1000))
        summaries.append(item);print(item,flush=True)
gpu.save(OUT/'heldout.json',dict(rows=rows,summary=summaries))
