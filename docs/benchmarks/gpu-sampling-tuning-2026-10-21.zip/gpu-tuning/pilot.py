"""Single-thread proposal screen. Fixed tuning/held-out split, unchanged integrand."""
import hashlib, inspect, json, sys, time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[2]; OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools')); import edge_integral as edge
def save(p,v): p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def quality(value,ref):
    floor=np.sqrt(np.mean(abs(ref)**2))*1e-6
    db=20*np.log10(np.maximum(abs(value),floor)/np.maximum(abs(ref),floor))
    return dict(error=float(np.linalg.norm(value-ref)/np.linalg.norm(ref)),within3dB=float(np.mean(abs(db)<=3)))
namespace=dict(vars(edge))
source=inspect.getsource(edge.sampled).replace(
    'connected = connections(config, points, hz, 0, depth=mirror_depth, integrate_chain=estimate)',
    'connected = np.zeros((len(points), 4), complex)')
exec(compile(source,'<pure-edge-screen>','exec'),namespace)
solver=namespace['sampled']; original=edge.draw_height
splits={}
for n in (1,9,25):
    parent=ROOT/f'.context/spatial-accuracy/planar-{n}'
    ids=np.load(parent/'prototype.npz')['indices']
    splits[str(n)]=dict(tuning=ids[::4].tolist(),heldout=np.delete(ids,np.arange(0,len(ids),4)).tolist())
save(OUT/'split.json',splits)
rows=[]
for scale,cv in [(s,False) for s in (.125,.25,.5,1.,2.,4.)]+[(1.,True)]:
    edge.draw_height=lambda centers,scales,random,low,high: original(centers,scales*scale,random,low,high)
    for n in (1,9,25):
        parent=ROOT/f'.context/spatial-accuracy/planar-{n}'
        c=json.loads((parent/'scene.json').read_text()); ids=np.array(splits[str(n)]['tuning'])
        points=np.array(c['points']).reshape(-1,3)[ids]
        ref=np.load(parent/'reference-0.35-250.npz')['pressure'][ids]
        common=np.load(ROOT/f'.context/route-monte-carlo/planar-{n}-connections-full.npz')['pressure'].sum(axis=1)[ids]
        for seed in (17,65554):
            start=time.perf_counter()
            value,_,_=solver(c,points,250,65536,seed,2,route_budget=True,control_variate=cv)
            seconds=time.perf_counter()-start; pressure=value.sum(axis=1)+common
            row=dict(scale=scale,cv=cv,scene=n,seed=seed,seconds=seconds,**quality(pressure,ref))
            rows.append(row); print(row,flush=True)
            np.savez_compressed(OUT/f'pilot-{n}-s{scale}-cv{int(cv)}-seed{seed}.npz',pressure=pressure,orders=value,indices=ids)
            save(OUT/'pilot.json',dict(samples=65536,depth=2,hz=250,rows=rows,
                 solverSha256=hashlib.sha256(Path(edge.__file__).read_bytes()).hexdigest()))
edge.draw_height=original
