"""Retain the experiment in the existing report, including unsuccessful candidates."""
import hashlib,json,shutil,sys,zipfile
from pathlib import Path
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'));import gpu_routes as gpu
maps=json.loads((OUT/'maps.json').read_text());heldout=json.loads((OUT/'heldout.json').read_text())
selection=json.loads((OUT/'selection.json').read_text())
sources=['tools/edge_integral.py','tools/gpu_routes.py','Assets/Tests/Editor/RouteIntegration.compute','Assets/Tests/Editor/RouteIntegrationChecks.cs']
hashes={p:gpu.sha(ROOT/p) for p in sources}
for p in sources:
    dest=OUT/'source'/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/p,dest)
for name in ('empty','no-support','first-order','dc','four-edges','route-subset'):
    shutil.copytree(ROOT/'.context/gpu-routes'/name,OUT/'legacy-controls'/name,dirs_exist_ok=True)
tests={}
for name in ('controls','heldout','maps'):
    xml=ET.parse(OUT/f'{name}.xml').getroot()
    assert xml.get('result')=='Passed' and xml.get('failed')=='0' and xml.get('skipped')=='0',xml.attrib
    provenance=json.loads((OUT/f'{name}-provenance.json').read_text())
    for p in sources[2:]:assert provenance['files'][p]==hashes[p]
    tests[name]={key:xml.get(key) for key in ('passed','failed','skipped','duration')}
refs={}
for n in (1,9,25):
    for p in [ROOT/f'.context/spatial-accuracy/planar-{n}/scene.json',ROOT/f'.context/spatial-accuracy/planar-{n}/reference-0.35-250.npz',
              ROOT/f'.context/route-monte-carlo/planar-{n}-connections-full.npz']:
        refs[str(p.relative_to(ROOT))]=gpu.sha(p)
summary=dict(scope='Offline rigid planar point-source/extruded-wall fields, 250 Hz, pure edges and common mirror/mixed paths through order two.',
    decision='Keep scale 0.25 as an opt-in low-budget candidate; default scale stays 1.0. Fresh-seed and amplitude results are mixed. Accept the numerical inverse-CDF fix.',
    sourceHashes=hashes,referenceHashes=refs,split=json.loads((OUT/'split.json').read_text()),selection=selection,
    heldout=heldout['summary'],fullMaps=maps,tests=tests,cpuChecks=len(json.loads((OUT/'cpu-controls.json').read_text())['checks']),
    limits=['These are existing layouts, with positions held out of this tuning sweep; no unseen scene or frequency validation.',
        'Four seeds on held-out probes; full maps use seed 17 only. No pressure/seed averaging for reported map quality.',
        'GPU timings are synchronous integration/reduction/readback at one frequency, not full-band audio or end-to-end cost.',
        'CPU visibility, route planning and direct/mirror/mixed integration remain outside GPU timings.',
        'Wave references have measured mesh convergence, not certified physical truth. No motion, finite 3D, materials or DSP qualification.'])
gpu.save(OUT/'summary.json',summary)
def row(n,count,scale):return next(r for r in maps if (r['scene'],r['samples'],r['scale'])==(n,count,scale))
def hold(n,scale):return next(r for r in heldout['summary'] if (r['scene'],r['scale'])==(n,scale))
fieldrows=[];holdrows=[];timerows=[]
for n in (1,9,25):
    a,b,c,d=[row(n,count,scale) for count,scale in ((65536,1.),(65536,.25),(1048576,1.),(1048576,.25))]
    fieldrows.append(f"| {n} | {a['complexL2']*100:.2f}% → {b['complexL2']*100:.2f}% | {a['within3dB']*100:.1f}% → {b['within3dB']*100:.1f}% | {c['complexL2']*100:.2f}% → {d['complexL2']*100:.2f}% |")
    timerows.append(f"| {n} | {a['medianSolveMs']:.3f} → {b['medianSolveMs']:.3f} ms | {c['medianSolveMs']:.3f} → {d['medianSolveMs']:.3f} ms | {b['cpuPreparationSeconds']:.2f} s |")
    a,b=hold(n,1.),hold(n,.25)
    holdrows.append(f"| {n} | {a['probes']} | {a['meanComplexL2']*100:.2f}% → {b['meanComplexL2']*100:.2f}% | {a['meanWithin3dB']*100:.1f}% → {b['meanWithin3dB']*100:.1f}% | {a['freshSeedComplexL2']*100:.2f}% → {b['freshSeedComplexL2']*100:.2f}% |")
text='''## GPU sampling tuning — 2026-10-21

**Narrower height proposals give a modest low-budget improvement.** A quarter-width proposal reduced full-map complex-pressure error from 32.02% to 27.90% for nine boxes and 83.23% to 78.76% for 25 boxes at the same 65,536 samples per receiver. Held-out improvements are smaller, some seed/amplitude results regress, and the difference nearly disappears at 1,048,576 samples. Keep `--proposal-scale .25` optional; the default remains `1`. The live renderer is unchanged.

![Actual 2D fields before and after tuning](benchmarks/gpu-sampling-tuning-2026-10-21.png)

### What changes

```text
width = existing geometric proposal width × proposalScale
height ~ truncated Cauchy mixture(width)
contribution = unchanged signed pressure(height) / exact proposal density(height, width)
```

Scaling narrows or widens where height samples fall on each selected edge. Every allowed height retains sampling support, and the PDF uses the same width as the draw. Route selection, diffraction coefficients, distance spreading, phase, physical delay support and cached direct/mirror/mixed fields are unchanged. This is sampling tuning, not amplitude fitting or removal of paths.

Narrowing also exposed a float precision problem: interpolating large opposite height endpoints loses precision around a narrow peak. The shader now rotates the nearer endpoint direction and recovers height from the direction ratio. This is the same inverse CDF; it avoids that subtraction. A four-edge per-sample CPU comparison originally failed at 0.36% relative error and now passes the original tolerance. The change improves full-grid CPU/GPU agreement to 0.00018–0.00036% relative L2 at the original width.

Four existing executable files change by **five net lines**. There is one optional proposal-width parameter and a versioned benchmark input header; both prior and new input versions are tested. There are no new runtime components, packages or live quality modes. CPU control variates were screened but not added to the GPU.

### Selection and held-out checks

The screen tested widths **0.125, 0.25, 0.5, 1, 2 and 4**, plus the existing CPU control-variate option at width 1. It used 25/24/24 predetermined tuning positions from the earlier coarse lattices, seeds 17/65554 and 65,536 samples per position. Width 0.25 had the lowest geometric mean of per-scene mean complex error relative to baseline: 0.907. The control variate scored 0.974 while taking 36–41% more CPU wall time in the larger tuning cases. All candidate results are retained.

Width 0.25 was fixed before GPU validation on the remaining **73/72/70 lattice positions**, with seeds 17, 65554, 131091 and 196628. These are positions held out of this sweep in existing scenes, not new scene families. Tables average each seed's error; they do not first average the pressure fields. The final column uses only the two seeds not used in selection.

| Boxes | Held-out positions | Mean complex error: original → quarter | Positions within ±3 dB: original → quarter | Fresh-seed complex error: original → quarter |
|---:|---:|---:|---:|---:|
'''+ '\n'.join(holdrows)+'''

The nine-box fresh-seed complex score regresses slightly, and the 25-box amplitude score also declines slightly. Across all four seeds, measured pressure variation falls from 19.22% to 16.25% of reference L2 norm for nine boxes, but stays about 36% for 25 boxes. This evidence does not establish a universally better default or stable moving-listener audio.

### Whole-map accuracy and cost

Full maps contain 1,014/960/880 evaluated receivers, use seed 17 and share the absolute pressure scale shown. Frequencies, wave fields, physical model and cached connection fields match the prior study. These are 2D maps of a point source with infinitely extruded walls, not a line-source wave or finite 3D scene. Complex error includes amplitude and phase; within ±3 dB measures amplitude only.

| Boxes | Complex error at 65,536: original → quarter | Within ±3 dB at 65,536: original → quarter | Complex error at 1,048,576: original → quarter |
|---:|---:|---:|---:|
'''+ '\n'.join(fieldrows)+'''

Warm median integration/reduction/readback time on Apple M5 / Metal, per position at **one frequency**. Both widths run the corrected inverse CDF and identical sample counts. Similar measured costs support a matched-budget comparison; timing fluctuations are not claimed as an algorithmic speedup. Cold compilation/allocation, initial random upload, CPU preparation and the separate connection stage are excluded from the GPU medians.

| Boxes | 65,536: original → quarter | 1,048,576: original → quarter | Quarter-width CPU preparation, whole 65K map |
|---:|---:|---:|---:|
'''+ '\n'.join(timerows)+'''

The cached CPU direct/mirror/mixed stage separately took 0.36/30.69/213.96 seconds in the prior run. Route geometry/packing remains a CPU cost. The GPU's millisecond figures must not be presented as whole-pipeline or full-band realtime costs.

### Validation, decision and reproduction

**30 CPU checks pass**, including independent DC/250 Hz quadrature for the narrow proposal. **12 GPU numerical cases** cover six conditions at both widths, with captured per-sample parity checks; **36 GPU field measurement cases** and the existing 115-angle numerical control pass. Three Unity invocations report 13/25/13 passed, zero failures or skips. Full original-width maps and seed-17 held-out probes at both widths also pass CPU aggregate parity. Tolerances were not weakened. The existing Metal potential-uninitialized-return warning remains; zero-support controls and finite-value checks pass.

Accept the inverse-CDF precision fix; retain the quarter-width setting as an explicit low-budget experiment. Neither width makes the large-scene field suitable as acoustic training truth. The high-budget residual needs an order-resolved comparison separating sampling noise from pure-edge/mixed-path truncation and physical approximation. This sweep does not prove which dominates, and does not validate other frequencies, materials, moving geometry, DSP or finite 3D.

```sh
python tools/gpu_routes.py prepare /tmp/quarter-width --scene /path/to/scene.json \\
  --samples 65536 --depth 2 --seed 17 --hz 250 --proposal-scale .25 --cpu
```

Use the existing isolated Unity measurement runner, then `python tools/gpu_routes.py check /tmp/quarter-width`. Reproduce the sweep from the archived `pilot.py`, `measure.py`, `score.py` and `maps.py`, alongside the preceding GPU-route/spatial-reference archives. Run silently with one low-priority numerical/GPU job, no user-editor interaction or audio playback.

[Ledger](benchmarks/gpu-sampling-tuning-2026-10-21.json) · [Raw candidates, fields, tests and reproduction scripts](benchmarks/gpu-sampling-tuning-2026-10-21.zip). Large request buffers are omitted and reproducible from recorded inputs; hashes are retained. The prior archive retains the old inverse-CDF implementation and original measurements.

'''
report=ROOT/'docs/cleanup-results.md';original=report.read_text();heading='# Cleanup validation and measured bottlenecks\n\n'
assert original.startswith(heading) and '## GPU sampling tuning —' not in original
report.write_text(heading+text+original[len(heading):])
base=ROOT/'docs/benchmarks/gpu-sampling-tuning-2026-10-21'
shutil.copy2(OUT/'summary.json',base.with_suffix('.json'));shutil.copy2(OUT/'gpu-tuning-maps.png',base.with_suffix('.png'))
with zipfile.ZipFile(base.with_suffix('.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for p in sorted(OUT.rglob('*')):
        if p.is_file() and not (p.name=='requests.bin' and p.stat().st_size>1_000_000):
            archive.write(p,Path('gpu-tuning')/p.relative_to(OUT))
print('Published',base,'archive bytes',base.with_suffix('.zip').stat().st_size)
