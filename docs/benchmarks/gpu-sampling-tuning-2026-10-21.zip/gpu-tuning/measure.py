"""GPU confirmation after the CPU-only proposal screen; no fitting on held-out positions."""
import json, shutil, subprocess, sys
from pathlib import Path
import numpy as np
from scipy.stats import qmc
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'));import edge_integral as edge;import gpu_routes as gpu
def run(cases):
    subprocess.run([sys.executable,str(ROOT/'.context/gpu-routes/run.py'),*[str(p) for p in cases]],check=True)
    for p in cases:gpu.check(p)
if sys.argv[1]=='controls':
    checks=edge.validate()
    wedge=(np.zeros(2),np.array([0.,-1]),np.array([1.,0]),0,2*np.pi)
    source,receiver=np.array([-2.,1,0]),np.array([2.,-2,0])
    draws=qmc.Sobol(4,scramble=True,bits=30,seed=17).random_base2(16)+.5/2**30
    for hz in (0,250):
        exact=edge.first(wedge,source,receiver,2*np.pi*hz/343,34.3,16)
        value=edge.sample_chain([wedge],source,receiver,2*np.pi*hz/343,34.3,draws,proposal_scale=.25)
        error=abs(value-exact)/abs(exact);assert error<.001,(hz,error)
        checks.append(dict(check='narrow proposal vs independent quadrature',hz=hz,relativeError=float(error)))
    gpu.save(OUT/'cpu-controls.json',dict(checks=checks,solverSha256=gpu.sha(Path(edge.__file__))))
    cases=[]
    for name in ('empty','no-support','first-order','dc','four-edges','route-subset'):
        old=ROOT/'.context/gpu-routes'/name;meta=json.loads((old/'metadata.json').read_text());p=OUT/name
        gpu.prepare(p,old/'scene.json',meta['samples'],meta['depth'],meta['seed'],meta['hz'],meta['indices'],True,True,proposal_scale=.25)
        cases.append(p)
    run(cases)
elif sys.argv[1]=='heldout':
    split=json.loads((OUT/'split.json').read_text());cases=[]
    for seed in (17,65554,131091,196628):
        for n in (1,9,25):
            for scale in ((1.,.25) if seed in (17,131091) else (.25,1.)):
                p=OUT/f'heldout-{n}-s{scale}-seed{seed}'
                gpu.prepare(p,ROOT/f'.context/spatial-accuracy/planar-{n}/scene.json',65536,2,seed,250,
                    split[str(n)]['heldout'],cpu=seed==17,proposal_scale=scale)
                cases.append(p)
    run(cases)
elif sys.argv[1]=='maps':
    cases=[]
    for n in (1,9,25):
        for count in (65536,1048576):
            p=OUT/f'full-{n}-n{count}-s1.0';old=ROOT/f'.context/gpu-routes/planar-{n}-n{count}'
            p.mkdir()
            for name in ('metadata.json','scene.json','cpu.npz'):shutil.copy2(old/name,p/name)
            (p/'requests.bin').symlink_to(old/'requests.bin')
            cases.append(p)
            p=OUT/f'full-{n}-n{count}-s0.25'
            gpu.prepare(p,ROOT/f'.context/spatial-accuracy/planar-{n}/scene.json',count,2,17,250,proposal_scale=.25)
            cases.append(p)
    run(cases)
else:raise ValueError(sys.argv[1])
