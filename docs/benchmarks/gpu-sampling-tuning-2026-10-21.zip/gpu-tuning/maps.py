"""Show actual evaluated 2D cells on one pressure scale, without seed averaging."""
import json,shutil,sys
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
DEST=Path('/Users/clarkpeng/conductor/workspaces/realisticaudioraytracing2d/tyler/.context')
sys.path.insert(0,str(ROOT/'tools'));import gpu_routes as gpu
def quality(value,ref):
    floor=np.sqrt(np.mean(abs(ref)**2))*1e-6
    db=20*np.log10(np.maximum(abs(value),floor)/np.maximum(abs(ref),floor))
    return dict(complexL2=float(np.linalg.norm(value-ref)/np.linalg.norm(ref)),within3dB=float(np.mean(abs(db)<=3)),medianAbsDb=float(np.median(abs(db))))
fig,axes=plt.subplots(3,4,figsize=(16,12.6),layout='constrained')
cmap=plt.colormaps['magma'].with_extremes(over='#27c9bd',under='#050505',bad='#e5e7eb')
summary=[]
for row,n in enumerate((1,9,25)):
    scene=ROOT/f'.context/spatial-accuracy/planar-{n}/scene.json';c=json.loads(scene.read_text())
    reference=np.load(scene.parent/'reference-0.35-250.npz')['pressure']
    commonpath=ROOT/f'.context/route-monte-carlo/planar-{n}-connections-full.npz';common=np.load(commonpath)
    cm=json.loads(commonpath.with_suffix('.json').read_text());assert cm['sceneSha256']==gpu.sha(scene)
    shared=common['pressure'].sum(axis=1);fields={};measures={}
    for count in (65536,1048576):
        for scale in (1.,.25):
            p=OUT/f'full-{n}-n{count}-s{scale}';meta=json.loads((p/'metadata.json').read_text())
            assert meta['sceneSha256']==gpu.sha(scene) and meta.get('proposalScale',1)==scale
            np.testing.assert_array_equal(meta['indices'],common['indices'])
            data=np.genfromtxt(p/'gpu.csv',delimiter=',',names=True)
            fields[count,scale]=data['real']+1j*data['imag']+shared
            item=dict(scene=n,scale=scale,**quality(fields[count,scale],reference),**json.loads((p/'checked.json').read_text()))
            item['preparedGpuStageSeconds']=item['gpuSolveSeconds']+item['uploadSeconds']+item['inputSeconds']
            measures[count,scale]=item;summary.append(item)
            print(n,count,scale,'error %',item['complexL2']*100,'within 3dB %',item['within3dB']*100,'ms',item['medianSolveMs'],flush=True)
    plotted=[reference,fields[65536,1.],fields[65536,.25],fields[1048576,.25]]
    titles=['Wave reference','Original width · 65,536','Quarter width · 65,536','Quarter width · 1,048,576']
    configs=[None,(65536,1.),(65536,.25),(1048576,.25)]
    for col,(value,title,config) in enumerate(zip(plotted,titles,configs)):
        floor=np.sqrt(np.mean(abs(reference)**2))*1e-6
        grid=np.full(len(c['x'])*len(c['y']),np.nan);grid[c['gridIndices']]=20*np.log10(np.maximum(abs(value),floor))
        ax=axes[row,col];im=ax.pcolormesh(c['x'],c['y'],grid.reshape(len(c['y']),len(c['x'])),cmap=cmap,vmin=-40,vmax=5,shading='nearest')
        for wall in c['walls']:
            center,half=np.array(wall['center'][:2]),np.array(wall['half'][:2])
            ax.add_patch(Rectangle(center-half,*(2*half),facecolor='#515962',edgecolor='white',linewidth=.5))
        ax.scatter(*c['source'][:2],marker='*',s=100,color='#00a8ff',edgecolor='black',linewidth=.5,zorder=5)
        ax.set(xlim=(-6.9,6.25),ylim=(-5.7,5.7),xlabel='x (m)',ylabel='y (m)');ax.set_aspect('equal')
        ax.set_title(f"{n} {'box' if n==1 else 'boxes'} · {title}",fontsize=10)
        if config:
            q=measures[config];ax.text(.025,.025,f"{q['complexL2']*100:.1f}% complex error\n{q['within3dB']*100:.1f}% of cells within ±3 dB",transform=ax.transAxes,fontsize=8.5,
                bbox=dict(facecolor='white',alpha=.92,edgecolor='none',pad=3))
    fig.colorbar(im,ax=list(axes[row]),shrink=.77,pad=.015,extend='both',label='Pressure level (dB re unit pressure)')
    np.savez_compressed(OUT/f'planar-{n}-fields.npz',reference=reference,original65k=fields[65536,1.],quarter65k=fields[65536,.25],
        original1m=fields[1048576,1.],quarter1m=fields[1048576,.25],points=common['points'])
fig.suptitle('Sampling tuning · 2D spatial pressure maps · 250 Hz\nSame two-interaction physics; change where samples are placed, preserve their exact probability weights',fontsize=15)
fig.supxlabel('Seed 17 · Blue star: source · Grey blocks: obstacles · Shared absolute pressure scale\nGPU pure-edge integration + identical cached CPU direct/reflection/mixed field. No pressure fitting, clipping or seed averaging.',fontsize=10)
fig.savefig(OUT/'gpu-tuning-maps.png',dpi=150);plt.close(fig);shutil.copy2(OUT/'gpu-tuning-maps.png',DEST/'gpu-tuning-maps.png')
gpu.save(OUT/'maps.json',summary)
