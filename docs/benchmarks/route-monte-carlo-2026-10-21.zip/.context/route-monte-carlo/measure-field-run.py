"""Silent CPU sampling ablation. Identical routes, target integrand and connections."""
import argparse, hashlib, importlib.util, inspect, json, sys, time
from pathlib import Path
import numpy as np
from scipy.stats import qmc
ROOT=Path(__file__).resolve().parents[2]; OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
import edge_integral as edge
SOLVER_BYTES=Path(edge.__file__).read_bytes()
SOLVER_HASH=hashlib.sha256(SOLVER_BYTES).hexdigest()
(OUT/f'edge-{SOLVER_HASH[:12]}.py').write_bytes(SOLVER_BYTES)
spec=importlib.util.spec_from_file_location('independent',OUT/'edge-01035a05ab6f.py')
independent=importlib.util.module_from_spec(spec); spec.loader.exec_module(independent)

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def functions(mode):
    base=edge if mode in ['balanced','stratified','pooled'] else independent
    namespace=dict(vars(base))
    if mode=='listener':
        code=inspect.getsource(base.sample_chain)
        code=code.replace('center = previous*rr/(rs+rr)',
            'rr = np.linalg.norm(edge[0]-receiver[:2])\n        center = previous*rr/(rs+rr)')
        code=code.replace('abs(np.sin(phi[i]/2))[None,:]', 'abs(np.sin(angles(edge, points[i], receiver)/2))[None,:]')
        code=code.replace('        if i:\n            incoming', '        if False:\n            incoming')
        exec(compile(code,'<listener-guide-ablation>','exec'),namespace)
    code=inspect.getsource(base.sampled).replace(
        'connected = connections(config, points, hz, 0, depth=mirror_depth, integrate_chain=estimate)',
        'connected = np.zeros((len(points), 4), complex)')
    if mode=='shared':
        code=code.replace('random[selected]', 'random[:len(selected)]')
    exec(compile(code,'<pure-edge-measurement>','exec'),namespace)
    return namespace['sampled']

def measure(name,count,depth,mode,seeds,full=False):
    parent=ROOT/'.context/spatial-accuracy'/name
    c=json.loads((parent/'scene.json').read_text()); allpoints=np.array(c['points']).reshape(-1,3)
    ids=np.arange(len(allpoints)) if full else np.load(parent/'prototype.npz')['indices']
    points=allpoints[ids]; stem=OUT/(f'{name}-{mode}-n{count}-d{depth}-'+('full' if full else 'lattice'))
    if stem.with_suffix('.json').exists(): raise FileExistsError(stem)
    solver=functions(mode); values=[]; counts=[]; rows=[]
    for seed in seeds:
        start=time.perf_counter(); stats={}
        v,_,r=solver(c,points,250,count,seed,depth,route_budget=mode!='enumerated',stats=stats)
        seconds=time.perf_counter()-start
        assert np.isfinite(v).all()
        values.append(v); counts.append(r)
        row=dict(seed=seed,seconds=seconds,stats=stats,maximumPressure=float(abs(v.sum(axis=1)).max()))
        rows.append(row); print(stem.name,row,flush=True)
        np.savez_compressed(stem.with_suffix('.npz'),pressure=values,counts=counts,indices=ids,points=points)
    stem.with_suffix('.json').write_text(json.dumps(dict(rows=rows,mode=mode,samples=count,depth=depth,hz=250,
        sceneSha256=sha(parent/'scene.json'),solverSha256=SOLVER_HASH if mode in ['balanced','stratified','pooled'] else sha(independent.__file__),driverSha256=sha(__file__),
        scope='CPU pure-edge stage including geometry setup. Mirror/direct fields measured separately. Not a GPU measurement.'),indent=2)+'\n')

def connections(name,full):
    parent=ROOT/'.context/spatial-accuracy'/name
    c=json.loads((parent/'scene.json').read_text()); allpoints=np.array(c['points']).reshape(-1,3)
    ids=np.arange(len(allpoints)) if full else np.load(parent/'prototype.npz')['indices']
    points=allpoints[ids]; stem=OUT/(f'{name}-connections-'+('full' if full else 'lattice'))
    if stem.with_suffix('.json').exists(): raise FileExistsError(stem)
    # Fixed common field; phase-resolving quadrature for every mixed one-edge route.
    start=time.perf_counter(); values=edge.connections(c,points,250,8,depth=2); seconds=time.perf_counter()-start
    np.savez_compressed(stem.with_suffix('.npz'),pressure=values,indices=ids,points=points)
    meta=dict(seconds=seconds,order=8,depth=2,hz=250,sceneSha256=sha(parent/'scene.json'),solverSha256=SOLVER_HASH)
    stem.with_suffix('.json').write_text(json.dumps(meta,indent=2)+'\n'); print(stem.name,meta,flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('names',nargs='+');p.add_argument('--samples',type=int,default=256)
    p.add_argument('--depth',type=int,default=2);p.add_argument('--modes',nargs='+',default=['listener','route'])
    p.add_argument('--seeds',type=int,nargs='+',default=[17,65554,131091,196628]);p.add_argument('--full',action='store_true')
    a=p.parse_args()
    for name in a.names:
        for mode in a.modes:
            if mode=='connections': connections(name,a.full)
            else: measure(name,a.samples,a.depth,mode,a.seeds,a.full)
