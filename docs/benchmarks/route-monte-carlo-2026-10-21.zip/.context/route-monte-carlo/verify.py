import ast, hashlib, importlib.util, json, subprocess, sys
from pathlib import Path
import numpy as np
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1]
sys.path.insert(0,str(ROOT/'tools'));import edge_integral as edge
spec=importlib.util.spec_from_file_location('before',OUT/'edge-before.py');before=importlib.util.module_from_spec(spec);spec.loader.exec_module(before)
c=dict(source=[-3.,.4,0],walls=[dict(center=[0,0,0],half=[1,1,1])],speedOfSound=343,maximumDelaySeconds=.1)
p=np.array([[3.,-.6,0],[-2.4,.7,0],[.2,2.,0]])
checks=[]
for depth,options in [(2,{}),(4,{}),(2,dict(control_variate=True)),(2,dict(roulette=.2))]:
 a=edge.sampled(c,p,250,64,17,depth,**options);b=before.sampled(c,p,250,64,17,depth,**options)
 assert all(np.array_equal(x,y) for x,y in zip(a,b))
 checks.append(dict(check='default-mode bit compatibility',depth=depth,options=options,passed=True))
for n in [1,9,25]:
 name=f'planar-{n}';stem=OUT/f'{name}-cli'
 subprocess.run([sys.executable,str(ROOT/'tools/edge_integral.py'),str(stem),'--scene',str(ROOT/'.context/spatial-accuracy'/name/'scene.json'),
  '--points','0','--hz','250','--samples','65536','--route-budget','--depth','2','--mirror-depth','2'],check=True,stdout=subprocess.DEVNULL)
 data=np.load(stem.with_suffix('.npz'));measured=np.load(OUT/f'{name}-pooled-n65536-d2-full.npz')
 np.testing.assert_array_equal(data['pressure'][0],measured['pressure'][0,0])
 assert data['routes'].sum()==65536
 meta=json.loads(stem.with_suffix('.json').read_text());assert meta['samplesPerProbe']==65536 and meta['routeBudget']
 checks.append(dict(check='CLI reproduces measured pure-edge field exactly',scene=name,passed=True))
(OUT/'compatibility.json').write_text(json.dumps(dict(checks=checks,solverSha256=hashlib.sha256(Path(edge.__file__).read_bytes()).hexdigest()),indent=2)+'\n')
print(checks,flush=True)
