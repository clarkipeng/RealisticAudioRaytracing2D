import json, shutil
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];STUDY=ROOT/'.context/spatial-accuracy'
DEST=Path('/Users/clarkpeng/conductor/workspaces/realisticaudioraytracing2d/tyler/.context')
fig,axes=plt.subplots(3,3,figsize=(12,10),layout='constrained')
for row,n in enumerate([1,9,25]):
 name=f'planar-{n}';c=json.loads((STUDY/name/'scene.json').read_text())
 ref=np.load(STUDY/name/'reference-0.35-250.npz')['pressure']
 data=np.load(OUT/f'{name}-pooled-n65536-d2-full.npz')
 field=data['pressure'][0].sum(axis=1)+np.load(OUT/f'{name}-connections-full.npz')['pressure'].sum(axis=1)
 floor=np.sqrt(np.mean(abs(ref)**2))*1e-6
 vals=[20*np.log10(np.maximum(abs(ref),floor)),20*np.log10(np.maximum(abs(field),floor)),
       20*np.log10(np.maximum(abs(field),floor)/np.maximum(abs(ref),floor))]
 for col,v in enumerate(vals):
  ax=axes[row,col];grid=np.full(len(c['x'])*len(c['y']),np.nan);grid[c['gridIndices']]=v
  im=ax.pcolormesh(c['x'],c['y'],grid.reshape(len(c['y']),len(c['x'])),shading='nearest',
   cmap='RdBu_r' if col==2 else 'magma',vmin=-15 if col==2 else -40,vmax=15 if col==2 else 5)
  for w in c['walls']:
   center,half=np.array(w['center'][:2]),np.array(w['half'][:2])
   ax.add_patch(Rectangle(center-half,*(2*half),facecolor='#56616b',edgecolor='white',lw=.5))
  ax.scatter(*c['source'][:2],marker='*',s=70,c='cyan',edgecolor='black',lw=.5)
  ax.set_aspect('equal');ax.set_title(f'{n} '+('box' if n==1 else 'boxes')+' · '+['wave reference','route-budget CPU prototype','level error'][col],fontsize=11)
  ax.set_xlabel('x (m)');ax.set_ylabel('y (m)')
  cb=fig.colorbar(im,ax=ax,shrink=.7);cb.set_label('dB difference' if col==2 else 'dB re unit pressure')
  if col==2:
   ax.text(.02,.02,f'{100*np.mean(abs(v)>15):.1f}% outside colour scale',transform=ax.transAxes,fontsize=8,
    bbox=dict(facecolor='white',alpha=.9,edgecolor='none'))
fig.suptitle('Complete-route Monte Carlo · 250 Hz · 65,536 height samples per receiver\nOne/two-edge orders + mirror/mixed connections through order two · seed 17',fontsize=13)
fig.savefig(OUT/'route-monte-carlo-maps.png',dpi=140);plt.close(fig)
shutil.copy2(OUT/'route-monte-carlo-maps.png',DEST/'route-monte-carlo-maps.png')
