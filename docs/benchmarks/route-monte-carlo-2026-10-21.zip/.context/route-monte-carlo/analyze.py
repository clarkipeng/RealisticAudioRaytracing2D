"""Aggregate raw fields without amplitude fitting, clipping, or seed averaging."""
import ast, hashlib, json
from pathlib import Path
import numpy as np
OUT=Path(__file__).resolve().parent; ROOT=OUT.parents[1]; STUDY=ROOT/'.context/spatial-accuracy'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def metrics(v,ref,shadow):
 floor=np.sqrt(np.mean(abs(ref)**2))*1e-6
 db=20*np.log10(np.maximum(abs(v),floor)/np.maximum(abs(ref),floor))
 return dict(complexL2=float(np.linalg.norm(v-ref)/np.linalg.norm(ref)),
  magnitudeL2=float(np.linalg.norm(abs(v)-abs(ref))/np.linalg.norm(ref)),
  shadowComplexL2=float(np.linalg.norm((v-ref)[shadow])/np.linalg.norm(ref[shadow])) if shadow.any() else None,
  within3dB=float(np.mean(abs(db)<=3)),medianAbsDb=float(np.median(abs(db))),p95AbsDb=float(np.quantile(abs(db),.95)))

rows=[]
for file in sorted(OUT.glob('planar-*-n*-d*-*.json')):
 meta=json.loads(file.read_text()); data=np.load(file.with_suffix('.npz'))
 name='-'.join(file.name.split('-')[:2]); scope='full' if '-full.' in file.name else 'lattice'
 parent=STUDY/name;c=json.loads((parent/'scene.json').read_text())
 assert meta['sceneSha256']==sha(parent/'scene.json')
 ids=data['indices'];np.testing.assert_array_equal(data['points'],np.array(c['points']).reshape(-1,3)[ids])
 common=np.load(OUT/f'{name}-connections-{scope}.npz'); np.testing.assert_array_equal(ids,common['indices'])
 field=data['pressure'].sum(axis=2)+common['pressure'].sum(axis=1)
 assert np.isfinite(field).all()
 ref=np.load(parent/'reference-0.35-250.npz')['pressure'][ids];shadow=abs(common['pressure'][:,0])==0
 scores=[metrics(v,ref,shadow) for v in field]
 common_meta=json.loads((OUT/f'{name}-connections-{scope}.json').read_text())
 row=dict(file=file.name,name=name,scope=scope,mode=meta['mode'],samples=meta['samples'],depth=meta['depth'],
  probes=len(ids),seeds=[r['seed'] for r in meta['rows']],perSeed=scores,
  mean={k:float(np.mean([s[k] for s in scores])) for k in scores[0]},
  medianPureSeconds=float(np.median([r['seconds'] for r in meta['rows']])),
  commonConnectionSeconds=common_meta['seconds'],
  edgeKernels=[r['stats']['edgeKernels'] for r in meta['rows']],
  seedRmsOverReference=float(np.linalg.norm(field-field.mean(axis=0))/np.sqrt(len(field))/np.linalg.norm(ref)),
  solverSha256=meta['solverSha256'])
 rows.append(row)
 if row['mode'] in ['listener','enumerated','pooled']:
  print(name,scope,row['mode'],row['samples'], 'error',round(row['mean']['complexL2']*100,2),
   'within3dB',round(row['mean']['within3dB']*100,1),'pureSec',round(row['medianPureSeconds'],3),flush=True)
controls=json.loads((OUT/'controls-exact.json').read_text())
assert controls['passed'] and controls['solverSha256']==sha(ROOT/'tools/edge_integral.py')
def implementation(p):
 return [ast.dump(n) for n in ast.parse(p.read_text()).body if isinstance(n,ast.FunctionDef) and n.name!='validate']
assert implementation(ROOT/'tools/edge_integral.py')==implementation(OUT/'edge-e9867eaca1e8.py')
result=dict(date='2026-10-21',solverSha256=controls['solverSha256'],measuredSource='edge-e9867eaca1e8.py',
 numericalImplementationUnchangedAfterMeasurements=True,controls=controls['checks'],rows=rows,
 limitations=['CPU prototype, not the live GPU renderer.','Rigid stationary XY boxes, point source with infinite extrusion (2.5D).',
  '250 Hz, pure diffraction and mixed mirror paths truncated at order two in field comparisons.',
  'Full maps use seed 17; seed variation is measured on fixed coarse lattices.',
  'Common direct/mirror/mixed field uses order-eight quadrature and is identical across sampling variants.',
  'Reference mesh refinement is observed convergence, not a certified physical error bound.',
  'CPU timings include geometry setup. Pure-edge budget excludes the enumerated mirror stage.',
  'Early n256 pilot hashes were read at write time; loaded numerical source is edge-route-draft.py (bd10906548f7).',
  'Larger maps remain inaccurate; no GPU, moving-scene, audio-artifact, finite-3D or training qualification.'])
(OUT/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
