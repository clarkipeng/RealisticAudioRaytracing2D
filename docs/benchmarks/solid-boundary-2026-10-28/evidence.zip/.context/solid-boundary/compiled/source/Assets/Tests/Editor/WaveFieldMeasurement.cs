using System;
using System.Collections.Generic;
using System.IO;
using NUnit.Framework;
using UnityEngine;

public partial class TakeChecks
{
    [Serializable] sealed class WaveWall { public float[] center, half; }
    [Serializable] sealed class WaveMotion { public float[] velocity; }
    [Serializable] sealed class WaveScene
    {
        public string physicalModel;
        public float[] source, points, frequencies;
        public WaveWall[] walls;
        public int[] rays, seeds;
        public int sampleRate, fftSize, maxBounces, completeRouteSamples;
        public float speedOfSound, maximumDelaySeconds;
        public bool decompose, captureFamilies, solidGeometry, bakeSolids;
        public float[] triangles;
        public int[] triangleMaterials;
        public AcousticTake.MaterialDefinition[] materials;
        public WaveMotion receiverMotion;
    }
    static Vector3 WaveVector(float[] values, int offset=0) =>
        new Vector3(values[offset], values[offset+1], values[offset+2]);

    // Opt-in measurement, not a test that declares the current renderer physically correct.
    [Test, Category("QualityMeasurement")]
    public void MeasureWaveField()
    {
        string output=Environment.GetEnvironmentVariable("ACOUSTIC_WAVE_OUTPUT");
        if(string.IsNullOrEmpty(output))Assert.Ignore("Set ACOUSTIC_WAVE_OUTPUT to a prepared pressure-map directory.");
        Assert.That(Application.isBatchMode,Is.True,"Use an isolated batch project.");
        string budget=Environment.GetEnvironmentVariable("ACOUSTIC_WAVE_WORK_FRACTION");
        double workFraction=string.IsNullOrEmpty(budget)?1:double.Parse(budget,System.Globalization.CultureInfo.InvariantCulture);
        Assert.That(workFraction,Is.GreaterThan(0).And.LessThanOrEqualTo(1));
        AudioListener.volume=0;
        string compiled=Path.Combine(output,"renderer-scene.json");
        var config=JsonUtility.FromJson<WaveScene>(File.ReadAllText(File.Exists(compiled)?compiled:Path.Combine(output,"scene.json")));
        Assert.That(config.physicalModel,Is.Null.Or.Empty.Or.EqualTo("point-extruded").Or.EqualTo("point-room-3d"),"Unsupported source/geometry model.");
        int owners=config.triangles==null?config.walls.Length:1;
        var scene=Scene(1+owners);scene.listeners=new[]{1};
        if(config.physicalModel=="point-extruded")
        {
            scene.dimension=AcousticTake.Dimension.Planar2D;
            Assert.That(config.source[2],Is.Zero);
            for(int p=2;p<config.points.Length;p+=3)Assert.That(config.points[p],Is.Zero);
        }
        var state=States(1+owners);state[0].position=WaveVector(config.source);
        if(config.receiverMotion?.velocity!=null)
        {state[1].velocity=WaveVector(config.receiverMotion.velocity);state[1].flags|=AcousticTake.StateFlags.VelocityValid;}
        scene.materials=config.materials??new[]{new AcousticTake.MaterialDefinition {name="rigid",frequencies=new[]{0f},
            absorption=new[]{0f},scattering=new[]{0f},transmission=new[]{0f}}};
        var geometry=new List<AcousticTake.Primitive>();
        if(config.triangles!=null)
        {
            Assert.That(config.triangles.Length,Is.EqualTo(config.triangleMaterials.Length*9));
            state[2].position=Vector3.zero;state[2].flags=AcousticTake.StateFlags.Active|AcousticTake.StateFlags.Geometry;
            var bounds=new Bounds(WaveVector(config.triangles),Vector3.zero);
            for(int triangle=0;triangle<config.triangleMaterials.Length;triangle++)
            {
                // FEM normals leave the air. The tracer needs normals leaving the solid.
                geometry.Add(new AcousticTake.Primitive {objectIndex=2,materialIndex=config.triangleMaterials[triangle],
                    a=WaveVector(config.triangles,9*triangle),b=WaveVector(config.triangles,9*triangle+(config.solidGeometry?3:6)),c=WaveVector(config.triangles,9*triangle+(config.solidGeometry?6:3))});
                var p=geometry[triangle];bounds.Encapsulate(p.a);bounds.Encapsulate(p.b);bounds.Encapsulate(p.c);
            }
            // Close the opaque solid outside the air cavity. These outer faces are
            // inaccessible from inside; they preserve solid winding and wedge angles.
            if(!config.solidGeometry)foreach(var face in TransportBox(scene.dimension,2,0,1))
            {
                var p=face;var half=bounds.extents+Vector3.one;
                p.a=bounds.center+Vector3.Scale(p.a,half);p.b=bounds.center+Vector3.Scale(p.b,half);p.c=bounds.center+Vector3.Scale(p.c,half);
                geometry.Add(p);
            }
            scene.objects[2].primitiveCount=geometry.Count;
        }
        for(int w=0;config.triangles==null && w<config.walls.Length;w++)
        {
            int owner=w+2;var wall=config.walls[w];
            state[owner].position=WaveVector(wall.center);
            state[owner].flags=AcousticTake.StateFlags.Active|AcousticTake.StateFlags.Geometry;
            var mesh=TransportBox(scene.dimension,owner,0,1);
            scene.objects[owner].primitiveStart=geometry.Count;scene.objects[owner].primitiveCount=mesh.Length;
            foreach(var triangle in mesh)
            {
                var p=triangle;var half=WaveVector(wall.half);
                p.a=Vector3.Scale(p.a,half);p.b=Vector3.Scale(p.b,half);p.c=Vector3.Scale(p.c,half);
                geometry.Add(p);
            }
        }
        using var baked=config.bakeSolids?new BakedWaveSolid(config,output):null;
        if(baked!=null)
        {
            scene=baked.scene;geometry=new List<AcousticTake.Primitive>(baked.geometry);state=baked.states;
            if(config.receiverMotion?.velocity!=null)
            {state[1].velocity=WaveVector(config.receiverMotion.velocity);state[1].flags|=AcousticTake.StateFlags.VelocityValid;}
        }
        using var csv=new StreamWriter(Path.Combine(output,"renderer.csv"));
        csv.WriteLine("diffraction,rays,seed,point,hz,real,imag,solve_seconds,direct_visible");
        using var terms=config.decompose?new StreamWriter(Path.Combine(output,"path-orders.csv")):null;
        terms?.WriteLine("diffraction,rays,seed,point,hz,slot,real,imag,arrivals,maximum_contribution");
        using var families=config.captureFamilies?new StreamWriter(Path.Combine(output,"families.csv")):null;
        families?.WriteLine("diffraction,seed,point,hz,family,real,imag,arrivals,maximum_contribution");
        if(config.captureFamilies){Assert.That(scene.dimension,Is.EqualTo(AcousticTake.Dimension.Spatial3D));Assert.That(config.materials,Is.Null,"Debug gain is signed only for these rigid controls.");}
        var shader=RequireGpu();var direct=new TakeRender.DirectPath[1];
        foreach(int rays in config.rays)foreach(int seed in config.seeds)foreach(int diffraction in new[]{0,1})
        {
            var settings=EdgeSettings();settings.useBvh=true;settings.airAbsorption=false;
            settings.fftSize=config.fftSize;settings.spectralHop=config.fftSize/2;
            settings.completeRouteSamples=config.completeRouteSamples;
            settings.raysPerBin=rays;settings.seed=seed;settings.maxBounces=config.maxBounces;
            settings.diffractionFactor=diffraction;settings.speedOfSound=config.speedOfSound;
            settings.maximumDelaySeconds=config.maximumDelaySeconds;settings.minimumDistance=.01f;
            using var solver=new TransportSolver(scene,geometry.ToArray(),settings,shader,sampleRate:config.sampleRate);
            state[1].position=WaveVector(config.points);solver.Solve(state,direct); // Exclude cold dispatch.
            if(config.captureFamilies)foreach(float hz in config.frequencies)solver.CaptureRays(state,0,(int)(hz*config.fftSize/config.sampleRate));
            long budgetStarted=System.Diagnostics.Stopwatch.GetTimestamp();
            for(int point=0;point<config.points.Length/3;point++)
            {
                state[1].position=WaveVector(config.points,point*3);
                long started=System.Diagnostics.Stopwatch.GetTimestamp();solver.Solve(state,direct);
                var paths=solver.RayPaths;double seconds=TakeRender.Elapsed(started);
                foreach(float hz in config.frequencies)
                {
                    float bin=hz*config.fftSize/config.sampleRate;
                    Assert.That(bin,Is.EqualTo(Mathf.Round(bin)),"Reference frequencies must be exact configured FFT bins.");
                    var p=EdgeResponse(paths,(int)bin,hz);
                    Assert.That(double.IsFinite(p.Real)&&double.IsFinite(p.Imaginary),Is.True);
                    csv.WriteLine(FormattableString.Invariant($"{diffraction},{rays},{seed},{point},{hz:R},{p.Real:R},{p.Imaginary:R},{seconds:R},{(direct[0].pressureGain!=0?1:0)}"));
                    if(families!=null && diffraction!=0)
                    {
                        var segments=solver.CaptureRays(state,0,(int)bin);
                        int start=geometry.Count+1+settings.RaysPerBin*(2+2*settings.maxBounces)+2*settings.MirrorCandidates(scene);
                        var sums=new System.Numerics.Complex[5];var counts=new int[5];var peaks=new double[5];
                        for(int sample=0;sample<settings.CompleteSamples;sample++)
                        {
                            int at=start+3*sample;var first=segments[at];var second=segments[at+1];
                            if(first.kind==TransportSolver.RayEvent.None)continue;
                            int family=first.kind==TransportSolver.RayEvent.Reflection?(second.kind==TransportSolver.RayEvent.Reflection?4:2):
                                second.kind==TransportSolver.RayEvent.Listener?0:second.kind==TransportSolver.RayEvent.Diffraction?1:3;
                            var arrival=segments[at+(family==0?1:2)];Assert.That(arrival.kind,Is.EqualTo(TransportSolver.RayEvent.Listener));
                            sums[family]+=arrival.pressure*System.Numerics.Complex.Exp(new System.Numerics.Complex(0,-2*Math.PI*hz*arrival.end.w));
                            counts[family]++;peaks[family]=Math.Max(peaks[family],Math.Abs(arrival.pressure));
                        }
                        string[] names={"D","DD","RD","DR","RR"};var captured=System.Numerics.Complex.Zero;
                        for(int f=0;f<5;f++)
                        {captured+=sums[f];families.WriteLine(FormattableString.Invariant($"{diffraction},{seed},{point},{hz:R},{names[f]},{sums[f].Real:R},{sums[f].Imaginary:R},{counts[f]},{peaks[f]:R}"));}
                        int offset=settings.FrequencyBins*(1+settings.MirrorCandidates(scene))+settings.RaysPerPair*settings.PathSlotsPerRay;
                        var ordinary=System.Numerics.Complex.Zero;
                        for(int i=offset;i<paths.Length;i++)if(paths[i].frequencyBin==(int)bin)
                            ordinary+=paths[i].pressureGain*System.Numerics.Complex.Exp(new System.Numerics.Complex(0,-2*Math.PI*hz*paths[i].delaySeconds));
                        Assert.That((captured-ordinary).Magnitude,Is.LessThan(1e-5+ordinary.Magnitude*1e-3),"Debug families must reconstruct the actual complete-route field.");
                        families.Flush();
                    }
                    int mirrorSlots=settings.FrequencyBins*settings.MirrorCandidates(scene);
                    int legacyKinds=settings.PathSlotsPerRay+1+(mirrorSlots>0?1:0);
                    int completeStart=settings.FrequencyBins+mirrorSlots+settings.RaysPerPair*settings.PathSlotsPerRay;
                    int kinds=legacyKinds+(settings.CompleteSamples>0?1:0);
                    if(terms!=null)for(int slot=0;slot<kinds;slot++)
                    {
                        var value=System.Numerics.Complex.Zero;int count=0;double largest=0;
                        for(int i=0;i<paths.Length;i++)
                        {
                            int kind=i>=completeStart?legacyKinds:i<settings.FrequencyBins?0:i<settings.FrequencyBins+mirrorSlots?1:
                                1+(mirrorSlots>0?1:0)+(i-settings.FrequencyBins-mirrorSlots)%settings.PathSlotsPerRay;
                            var path=paths[i];if(kind!=slot||path.frequencyBin!=(int)bin)continue;
                            var gain=new System.Numerics.Complex(path.pressureGain,path.pressureImag);
                            if(gain==System.Numerics.Complex.Zero)continue;
                            value+=gain*System.Numerics.Complex.Exp(new System.Numerics.Complex(0,-2*Math.PI*hz*path.delaySeconds));
                            count++;largest=Math.Max(largest,gain.Magnitude);
                        }
                        terms.WriteLine(FormattableString.Invariant($"{diffraction},{rays},{seed},{point},{hz:R},{slot},{value.Real:R},{value.Imaginary:R},{count},{largest:R}"));
                    }
                }
                // Pace short batches of completed work. Per-point sleeps suffer
                // severe timer coalescing under macOS background task policy.
                double workSeconds=TakeRender.Elapsed(budgetStarted);
                if(workFraction<1 && (workSeconds>=.05 || point+1==config.points.Length/3))
                {
                    System.Threading.Thread.Sleep((int)Math.Min(int.MaxValue,
                        Math.Ceiling(workSeconds*1000*(1/workFraction-1))));
                    budgetStarted=System.Diagnostics.Stopwatch.GetTimestamp();
                }
            }
            csv.Flush();Debug.Log($"Wave field: diffraction={diffraction}, rays={rays}, seed={seed}");
        }
    }

    // Exercise the same bake/import/scene compiler used by live and recorded
    // scenes, rather than substituting a hand-authored union for the renderer.
    sealed class BakedWaveSolid : IDisposable
    {
        readonly GameObject root,source,listener; readonly AudioMaterial material; readonly string asset;
        public readonly AcousticTake.Scene scene;
        public readonly AcousticTake.Primitive[] geometry;
        public readonly AcousticTake.State[] states;
        public BakedWaveSolid(WaveScene config,string output)
        {
            Assert.That(config.triangles,Is.Null);Assert.That(config.materials,Is.Null,"This bake/reference fixture uses rigid walls.");
            Assert.That(config.physicalModel,Is.Not.EqualTo("point-extruded"));
            string python=SolidPython();asset="Assets/wave-solid-"+Guid.NewGuid().ToString("N")+".json";
            root=new GameObject("physical boundary");source=new GameObject("source");listener=new GameObject("listener");
            material=RigidSolidMaterial("rigid");
            try
            {
                var solid=root.AddComponent<AcousticSolid>();solid.members=new AcousticSurface[config.walls.Length];
                var bindings=new List<RayTraceManager.TakeObjectBinding>{new(){id="source",transform=source.transform},new(){id="listener",transform=listener.transform},new(){id="boundary",transform=root.transform,geometry=true}};
                for(int i=0;i<config.walls.Length;i++)
                {
                    var wall=config.walls[i];solid.members[i]=SolidBox(root.transform,"wall-"+i,WaveVector(wall.center),WaveVector(wall.half)*2,material);
                    bindings.Add(new(){id="wall-"+i,transform=solid.members[i].transform,geometry=true});
                }
                AcousticSolidEditor.Bake(solid,python,asset,material);
                File.WriteAllText(Path.Combine(output,"boundary-input.json"),solid.ExportInput(material,out _),new System.Text.UTF8Encoding(false));
                File.WriteAllText(Path.Combine(output,"boundary.json"),solid.boundary.text);
                source.transform.position=WaveVector(config.source);
                scene=SceneToTake.Compile(bindings,AcousticTake.Dimension.Spatial3D,.01f,material,Array.Empty<Transform>(),Array.Empty<AudioClip>(),new[]{listener.transform},out geometry);
                scene.sources=new[]{new AcousticTake.SourceDefinition{objectIndex=0,clipIndex=0}};scene.clips=new[]{new AcousticTake.ClipDefinition()};
                states=new AcousticTake.State[bindings.Count];for(int i=0;i<states.Length;i++)states[i]=SceneToTake.Observe(scene,i,bindings[i].transform);
            }
            catch {Dispose();throw;}
        }
        public void Dispose()
        {
            UnityEditor.AssetDatabase.DeleteAsset(asset);UnityEngine.Object.DestroyImmediate(root);
            UnityEngine.Object.DestroyImmediate(source);UnityEngine.Object.DestroyImmediate(listener);UnityEngine.Object.DestroyImmediate(material);
        }
    }

    // Analytic direct + first-image control, not a full reverberation/wave reference.
    [Test, Category("QualityMeasurement")]
    public void MeasureRoomMaterialMotion()
    {
        string output=Environment.GetEnvironmentVariable("ACOUSTIC_WAVE_OUTPUT");
        if(string.IsNullOrEmpty(output))Assert.Ignore("Set ACOUSTIC_WAVE_OUTPUT for the silent room control.");
        Assert.That(Application.isBatchMode,Is.True);AudioListener.volume=0;
        float[] frequencies={125,250,500};
        float[][] absorption={new[]{0f,0f,0f},new[]{.2f,.2f,.2f},new[]{.6f,.6f,.6f},new[]{.9f,.9f,.9f},new[]{.1f,.4f,.8f}};
        var half=new Vector3(3,2,1.5f);var velocity=new Vector3(1.25f,0,0);var shader=RequireGpu();
        using var csv=new StreamWriter(Path.Combine(output,"room-material-motion.csv"));
        csv.WriteLine("dimension,material,frame,time,hz,absorption,real,imag,reference_real,reference_imag,solve_seconds");
        foreach(var dimension in new[]{AcousticTake.Dimension.Planar2D,AcousticTake.Dimension.Spatial3D})
        for(int material=0;material<absorption.Length;material++)
        {
            var scene=Scene(2);scene.dimension=dimension;scene.listeners=new[]{1};
            scene.materials=new[]{new AcousticTake.MaterialDefinition {name="synthetic-"+material,
                frequencies=frequencies,absorption=absorption[material],scattering=new float[3],transmission=new float[3],
                ior=new[]{1f,1f,1f},damping=new float[3]}};
            var geometry=TransportBox(dimension,2,0,1);scene.objects[2].primitiveCount=geometry.Length;
            for(int i=0;i<geometry.Length;i++)
            {geometry[i].a=Vector3.Scale(geometry[i].a,half);geometry[i].b=Vector3.Scale(geometry[i].b,half);geometry[i].c=Vector3.Scale(geometry[i].c,half);}
            var state=States(2);state[0].position=new Vector3(-1.5f,-.5f,0);state[2].position=Vector3.zero;
            state[2].flags=AcousticTake.StateFlags.Active|AcousticTake.StateFlags.Geometry;
            state[1].velocity=velocity;state[1].flags|=AcousticTake.StateFlags.VelocityValid;
            var images=new List<Vector3>{state[0].position};
            for(int axis=0;axis<(dimension==AcousticTake.Dimension.Planar2D?2:3);axis++)
            foreach(int side in new[]{-1,1})
            {var image=state[0].position;image[axis]=2*side*half[axis]-image[axis];images.Add(image);}
            var settings=EdgeSettings();settings.useBvh=true;settings.airAbsorption=false;settings.diffractionFactor=0;
            settings.fftSize=8;settings.spectralHop=4;settings.maxBounces=1;settings.raysPerBin=geometry.Length;
            settings.maximumDelaySeconds=.1f;settings.speedOfSound=343;settings.minimumDistance=.01f;
            using var solver=new TransportSolver(scene,geometry,settings,shader,sampleRate:1000);
            var direct=new TakeRender.DirectPath[1];state[1].position=new Vector3(-1,.4f,0);solver.Solve(state,direct);
            double error=0,energy=0;
            for(int frame=0;frame<=32;frame++)
            {
                float time=frame/16f;state[1].position=new Vector3(-1,.4f,0)+velocity*time;
                long start=System.Diagnostics.Stopwatch.GetTimestamp();solver.Solve(state,direct);
                var paths=solver.RayPaths;double seconds=TakeRender.Elapsed(start);
                for(int f=0;f<frequencies.Length;f++)
                {
                    float hz=frequencies[f];var expected=System.Numerics.Complex.Zero;
                    for(int image=0;image<images.Count;image++)
                    {
                        double distance=Vector3.Distance(images[image],state[1].position);
                        double gain=(image==0?1:Math.Sqrt(1-absorption[material][f]))/distance;
                        expected+=System.Numerics.Complex.FromPolarCoordinates(gain,-2*Math.PI*hz*distance/343);
                    }
                    var actual=EdgeResponse(paths,(int)(hz*8/1000),hz);
                    error+=(actual-expected).Magnitude*(actual-expected).Magnitude;energy+=expected.Magnitude*expected.Magnitude;
                    csv.WriteLine(FormattableString.Invariant($"{dimension},{material},{frame},{time:R},{hz:R},{absorption[material][f]:R},{actual.Real:R},{actual.Imaginary:R},{expected.Real:R},{expected.Imaginary:R},{seconds:R}"));
                }
            }
            csv.Flush();Assert.That(Math.Sqrt(error/energy),Is.LessThan(.0001),"Early room images and synthetic material pressure must match within 0.01%.");
        }
    }
}
