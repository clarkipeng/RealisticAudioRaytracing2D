from pathlib import Path
import json, struct, sys, warnings
import numpy as np
from scipy.io import wavfile

root=Path(sys.argv[1]);take=json.loads((root/'take/take.json').read_text());scene=take['scene'];rate=take['sampleRate']
events=list(struct.iter_unpack('<qqiif?',(root/'take/events.bin').read_bytes()))
assert take['complete'] and all(a[0]<=b[0] for a,b in zip(events,events[1:]))
names=[scene['objects'][s['objectIndex']]['id'] for s in scene['sources']]
activity={};steps={};starts={}
for sample,offset,source,action,gain,loop in events:
 name=names[source]
 if action==0:
  activity[source]=(sample,offset,gain);starts.setdefault(name,[]).append(sample/rate)
 elif action==1:activity.pop(source,None)
 elif source in activity:
  start,phase,previous=activity[source];steps[name]=max(steps.get(name,0),abs(gain-previous));activity[source]=(start,phase,gain)
report={'sampleRate':rate,'eventCount':len(events),'sourceCount':len(names),'playSeconds':starts,'maximumAutomationGainStep':steps,
 'takeSeconds':take['durationSamples']/rate,'sources':names}
if (root/'audio/run.json').exists():
 render=json.loads((root/'audio/run.json').read_text());assert render['complete'];assert render['settings']['maxBounces']==32
 with warnings.catch_warnings():
  warnings.simplefilter('ignore');hz,y=wavfile.read(root/'audio/listener-0.wav')
 assert hz==rate and np.isfinite(y).all()
 y=np.asarray(y,dtype=np.float64);latency=render['dspLatencySamples'];aligned=y[latency:]
 def stats(a,b):
  x=aligned[round(a*rate):round(b*rate)]
  return {'rms':float(np.sqrt(np.mean(x*x))),'peak':float(np.max(abs(x)))}
 report['windows']={name:stats(a,b) for name,a,b in [('quiet',0,4),('bells',4.3,14),('bird',15.1,22.2),('wind',25,33),('rain',38,44),('thunder',45.3,52),('interior',55,60),('end',70,70.9)]}
 assert report['windows']['quiet']['peak']<1e-7
 assert all(report['windows'][n]['peak']>1e-6 for n in ['bells','bird','wind','rain','thunder'])
 report['masterPeak']=float(np.max(abs(y)));report['masterOverFullScaleSamples']=int(np.count_nonzero(abs(y)>=1))
 report['dspLatencySamples']=latency;report['tailCoversResponseSupport']=render['tailCoversResponseSupport']
 report['movieGain']=.85/report['masterPeak'];report['movieSeconds']=71
(root/'quality.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
