from pathlib import Path
import numpy as np, json, warnings, hashlib
from scipy.io import wavfile
from scipy.signal import resample_poly, find_peaks
warnings.simplefilter('ignore',wavfile.WavFileWarning)
root=Path(__file__).resolve().parents[2];out=root/'Assets/External/Church/Audio';rate=44100
def read(path):
 r,y=wavfile.read(path);y=y.astype(float)/(2**(y.dtype.itemsize*8-1))
 if y.ndim==2:y=y.mean(axis=1)
 if r!=rate:y=resample_poly(y,rate//np.gcd(r,rate),r//np.gcd(r,rate))
 return y-y.mean()
def fade(y,seconds=.025):
 n=round(seconds*rate);y[:n]*=np.sin(np.linspace(0,np.pi/2,n))**2;y[-n:]*=np.cos(np.linspace(0,np.pi/2,n))**2
 return y
bird=fade(read(root/'.context/church-sequence/1670.wav'))
wind=read(root/'.context/church-sequence/1051.wav')[20*rate:37*rate];phase=np.linspace(0,np.pi/2,rate)
loop=wind[:16*rate].copy();loop[:rate]=wind[16*rate:]*np.cos(phase)+wind[:rate]*np.sin(phase)
thunder=fade(read(root/'.context/church-weather/3114.wav'),.03)
stats={}
for name,y,peak in [('RobinCall',bird,.6),('TreeWind',loop,.4),('ThunderCue',thunder,.7)]:
 y*=peak/np.max(abs(y));pcm=np.round(y*32767).astype(np.int16);p=out/(name+'.wav');wavfile.write(p,rate,pcm)
 stats[name]={'seconds':len(y)/rate,'peak':float(max(abs(y))),'rms':float(np.sqrt(np.mean(y*y))),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
r,y=wavfile.read(out/'Bell.wav');env=np.sqrt(np.mean((y.astype(float)/32768).reshape(-1,441)**2,axis=1));peaks,_=find_peaks(env,prominence=.025,distance=55)
stats['bellStrikeSeconds']=[round(float(p)*.01,2) for p in peaks]
(root/'.context/church-sequence/audio-checks.json').write_text(json.dumps(stats,indent=2)+'\n');print(json.dumps(stats,indent=2))
