"""Reproducible silent spatial study; all runtime sources remain untouched."""
import argparse, hashlib, json, os, shutil, subprocess, sys, time
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'tools'))
from compare_wave_field import save_json

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def box(center, half): return dict(center=list(center), half=list(half))

def prepare():
    names = []
    common = dict(speedOfSound=343, rays=[16,64,256], seeds=[17,65554,131091,196628],
                  maxBounces=8, maximumDelaySeconds=.4, fftSize=4, referenceConvention='exp(+i*w*t)')
    for count in [1,9,25]:
        side = round(np.sqrt(count)); coordinates = np.linspace(-4,4,side) if side>1 else [0.]
        walls = [box([x,y,0], [.3,.3,1]) for x in coordinates for y in coordinates]
        x,y = np.linspace(-6,6,33), np.linspace(-5.5,5.5,31)
        xx,yy = np.meshgrid(x,y); points = np.c_[xx.ravel(),yy.ravel(),np.zeros(xx.size)]
        keep = np.ones(len(points),bool)
        for w in walls: keep &= np.any(abs(points[:,:2]-w['center'][:2])>np.array(w['half'][:2])+.12,axis=1)
        config = dict(common,physicalModel='point-extruded',family=f'planar-{count}',source=[-6.5,-.4,0],walls=walls,
                      x=x.tolist(),y=y.tolist(),z=[0],gridIndices=np.flatnonzero(keep).tolist(),points=points[keep].ravel().tolist(),
                      frequencies=[125,250],sampleRate=500,meshSizes=[.7,.5],
                      fem=dict(order=4,radius=9.,thickness=3.,strength=2.),quadrature=dict(count=48,limit=35.,angle=35.))
        names.append(config['family']); path=OUT/config['family'];path.mkdir();save_json(path/'scene.json',config)
    for scale,count in [(1,4),(2,4),(2,25)]:
        side=round(np.sqrt(count));coords=np.linspace(-1.5,1.5,side)
        obstacles=[box(np.array([x,y*.65,0])*scale,np.array([.15,.15,1.5])*scale) for x in coords for y in coords]
        if count==25:
            for i,w in enumerate(obstacles):
                w['half'][2]=[.6,.9,1.5][i%3]*scale
                w['center'][2]=-1.5*scale+w['half'][2]
        x,y,z = np.linspace(-2.75,2.75,23)*scale,np.linspace(-1.75,1.75,17)*scale,np.array([-.9,0,.9])*scale
        # XY-major planes; retain indices for positional maps, no interpolated field.
        points=np.array([[a,b,c] for c in z for b in y for a in x]);keep=np.ones(len(points),bool)
        for w in obstacles:keep &= np.any(abs(points-w['center'])>np.array(w['half'])+.08*scale,axis=1)
        source=np.array([-2.4,-.4,0])*scale
        keep &= np.linalg.norm(points-source,axis=1)>.25*scale
        mats=[dict(name='resistive-enclosure',frequencies=[0],admittanceReal=[.2],admittanceImag=[0]),
              dict(name='rigid-pillars',frequencies=[0],admittanceReal=[0],admittanceImag=[0])]
        name=f'room-{scale*6}m-{count}'
        config=dict(common,physicalModel='point-room-3d',family=name,airVolumes=[box([0,0,0],np.array([3,2,1.5])*scale)],
                    obstacles=obstacles,materials=mats,boundaryMaterials={f'obstacle{i}':1 for i in range(count)},
                    source=source.tolist(),points=points[keep].ravel().tolist(),x=x.tolist(),y=y.tolist(),z=z.tolist(),
                    gridIndices=np.flatnonzero(keep).tolist(),frequencies=[62.5,125],sampleRate=250,
                    meshSizes=[.65*scale,.45*scale],order=4,scale=scale)
        names.append(name);path=OUT/name;path.mkdir();save_json(path/'scene.json',config)
    save_json(OUT/'manifest.json',dict(cases=names,gitHead=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        sources={str(p.relative_to(ROOT)):sha(p) for p in [ROOT/'tools/planar_wave.py',ROOT/'tools/room_wave.py',ROOT/'tools/edge_integral.py',ROOT/'Assets/Shaders/Transport.hlsl',ROOT/'Assets/Tests/Editor/WaveFieldMeasurement.cs']},
        scope='Stationary synthetic fields, no fitting; larger planar maps and finite 3D volumes.'))
    print('Prepared',names,flush=True)

def reference(name):
    path=OUT/name; c=json.loads((path/'scene.json').read_text());points=np.array(c['points']).reshape(-1,3)
    if c['physicalModel']=='point-extruded':
        from planar_wave import reference
        reference(path)
    else:
        from room_wave import RoomField
        for h in c['meshSizes']:
            if all((path/f'reference-{h:g}-{hz:g}.npz').exists() for hz in c['frequencies']):continue
            field=RoomField(c,h,c['order'])
            print(name,'mesh',field.stats,flush=True)
            for hz in c['frequencies']:
                stem=path/f'reference-{h:g}-{hz:g}'
                if Path(str(stem)+'.npz').exists():continue
                start=time.perf_counter();pressure=field.solve(hz)
                np.savez_compressed(str(stem)+'.npz',pressure=pressure,points=points)
                stats=dict(field.stats,hz=hz,seconds=time.perf_counter()-start,sceneSha256=sha(path/'scene.json'),solverSha256=sha(ROOT/'tools/room_wave.py'))
                save_json(Path(str(stem)+'.json'),stats);print(name,'reference',stats,flush=True)
        # A coarser tessellation of exactly the same planar surfaces keeps acoustic
        # solver mesh refinement out of GPU geometry/edge-count comparisons.
        if not (path/'renderer-scene.json').exists():
            surface=RoomField(c,2*c['scale'],1);triangles,indices=surface.surface()
            save_json(path/'renderer-scene.json',dict(c,triangles=triangles,triangleMaterials=indices))
            print(name,'renderer triangles',len(indices),flush=True)

def gpu(names):
    runner=ROOT/'.context/gpu-audio/runner'
    if (runner/'Temp/UnityLockfile').exists():raise RuntimeError('Runner open')
    hashes={}
    for folder in ['Assets/Scripts','Assets/Shaders','Assets/Resources/Acoustics','Assets/Tests/Editor/TakeChecks.cs','Assets/Tests/Editor/RayTransportChecks.cs']:
        parent=ROOT/folder
        for source in [parent] if parent.is_file() else parent.rglob('*'):
            if source.is_file() and source.suffix!='.meta':
                relative=source.relative_to(ROOT)
                if source.read_bytes()!=(runner/relative).read_bytes():raise RuntimeError(f'Runner differs: {relative}')
                hashes[str(relative)]=sha(source)
    for name in names:
        if (OUT/name/'renderer.csv').exists():raise FileExistsError(name)
    fixture=runner/'Assets/Tests/Editor/WaveFieldMeasurement.cs'
    batch=runner/'Assets/Tests/Editor/SpatialStudy.cs'
    if fixture.exists() or batch.exists():raise FileExistsError('Fixture already staged')
    text=(ROOT/'Assets/Tests/Editor/WaveFieldMeasurement.cs').read_text().replace('foreach(int diffraction in new[]{0,1})','foreach(int diffraction in new[]{1})')
    fixture.write_text(text)
    batch.write_text('''using System; using System.IO; using System.Collections.Generic; using NUnit.Framework; using UnityEngine;
public partial class TakeChecks {
 public static IEnumerable<string> SpatialCases() => File.ReadAllLines(Environment.GetEnvironmentVariable("SPATIAL_CASES"));
 [TestCaseSource(nameof(SpatialCases)), Category("QualityMeasurement")]
 public void SpatialStudy(string path) {
  Debug.Log("SPATIAL BEGIN "+path); Environment.SetEnvironmentVariable("ACOUSTIC_WAVE_OUTPUT",path);
  MeasureWaveField(); Debug.Log("SPATIAL COMPLETE "+path);
 }
}\n''')
    stamp=time.strftime('%H%M%S');casefile=OUT/f'gpu-cases-{stamp}.txt'
    casefile.write_text(''.join(str(OUT/n)+'\n' for n in names))
    save_json(OUT/f'gpu-provenance-{stamp}.json',dict(files=hashes,fixtureSha256=sha(fixture),batchSha256=sha(batch),cases={n:sha(OUT/n/'scene.json') for n in names},
              note='Original pressure measurement fixture with diffraction-on only; three computed FFT bins, no DSP.'))
    shutil.copy2(fixture,OUT/f'WaveFieldMeasurement-{stamp}.cs')
    try:
        result=subprocess.run(['nice','-n','15','/Applications/Unity/Hub/Editor/6000.4.1f1/Unity.app/Contents/MacOS/Unity',
            '-batchmode','-force-metal','-disable-audio','-job-worker-count','1','-projectPath',str(runner),'-runTests',
            '-testPlatform','EditMode','-testFilter','TakeChecks.SpatialStudy','-testResults',str(OUT/f'gpu-{stamp}.xml'),'-logFile',str(OUT/f'gpu-{stamp}.log')],
            env=dict(os.environ,SPATIAL_CASES=str(casefile)),timeout=1200)
        import xml.etree.ElementTree as ET
        test=ET.parse(OUT/f'gpu-{stamp}.xml').getroot()
        if result.returncode or test.get('result')!='Passed' or int(test.get('passed','0'))!=len(names):raise RuntimeError('GPU measurement failed')
        print('GPU measurement passed',names,flush=True)
    finally:
        for p in [fixture,batch]:p.unlink(missing_ok=True);Path(str(p)+'.meta').unlink(missing_ok=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('command',choices=['prepare','reference','gpu']);p.add_argument('names',nargs='*');a=p.parse_args()
    if a.command=='prepare':prepare()
    elif a.command=='gpu':gpu(a.names)
    else:
        for name in a.names:reference(name)
