"""Validate and summarize the unchanged-GPU sample sweep."""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import numpy as np

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
BASE = ROOT / '.context/spatial-accuracy'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return np.genfromtxt(p, delimiter=',', names=True)

manifest = json.loads((OUT / 'manifest.json').read_text())
provenance = json.loads(next(OUT.glob('gpu-provenance-*.json')).read_text())
for relative, expected in provenance['files'].items():
    assert sha(ROOT / relative) == expected, relative
xml = ET.parse(next(OUT.glob('gpu-*.xml'))).getroot()
assert xml.get('result') == 'Passed' and int(xml.get('passed')) == 3
rows = []
matched = 0
for name, case in manifest['cases'].items():
    config = json.loads((OUT / name / 'scene.json').read_text())
    assert sha(OUT / name / 'scene.json') == provenance['cases'][name]
    data = read(OUT / name / 'renderer.csv')
    old = read(BASE / name / 'renderer.csv')
    old = old[(old['diffraction'] == 1) & (old['rays'] == 256)]
    lookup = {(int(r['seed']), int(r['point']), r['hz']): r for r in old}
    indices = case['indices']
    assert len(data) == len(indices) * len(config['rays']) * len(config['seeds']) * len(config['frequencies'])
    assert np.isfinite(data.view(float)).all()
    assert np.all(data['diffraction'] == 1) and np.all(data['solve_seconds'] > 0)
    for r in data[data['rays'] == 256]:
        previous = lookup[int(r['seed']), indices[int(r['point'])], r['hz']]
        for key in ['real', 'imag', 'direct_visible']:
            assert r[key] == previous[key], (name, key, r)
        matched += 1
    for hz in config['frequencies']:
        assert sha(BASE / name / f'reference-0.35-{hz}.npz') == case['references'][str(hz)]
        reference = np.load(OUT / name / f'reference-{hz}.npz')['pressure']
        np.testing.assert_array_equal(reference, np.load(BASE / name / f'reference-0.35-{hz}.npz')['pressure'][indices])
        floor = np.sqrt(np.mean(abs(reference)**2)) * 1e-6
        for rays in config['rays']:
            scores = []
            times = []
            for seed in config['seeds']:
                selected = data[(data['rays'] == rays) & (data['seed'] == seed) & (data['hz'] == hz)]
                selected.sort(order='point')
                np.testing.assert_array_equal(selected['point'], np.arange(len(indices)))
                value = selected['real'] + 1j * selected['imag']
                db = 20 * np.log10(np.maximum(abs(value), floor) / np.maximum(abs(reference), floor))
                scores.append(dict(seed=seed,
                    complexL2=float(np.linalg.norm(value-reference)/np.linalg.norm(reference)),
                    magnitudeL2=float(np.linalg.norm(abs(value)-abs(reference))/np.linalg.norm(reference)),
                    within3dB=float(np.mean(abs(db)<=3)), medianAbsDb=float(np.median(abs(db))),
                    p95AbsDb=float(np.quantile(abs(db), .95)),
                    maximumPressureMagnitude=float(abs(value).max())))
                times.extend(selected['solve_seconds'] * 1000)
            row = dict(scene=name, hz=hz, raysPerBin=rays, probes=len(indices), perSeed=scores,
                mean={key:float(np.mean([s[key] for s in scores])) for key in scores[0] if key!='seed'},
                medianSolveMs=float(np.median(times)), p95SolveMs=float(np.quantile(times, .95)),
                pathBufferBytes=48*3*(1+rays*(config['maxBounces']+1)))
            rows.append(row)
            if hz==250:
                print(f"{name:10} {rays:6} rays  error {row['mean']['complexL2']*100:12.2f}%  within3dB {row['mean']['within3dB']*100:5.1f}%  {row['medianSolveMs']:8.3f} ms  buffer {row['pathBufferBytes']/2**20:6.2f} MiB", flush=True)
summary = dict(date='2026-10-21',manifest=manifest, matchedBaselineRows=matched,
    validation='Three measurement cases completed; all expected finite rows present; 256-ray complex values and visibility exactly reproduce previous GPU fields.',
    metrics='Relative complex L2 and amplitude metrics computed per seed then averaged; pressure fields are never seed-averaged before scoring.',
    memory='Path buffer only, per pair and response. Diagnostic holds an equally sized CPU copy. Geometry/material/driver memory excluded.',
    limitations=['Small predetermined lattice subsets, not full maps.',
        'Three computed bins, not a full-band audio timing; synchronous GPU readback included.',
        'Eight-interaction production GPU walk, not the two-order offline complete-route sampler.',
        'Four seeds, with nested ray sequences as count increases; not independent replications across budgets.',
        'Reference mesh convergence is observed, not a certified total error bound.',
        'No 3D, moving-scene, perceptual/audio-artifact or training-data qualification.'], rows=rows)
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2, allow_nan=False)+'\n')
print('Matched baseline rows:', matched)
