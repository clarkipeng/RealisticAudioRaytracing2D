"""Publish measured sample scaling, preserving raw results and exact runner inputs."""
import json
import shutil
import zipfile
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
data = json.loads((OUT / 'summary.json').read_text())
fig, axes = plt.subplots(1, 2, figsize=(12, 4.8))
for name, label, color in [('planar-1','1 box','#19679d'),('planar-9','9 boxes','#c26114'),('planar-25','25 boxes','#8e3378')]:
    rows = [r for r in data['rows'] if r['scene']==name and r['hz']==250]
    x = [r['raysPerBin'] for r in rows]
    errors = np.array([[s['complexL2']*100 for s in r['perSeed']] for r in rows])
    axes[0].plot(x, errors.mean(axis=1), '-o', color=color, label=label, linewidth=2)
    axes[0].fill_between(x, errors.min(axis=1), errors.max(axis=1), color=color, alpha=.12)
    axes[1].plot(x, [r['medianSolveMs'] for r in rows], '-o', color=color, label=label, linewidth=2)
    axes[1].plot(x, [r['p95SolveMs'] for r in rows], ':', color=color, alpha=.7)
for ax in axes:
    ax.set_xscale('log', base=4)
    ax.set_xticks(x, ['256','1,024','4,096','16,384','65,536'])
    ax.set_xlabel('Rays per frequency bin')
    ax.grid(alpha=.2)
    ax.spines[['top','right']].set_visible(False)
    ax.legend(frameon=False)
axes[0].set_yscale('log')
axes[0].set_ylabel('Relative complex-pressure error (%)')
axes[0].set_title('Accuracy at 250 Hz — lower is better')
axes[1].set_ylabel('Warm solve + path readback (ms)')
axes[1].set_title('Three computed bins — median / dotted p95')
fig.suptitle('More GPU rays do not stabilize the current diffraction walk', fontsize=14, fontweight='bold')
fig.text(.5, .035, 'M5 / Metal · 8 interactions · 0.4 s support · 33 / 32 / 32 fixed probes · four seeds\n'
    'Error line = mean per-seed error; shading = seed range. Narrow-band stationary diagnostic, not full-band audio.',
    ha='center', fontsize=9)
fig.tight_layout(rect=(0,.12,1,.93))
fig.savefig(OUT/'gpu-more-samples.png', dpi=160)
plt.close(fig)

stem = 'gpu-more-samples-2026-10-21'
dest = ROOT/'docs/benchmarks'
shutil.copy2(OUT/'summary.json', dest/f'{stem}.json')
shutil.copy2(OUT/'gpu-more-samples.png', dest/f'{stem}.png')
shutil.copy2(ROOT/'.context/spatial-accuracy/run.py', OUT/'spatial-run-snapshot.py')
with zipfile.ZipFile(dest/f'{stem}.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for file in sorted(OUT.rglob('*')):
        if file.is_file() and '__pycache__' not in file.parts:
            archive.write(file, 'gpu-more-samples/'+str(file.relative_to(OUT)))
visible = Path('/Users/clarkpeng/conductor/workspaces/realisticaudioraytracing2d/tyler/.context')
visible.mkdir(exist_ok=True)
shutil.copy2(OUT/'gpu-more-samples.png', visible/'gpu-more-samples.png')

table = []
for name in data['manifest']['cases']:
    rows = [r for r in data['rows'] if r['scene']==name and r['hz']==250]
    for r in rows:
        table.append(f"| {name.split('-')[1]} | {r['raysPerBin']:,} | {r['mean']['complexL2']*100:,.2f}% | {r['mean']['within3dB']*100:.1f}% | {r['medianSolveMs']:.3f} |")
section = f'''## More GPU samples — 2026-10-21

**Measured the unchanged production GPU walk up to 65,536 rays per frequency bin. More samples alone do not stabilize its larger-scene fields.** This is not a GPU port of the offline complete-route experiment below. No runtime code or quality defaults changed.

The existing silent Metal runner tested 256 / 1,024 / 4,096 / 16,384 / 65,536 rays, with eight interactions, 0.4 s support and four seeds. Each layout uses every third point of the pre-existing regular lattice: 33 / 32 / 32 probes, selected before this sweep. The same cached refined wave references are used. These are stationary point-source/extruded-wall planar scenes; no finite-3D or audio/artifact test is implied.

### Measured accuracy and cost

Relative complex-pressure L2 includes amplitude and phase; each seed is scored separately and errors are then averaged. Fields are not averaged before scoring. Within ±3 dB measures local amplitude agreement. The table shows 250 Hz; raw results also include 125 Hz.

| Boxes | Rays/bin | Complex error | Within ±3 dB | Median solve + readback (ms) |
|---:|---:|---:|---:|---:|
{chr(10).join(table)}

![GPU sample-count scaling](benchmarks/{stem}.png)

Timings are warm synchronous solver wall time on Apple M5 / Metal, **three computed FFT bins**, one source/listener pair, including GPU-to-CPU path-buffer readback. They exclude cold construction, CPU complex summation and audio DSP; these are neither GPU timestamp measurements nor full-band real-time costs. Four seeds and this small spatial subset cannot establish statistical convergence. Ray sequences are nested across budgets. The 256-ray complex pressure and direct visibility exactly reproduce **776 prior baseline rows**. All three measurement cases completed in 20.82 s; startup/compilation is outside that duration. Passing these cases means the measurements completed with finite values, not that acoustic accuracy passed.

### Why a larger budget is insufficient here

The one-box mean error improves from 128.44% to 39.35%, but is not monotonic; 4,096 rays gave 32.97% on these probes. The larger layouts remain severely inaccurate, including at the highest budget. This is consistent with the previously captured large inverse-probability weights on multi-edge routes. Additional rays can discover new extreme contributions. This sweep does not prove convergence, or separate every source of model bias from sampling variance.

There is also a concrete memory limit in the present path layout. Per pair and response, path storage is `48 × frequencyBins × (1 + raysPerBin × (maxBounces + 1))` bytes. At eight interactions and three bins, the five budgets use 0.32 / 1.27 / 5.06 / 20.25 / 81.00 MiB. This diagnostic holds an equally sized CPU copy. With a 1,024-point FFT (513 bins), 65,536 rays would require **13.53 GiB for the GPU path buffer alone**, before other data or additional pairs/responses. This full-band allocation was calculated, not run.

### Next implementation decision

GPU acceleration remains appropriate. The next candidate is a separately validated GPU implementation of complete-route sampling, using the CPU implementation as a numerical control and the wave solver as the physical reference. For stationary field measurements, bounded sample batches and on-GPU complex-pressure reduction would avoid storing/readback of every path. The live renderer also needs delay, direction and motion information, so a scalar-field reduction is not a drop-in replacement for its response format. The CPU prototype still has larger-scene errors and an enumerated mixed-path stage; porting it is an experiment, not a proven accuracy fix.

Keep the current quality defaults unchanged. Require a measured accuracy gain at matched time before promoting a GPU candidate; simply setting a much higher ray count is not supported by these results.

[Ledger](benchmarks/{stem}.json) · [Raw rows, reference subsets, configuration, source hashes and scripts](benchmarks/{stem}.zip). Reproduction starts from commit `db295a7` and the earlier spatial-study runner; the archive includes its exact snapshot. No visible windows, cursor capture, microphone or speaker playback were used.

'''
doc = ROOT/'docs/cleanup-results.md'
text = doc.read_text()
heading = '# Cleanup validation and measured bottlenecks\n\n'
assert text.startswith(heading)
if '## More GPU samples — 2026-10-21' not in text:
    doc.write_text(heading+section+text[len(heading):])
print('Published', stem)
