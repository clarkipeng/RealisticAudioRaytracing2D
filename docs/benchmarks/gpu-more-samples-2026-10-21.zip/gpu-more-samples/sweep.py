"""Silent sample-count sweep of the unchanged production GPU walk."""
import importlib.util
import json
import subprocess
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
BASE = ROOT / '.context/spatial-accuracy'
spec = importlib.util.spec_from_file_location('spatial', BASE / 'run.py')
study = importlib.util.module_from_spec(spec)
spec.loader.exec_module(study)
study.OUT = OUT
names = [f'planar-{n}' for n in (1, 9, 25)]
manifest = dict(gitHead=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    selection='Every third position of the pre-existing regular lattice, fixed before measuring this sweep.',
    hardware='Apple M5, 16 GiB; Unity 6000.4.1f1, Metal; silent nice-15 batch, one worker.',
    scope='Current GPU walk; not the new offline complete-route sampler. Three computed bins, one pair, eight bounces, 0.4 s support; no DSP.',
    timings='Warm synchronous Solve, including path-buffer GPU-to-CPU readback; excludes CPU complex summation and cold construction.',
    cases={})
for name in names:
    target = OUT / name
    target.mkdir(exist_ok=True)
    if (target / 'scene.json').exists():
        raise FileExistsError(target / 'scene.json')
    config = json.loads((BASE / name / 'scene.json').read_text())
    indices = np.load(BASE / name / 'prototype.npz')['indices'][::3]
    points = np.array(config['points']).reshape(-1, 3)[indices]
    config.update(points=points.ravel().tolist(), originalPoints=indices.tolist(),
                  rays=[256, 1024, 4096, 16384, 65536], decompose=False)
    study.save_json(target / 'scene.json', config)
    manifest['cases'][name] = dict(probes=len(indices), indices=indices.tolist(),
        originalSceneSha256=study.sha(BASE / name / 'scene.json'),
        references={str(hz):study.sha(BASE / name / f'reference-0.35-{hz}.npz') for hz in (125,250)})
    # Retain the exact subset of the existing reference; do not rerun the wave solver.
    for hz in (125, 250):
        reference = np.load(BASE / name / f'reference-0.35-{hz}.npz')
        np.testing.assert_array_equal(reference['points'][indices], points)
        np.savez_compressed(target / f'reference-{hz}.npz', pressure=reference['pressure'][indices], points=points)
study.save_json(OUT / 'manifest.json', manifest)
print(json.dumps(manifest, indent=2), flush=True)
study.gpu(names)
