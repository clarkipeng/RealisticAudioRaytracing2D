"""Measure complete 2D maps for the high-sample GPU comparison, silently."""
import importlib.util
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / '.context/spatial-accuracy'
OUT = Path(__file__).resolve().parent / 'full-maps'
OUT.mkdir(exist_ok=True)
spec = importlib.util.spec_from_file_location('spatial', BASE / 'run.py')
study = importlib.util.module_from_spec(spec)
spec.loader.exec_module(study)
study.OUT = OUT
names = [f'planar-{n}' for n in (1, 9, 25)]
manifest = dict(gitHead=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    scope='Full existing receiver grids, seed 17, 250 Hz, 65,536 GPU rays per bin; eight interactions, 0.4 s support. Three computed bins.',
    cases={})
for name in names:
    target = OUT / name
    target.mkdir(exist_ok=True)
    if (target / 'scene.json').exists():
        raise FileExistsError(target / 'scene.json')
    config = json.loads((BASE / name / 'scene.json').read_text())
    config.update(rays=[65536], seeds=[17], frequencies=[250], decompose=False)
    study.save_json(target / 'scene.json', config)
    manifest['cases'][name] = dict(probes=len(config['points'])//3,
        originalSceneSha256=study.sha(BASE / name / 'scene.json'),
        referenceSha256=study.sha(BASE / name / 'reference-0.35-250.npz'),
        baselineSha256=study.sha(BASE / name / 'renderer.csv'))
study.save_json(OUT / 'manifest.json', manifest)
print('Measuring full 2D maps:', manifest['cases'], flush=True)
study.gpu(names)
