"""Show measured pressure over XY space, never interpolating missing receivers."""
import hashlib
import json
import shutil
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent / 'full-maps'
BASE = ROOT / '.context/spatial-accuracy'
DEST = Path('/Users/clarkpeng/conductor/workspaces/realisticaudioraytracing2d/tyler/.context')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p): return np.genfromtxt(p, delimiter=',', names=True)
def select(data, rays):
    value = np.sort(data[(data['rays']==rays)&(data['seed']==17)&(data['hz']==250)&(data['diffraction']==1)], order='point')
    np.testing.assert_array_equal(value['point'], np.arange(len(value)))
    return value

manifest = json.loads((OUT/'manifest.json').read_text())
provenance = json.loads(next(OUT.glob('gpu-provenance-*.json')).read_text())
for relative, expected in provenance['files'].items():
    assert sha(ROOT/relative)==expected, relative
test = ET.parse(next(OUT.glob('gpu-*.xml'))).getroot()
assert test.get('result')=='Passed' and int(test.get('passed'))==3
plt.rcParams.update({'font.size':10, 'axes.titlesize':12, 'figure.facecolor':'white', 'savefig.facecolor':'white'})
fig, axes = plt.subplots(3, 3, figsize=(13, 12.5), layout='constrained')
cmap = plt.colormaps['magma'].with_extremes(over='#27c9bd', under='#050505', bad='#e5e7eb')
summary = dict(manifest=manifest, comparison='Full maps, seed 17, 250 Hz. Earlier four-seed sweep used smaller lattice subsets.',
    scope='Current production GPU walk, eight interactions; not the CPU complete-route prototype.',
    plotting='Identical -40 to +5 dB scale on every field; turquoise explicitly marks values above +5 dB. No amplitude fitting or interpolation.',
    matchedHighSampleSubsetRows=0, measurementCasesPassed=3, measurementSeconds=float(test.get('duration')), cases=[])
for row, (name, meta) in enumerate(manifest['cases'].items()):
    assert sha(BASE/name/'scene.json')==meta['originalSceneSha256']
    assert sha(BASE/name/'reference-0.35-250.npz')==meta['referenceSha256']
    assert sha(BASE/name/'renderer.csv')==meta['baselineSha256']
    assert sha(OUT/name/'scene.json')==provenance['cases'][name]
    c = json.loads((OUT/name/'scene.json').read_text())
    original = json.loads((BASE/name/'scene.json').read_text())
    assert c['points']==original['points'] and c['gridIndices']==original['gridIndices']
    refdata = np.load(BASE/name/'reference-0.35-250.npz')
    ref = refdata['pressure']
    np.testing.assert_array_equal(refdata['points'], np.array(c['points']).reshape(-1,3))
    low = select(rows(BASE/name/'renderer.csv'), 256)
    high = select(rows(OUT/name/'renderer.csv'), 65536)
    assert len(low)==len(high)==len(ref)==meta['probes']
    for value in (low, high):
        assert np.isfinite(value.view(float)).all() and np.all(value['solve_seconds']>0)
    fields = [ref, low['real']+1j*low['imag'], high['real']+1j*high['imag']]
    sparse = rows(OUT.parent/name/'renderer.csv')
    sparse = select(sparse, 65536)
    sparse_config = json.loads((OUT.parent/name/'scene.json').read_text())
    for i, idx in enumerate(sparse_config['originalPoints']):
        for key in ('real', 'imag', 'direct_visible'):
            assert sparse[i][key]==high[idx][key], (name, i, key)
        summary['matchedHighSampleSubsetRows']+=1
    np.testing.assert_array_equal(low['direct_visible'], high['direct_visible'])
    floor = np.sqrt(np.mean(abs(ref)**2))*1e-6
    levels = [20*np.log10(np.maximum(abs(v), floor)) for v in fields]
    case = dict(scene=name, probes=len(ref), fields=[])
    for col, (field, level) in enumerate(zip(fields, levels)):
        error = level-levels[0]
        metrics = dict(method=['wave-reference','gpu-256','gpu-65536'][col],
            complexL2=float(np.linalg.norm(field-ref)/np.linalg.norm(ref)),
            within3dB=float(np.mean(abs(error)<=3)),
            maximumLevelDb=float(level.max()), minimumLevelDb=float(level.min()),
            fractionAboveScale=float(np.mean(level>5)))
        if col:
            metrics['medianSolveMs']=float(np.median([low,high][col-1]['solve_seconds'])*1000)
            metrics['p95SolveMs']=float(np.quantile([low,high][col-1]['solve_seconds'],.95)*1000)
        case['fields'].append(metrics)
        ax = axes[row,col]
        grid = np.full(len(c['x'])*len(c['y']), np.nan)
        grid[c['gridIndices']] = level
        im = ax.pcolormesh(c['x'], c['y'], grid.reshape(len(c['y']),len(c['x'])),
            shading='nearest', cmap=cmap, vmin=-40, vmax=5, rasterized=True)
        for wall in c['walls']:
            center, half = np.array(wall['center'][:2]), np.array(wall['half'][:2])
            ax.add_patch(Rectangle(center-half, *(2*half), facecolor='#515962', edgecolor='white', linewidth=.6))
        ax.scatter(*c['source'][:2], marker='*', s=125, color='#00a8ff', edgecolor='black', linewidth=.6, zorder=5)
        ax.set(xlim=(-6.9,6.25), ylim=(-5.7,5.7), xlabel='x (m)', ylabel='y (m)')
        ax.set_aspect('equal')
        count = len(c['walls'])
        ax.set_title(f"{count} {'box' if count==1 else 'boxes'} · "+['Wave reference','GPU · 256 rays/bin','GPU · 65,536 rays/bin'][col])
        annotation = f"Peak {level.max():+.1f} dB"
        if col:
            annotation += f" · {100*metrics['within3dB']:.1f}% within ±3 dB"
        ax.text(.025,.025,annotation,transform=ax.transAxes, fontsize=8.5,
                bbox=dict(facecolor='white',alpha=.92,edgecolor='none',pad=3))
    colorbar = fig.colorbar(im, ax=list(axes[row]), shrink=.77, pad=.02, extend='both')
    colorbar.set_label('Pressure level (dB re unit pressure)')
    summary['cases'].append(case)
    np.savez_compressed(OUT/name/'comparison.npz', pressure=np.array(fields), points=refdata['points'])
fig.suptitle('2D spatial pressure maps · 250 Hz\nWave reference vs current GPU renderer · same scale, same source, seed 17', fontsize=16)
fig.supxlabel('Blue star: sound source · Grey blocks: solid obstacles · Turquoise: above +5 dB\n'
    'Each coloured cell is a measured receiver position; light-grey gaps near obstacles were not sampled.',fontsize=10)
figure = OUT/'gpu-full-2d-maps.png'
fig.savefig(figure,dpi=155)
plt.close(fig)
(OUT/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
shutil.copy2(figure, DEST/figure.name)
for case in summary['cases']:
    print(case['scene'],[(f['method'],round(f['complexL2']*100,2),round(f['within3dB']*100,1)) for f in case['fields']],flush=True)
print('Matched prior high-sample measurements:',summary['matchedHighSampleSubsetRows'])
