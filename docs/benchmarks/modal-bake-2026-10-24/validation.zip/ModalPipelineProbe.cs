using System;
using System.IO;
using NUnit.Framework;
using UnityEngine;

public class ModalPipelineProbe
{
    const string Root="/Users/clarkpeng/UnityGames/realisticaudioraytracing2d/.context/modal-bake/";
    [Serializable] public class Output { public double[] displacement,velocity; }
    [Test,Category("Core")]
    public void PythonBakeLoadsAndProducesMechanicalResponseInUnity()
    {
        var bank=new ModalBody.Bank(File.ReadAllText(Root+"panel-runtime.json"));
        var readout=new double[bank.ModeCount];bank.Couple(100,new Vector3(.25f,.25f,.5f),Vector3.forward,readout);
        var impacts=new ModalBody.Impact[3];
        for(int i=0;i<3;i++) impacts[i]=new ModalBody.Impact {sample=new[]{13,33,129}[i],triangle=100,
            barycentric=new Vector3(.25f,.25f,.5f),impulse=Vector3.forward*.001f};
        var state=new ModalBody(bank,48000);var output=new Output {displacement=new double[2000],velocity=new double[2000]};
        state.Render(2000,impacts,readout,output.displacement,output.velocity);
        Assert.That(output.velocity[13],Is.GreaterThan(0));
        File.WriteAllText(Root+"unity-response.json",JsonUtility.ToJson(output));
        var target=GameObject.CreatePrimitive(PrimitiveType.Cube);var mat=ScriptableObject.CreateInstance<AudioMaterial>();
        try
        {
            target.AddComponent<AcousticSurface>().material=mat;
            target.transform.localScale=new Vector3(.4f,.25f,.1f);target.transform.rotation=Quaternion.Euler(10,20,30);
            File.WriteAllText(Root+"unity-box.json",JsonUtility.ToJson(ModalBakeEditor.Describe(target,true),true)+"\n");
            File.WriteAllText(Root+"unity-mesh.json",JsonUtility.ToJson(ModalBakeEditor.Describe(target,false),true)+"\n");
        }
        finally {UnityEngine.Object.DestroyImmediate(target);UnityEngine.Object.DestroyImmediate(mat);}
    }
}
