"""Run from the repository root with numpy, scipy and ngsolve installed."""
import json
from pathlib import Path
import sys

import numpy as np
sys.path.insert(0, str(Path.cwd()/'tools'))
import modal_bake as m

source = Path(__file__).resolve().parent
output = Path(sys.argv[1])
output.mkdir(parents=True, exist_ok=False)
reports = {}
for name, geometry, h in [('solid-coarse', 'beveled', .045), ('solid-fine', 'beveled', .035),
                          ('proxy-coarse', 'fitted', .045), ('proxy-fine', 'fitted', .035)]:
    reports[name] = m.bake(m.read_spec(source/(geometry+'.json')), output/(name+'.npz'), 12, 50000, h, 3)
    print(name, reports[name]['seconds'], flush=True)
for name, reference, candidate in [('meshRefinement', 'solid-fine', 'solid-coarse'),
                                  ('proxyRefinement', 'proxy-fine', 'proxy-coarse'),
                                  ('approximation', 'solid-fine', 'proxy-fine')]:
    reports[name] = m.compare(m.read_bank(output/(reference+'.npz')), m.read_bank(output/(candidate+'.npz')))
m.bake(m.read_spec(source/'panel.json'), output/'panel.npz', 12, 12000)
bank = m.read_bank(output/'panel.npz')
point = dict(triangle=100, barycentric=[.25, .25, .5], direction=[0, 0, 1])
impacts = [dict(point, sample=sample, impulse=float(np.float32(.001))) for sample in (13, 33, 129)]
response = m.Resonator(bank, 48000).render(2000, impacts, m.coupling(bank, **point))
unity = json.loads((source/'unity-response.json').read_text())
reference = np.column_stack((unity['displacement'], unity['velocity']))
reports['pythonUnityRelativeDifference'] = float(np.linalg.norm(response-reference)/np.linalg.norm(reference))
m.save_json(output/'results.json', reports)
print(json.dumps({key: reports[key]['maxAbsoluteRelativeError'] for key in
                  ('meshRefinement', 'proxyRefinement', 'approximation')}, indent=2))
print('Python/Unity relative difference:', reports['pythonUnityRelativeDifference'])
