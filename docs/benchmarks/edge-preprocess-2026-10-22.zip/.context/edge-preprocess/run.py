import hashlib,json,os,shutil,subprocess,sys,time,uuid
from pathlib import Path
import xml.etree.ElementTree as ET
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];RUNNER=ROOT/'.context/gpu-audio/runner'
assert not (RUNNER/'Temp/UnityLockfile').exists()
fields='--fields' in sys.argv;merged='--merged' in sys.argv;variant='merged' if merged else 'baseline';assert not (OUT/((('fields-' if fields else '')+variant)+'.csv')).exists()
fixture=OUT/'EdgePreprocessChecks.cs';target=RUNNER/'Assets/Tests/Editor'/fixture.name;assert not target.exists()
source=RUNNER/'Assets/Scripts/Simulation/RayTransport.cs';original=source.read_bytes();assert original==(OUT/'RayTransport.before.cs').read_bytes()
changed=(OUT/('RayTransport.merged.cs' if merged else 'RayTransport.before.cs')).read_bytes();stamp=time.strftime('%H%M%S')
(OUT/f'provenance-{stamp}.json').write_text(json.dumps(dict(baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),variant=variant,fixture=hashlib.sha256(fixture.read_bytes()).hexdigest(),source=hashlib.sha256(changed).hexdigest()),indent=2)+'\n')
shutil.copy2(fixture,target);target.with_name(target.name+'.meta').write_text('fileFormatVersion: 2\nguid: '+uuid.uuid4().hex+'\n')
try:
 source.write_bytes(changed)
 cmd=['nice','-n','15','/Applications/Unity/Hub/Editor/6000.4.1f1/Unity.app/Contents/MacOS/Unity','-batchmode','-force-metal','-disable-audio','-job-worker-count','1','-projectPath',str(RUNNER),'-runTests','-testPlatform','EditMode','-testFilter','TakeChecks.MeasureEdgePreprocessingFields' if fields else 'TakeChecks.MeasureEdgePreprocessing','-testResults',str(OUT/f'gpu-{stamp}.xml'),'-logFile',str(OUT/f'gpu-{stamp}.log')]
 result=subprocess.run(cmd,env=dict(os.environ,ACOUSTIC_EDGE_OUTPUT=str(OUT),ACOUSTIC_EDGE_MERGED=str(int(merged))),timeout=300)
 t=ET.parse(OUT/f'gpu-{stamp}.xml').getroot();print(t.attrib,flush=True);assert result.returncode==0 and t.get('result')=='Passed'
finally:
 source.write_bytes(original);target.unlink(missing_ok=True);target.with_name(target.name+'.meta').unlink(missing_ok=True)
