from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1]
source=(ROOT/'Assets/Scripts/Simulation/RayTransport.cs').read_text()
(OUT/'RayTransport.before.cs').write_text(source)
source=source.replace('var edges = Edges(geometry, planar, materials, bins, volumes);','var originalEdges = Edges(geometry, planar, materials, bins, volumes);\n            var edges = MergeEdges(originalEdges, geometry, out var remap);')
source=source.replace('for (int i = 0; i < edges.Length; i++)\n            {\n                adjacency[edges[i].firstFace].Add(i);\n                if (edges[i].secondFace != edges[i].firstFace)\n                    adjacency[edges[i].secondFace].Add(i);\n            }','for (int i = 0; i < originalEdges.Length; i++)\n            {\n                var edge=originalEdges[i]; int id=remap[i];\n                if(!adjacency[edge.firstFace].Contains(id))adjacency[edge.firstFace].Add(id);\n                if(edge.secondFace!=edge.firstFace && !adjacency[edge.secondFace].Contains(id))adjacency[edge.secondFace].Add(id);\n            }')
method='''    // Conservative topology-only merge: same owner, wedge and material pair;
    // exactly collinear segments meet at a degree-two endpoint. Keep all face links.
    static Edge[] MergeEdges(Edge[] original, AcousticTake.Primitive[] geometry, out int[] remap)
    {
        var edges=(Edge[])original.Clone();var parent=new int[edges.Length];
        var ends=new Dictionary<(uint,Vector3),(int first,int second,int count)>();
        void Add(uint owner,Vector3 position,int id)
        {
            var key=(owner,position);
            if(ends.TryGetValue(key,out var v))ends[key]=(v.first,id,v.count+1);
            else ends.Add(key,(id,id,1));
        }
        for(int i=0;i<edges.Length;i++)
        {
            parent[i]=i;var e=edges[i];if(e.a.Equals(e.b))continue;
            Add(e.owner,e.a,i);Add(e.owner,e.b,i);
        }
        for(int i=0;i<edges.Length;i++)
        {
            int root=parent[i];var a=edges[root];if(a.a.Equals(a.b))continue;
            var end=ends[(a.owner,a.b)];if(end.count!=2)continue;
            int j=end.first==i?end.second:end.first;if(j<=i)continue;
            var b=edges[j];
            if(!a.b.Equals(b.a)||!a.face.Equals(b.face)||!a.normal.Equals(b.normal)||
                (a.firstFace==a.secondFace)!=(b.firstFace==b.secondFace)||
                geometry[a.firstFace].materialIndex!=geometry[b.firstFace].materialIndex||
                geometry[a.secondFace].materialIndex!=geometry[b.secondFace].materialIndex||
                Vector3.Cross((Vector3)(a.b-a.a),(Vector3)(b.b-b.a)).sqrMagnitude!=0)continue;
            a.b=b.b;edges[root]=a;parent[j]=root;
        }
        var result=new List<Edge>();remap=new int[edges.Length];
        for(int i=0;i<edges.Length;i++)
            if(parent[i]==i){remap[i]=result.Count;result.Add(edges[i]);}
            else remap[i]=remap[parent[i]];
        return result.ToArray();
    }
'''
source=source.replace('    public void Dispatch(int frames, bool asynchronous)\n',method+'    public void Dispatch(int frames, bool asynchronous)\n')
(OUT/'RayTransport.merged.cs').write_text(source)
print('Prepared conservative edge-chain experiment; production remains unchanged')
