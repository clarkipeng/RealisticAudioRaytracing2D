# Conservative acoustic edge merging — offline experiment

Base commit 47e4fd7. Production code is unchanged. The candidate is stored as RayTransport.merged.cs; the before file exactly matches production at the checkpoint. It merges exactly collinear degree-two chains only when owner, wedge frame, thin/solid status and ordered material pair agree. It preserves every original triangle-to-edge link after remapping and deduplication. It does not move triangles, close gaps, merge material changes or decimate the surface mesh. Exact float equality intentionally leaves uncertain cases unmerged.

The fixture recursively subdivides finite cube and sheet faces using exact dyadic midpoints. Five shapes × five levels cover a cube, material breaks, a sheet, separate sheets with a 0.03125 m gap, and a bent sheet. At the highest subdivision level, 192 cube edge segments become 12. Separate fields compare the same finite cube at 12/3072 triangles, with and without edge merging, at 1024/16384 rays per bin. Two interactions; bins 0/250/500 Hz; 0.1-second horizon. Seed 17 evaluates 195 XY positions at z=0; seeds 29/71/113 repeat a fixed 25-position subset. These nearby RNG offsets overlap ray sequences, so their variation is NOT independent Monte Carlo uncertainty. All raw values remain available.

Maps are same-sampler comparisons, not wave-reference accuracy. The logged DC point uses the existing independently integrated finite-cube second-order EDtoolbox value from the production test (0.160990476380), but this run does not establish convergence or general physical accuracy. Existing geometric triangle-based reflection and local-edge proposals remain sensitive to surface tessellation.

Result: edge storage falls, but speed gains are inconsistent and merging does not recover the simple cube's low-noise behavior. Keep this as an experiment; do not ship an extra preprocessing path on this evidence alone. A coherent acoustic proxy that reduces redundant surface tessellation and preserves physical boundaries is the more useful next target. Visual meshes can remain detailed without altering the acoustic proxy.

Reproduce from the base checkout with a matching isolated Unity project at .context/gpu-audio/runner. Unity path is pinned in run.py to 6000.4.1f1. Use only one runner process, nice15, -batchmode -force-metal -disable-audio -job-worker-count 1. The script snapshots/restores the runner source and temporarily stages the fixture. Preserve old CSVs elsewhere before rerunning because overwrite is refused:

python .context/edge-preprocess/run.py
python .context/edge-preprocess/run.py --merged
python .context/edge-preprocess/run.py --fields
python .context/edge-preprocess/run.py --merged --fields
python .context/edge-preprocess/analyze.py

Analysis uses NumPy/matplotlib; constrain OPENBLAS_NUM_THREADS, VECLIB_MAXIMUM_THREADS and OMP_NUM_THREADS to 1. plots.py is not separate; analyze.py saves the figure and copies it to the original Conductor .context path (adjust that path elsewhere). prepare.py creates explicit source variants but is not needed for replay from archived snapshots. EdgePreprocessChecks.initial.cs is the exact fixture for the first topology runs; current fixture adds the map run. Provenance hashes distinguish them. Test XMLs report 1 passing measurement case each, not hundreds of independent test cases. Logs include compiler warnings. No audio or scene UI was launched.
