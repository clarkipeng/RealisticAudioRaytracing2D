using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using NUnit.Framework;
using UnityEngine;
public partial class TakeChecks
{
    static AcousticTake.Primitive[] Tessellate(AcousticTake.Primitive[] input,int levels)
    {
        for(int level=0;level<levels;level++)
        {
            var result=new List<AcousticTake.Primitive>();
            foreach(var p in input)
            {
                var ab=(p.a+p.b)*.5f;var bc=(p.b+p.c)*.5f;var ca=(p.c+p.a)*.5f;
                void Add(Vector3 a,Vector3 b,Vector3 c){var t=p;t.a=a;t.b=b;t.c=c;result.Add(t);}
                Add(p.a,ab,ca);Add(ab,p.b,bc);Add(ca,bc,p.c);Add(ab,bc,ca);
            }
            input=result.ToArray();
        }
        return input;
    }
    static int DiffractionEdges(TransportSolver solver)
    {
        const BindingFlags flags=BindingFlags.Instance|BindingFlags.NonPublic;
        var transport=typeof(TransportSolver).GetField("transport",flags).GetValue(solver);
        return ((ComputeBuffer)typeof(RayTransport).GetField("edgeBuffer",flags).GetValue(transport)).count;
    }
    [Test,Category("QualityMeasurement")]
    public void MeasureEdgePreprocessing()
    {
        string output=Environment.GetEnvironmentVariable("ACOUSTIC_EDGE_OUTPUT");if(string.IsNullOrEmpty(output))Assert.Ignore();
        Assert.That(Application.isBatchMode,Is.True);AudioListener.volume=0;
        bool merged=Environment.GetEnvironmentVariable("ACOUSTIC_EDGE_MERGED")=="1";
        string variant=merged?"merged":"baseline";using var csv=new StreamWriter(Path.Combine(output,variant+".csv"));
        csv.WriteLine("shape,level,triangles,edges,rays,seed,point,x,y,real,imag,setup_seconds,solve_seconds,gpu_bytes");
        var shader=RequireGpu();var scene=Scene(2);scene.listeners=new[]{1};
        scene.materials=new[]{new AcousticTake.MaterialDefinition {frequencies=new[]{0f},absorption=new[]{0f},transmission=new[]{0f}},new AcousticTake.MaterialDefinition {frequencies=new[]{0f},absorption=new[]{.5f},transmission=new[]{0f}}};
        var state=States(2);state[0].position=Vector3.left*3;state[2].position=Vector3.zero;state[2].flags=AcousticTake.StateFlags.Active|AcousticTake.StateFlags.Geometry;
        foreach(string shape in new[]{"box","materials","sheet","gap","bent"})foreach(int level in new[]{0,1,2,3,4})
        {
            var coarse=TransportBox(scene.dimension,2,0,1);
            if(shape=="sheet"||shape=="gap"||shape=="bent")
            {
                var parts=new List<AcousticTake.Primitive>();
                void Quad(float y0,float y1,float dx){var a=new Vector3(0,y0,-1);var b=new Vector3(0,y0,1);var c=new Vector3(dx,y1,1);var d=new Vector3(dx,y1,-1);parts.Add(new AcousticTake.Primitive {objectIndex=2,a=a,b=b,c=c});parts.Add(new AcousticTake.Primitive {objectIndex=2,a=a,b=c,c=d});}
                if(shape=="sheet")Quad(-1,1,0);else {Quad(-1,0,0);Quad(shape=="gap"?.03125f:0,1,shape=="bent"?.25f:0);}
                coarse=parts.ToArray();
            }
            var geometry=Tessellate(coarse,level);
            if(shape=="materials")for(int i=0;i<geometry.Length;i++){var p=geometry[i];p.materialIndex=(p.a.z+p.b.z+p.c.z)>0?1:0;geometry[i]=p;}
            scene.objects[2].primitiveCount=geometry.Length;
            var settings=EdgeSettings();settings.useBvh=true;settings.fftSize=4;settings.spectralHop=2;settings.raysPerBin=1024;settings.maxBounces=2;settings.maximumDelaySeconds=.1f;settings.seed=17;
            long start=Stopwatch.GetTimestamp();using var solver=new TransportSolver(scene,geometry,settings,shader,sampleRate:1000);double setup=TakeRender.Elapsed(start);int edges=DiffractionEdges(solver);
            if(merged && shape=="box")Assert.That(edges,Is.EqualTo(12),"Tessellation must not split the cube's 12 physical wedges.");
            if(merged && shape=="sheet")Assert.That(edges,Is.EqualTo(4),"Sheet boundary preserves four sides.");
            if(merged && shape=="gap")Assert.That(edges,Is.EqualTo(8),"Do not close physical gaps.");
            if(merged && shape=="bent")Assert.That(edges,Is.EqualTo(7),"Retain the bend and its junctions.");
            if(merged && shape=="materials" && level>0)Assert.That(edges,Is.EqualTo(16),"Retain the four material breaks along vertical wedges.");
            var direct=new TakeRender.DirectPath[1];state[1].position=Vector3.right*3;solver.Solve(state,direct);
            for(int point=0;point<9;point++)
            {
                state[1].position=new Vector3(3,-2+point*.5f,0);start=Stopwatch.GetTimestamp();solver.Solve(state,direct);double seconds=TakeRender.Elapsed(start);var p=EdgeResponse(solver.RayPaths,1,250);
                Assert.That(double.IsFinite(p.Real)&&double.IsFinite(p.Imaginary),Is.True);
                csv.WriteLine(FormattableString.Invariant($"{shape},{level},{geometry.Length},{edges},1024,17,{point},{state[1].position.x:R},{state[1].position.y:R},{p.Real:R},{p.Imaginary:R},{setup:R},{seconds:R},{solver.GpuBufferBytes}"));
            }
            csv.Flush();UnityEngine.Debug.Log($"Edge preprocessing {variant} {shape} level={level} edges={edges}");
        }
    }
}
