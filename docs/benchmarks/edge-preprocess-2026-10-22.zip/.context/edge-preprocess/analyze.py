import json,re
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];DOC=ROOT/'docs/benchmarks'
def read(name):return np.genfromtxt(OUT/name,delimiter=',',names=True,dtype=None,encoding='utf8')
def field(x):return x['real']+1j*x['imag']
a=read('baseline.csv');b=read('merged.csv');topology=[]
for shape in np.unique(a['shape']):
 for level in range(5):
  x=a[(a['shape']==shape)&(a['level']==level)];y=b[(b['shape']==shape)&(b['level']==level)]
  topology.append(dict(shape=shape,level=level,triangles=int(x['triangles'][0]),oldEdges=int(x['edges'][0]),newEdges=int(y['edges'][0]),oldGpuBytes=int(x['gpu_bytes'][0]),newGpuBytes=int(y['gpu_bytes'][0]),oldSetupMs=float(x['setup_seconds'][0]*1000),newSetupMs=float(y['setup_seconds'][0]*1000),oldQueryMedianMs=float(np.median(x['solve_seconds'])*1000),newQueryMedianMs=float(np.median(y['solve_seconds'])*1000)))
a=read('fields-baseline.csv');b=read('fields-merged.csv');measurements=[]
for n in (1024,16384):
 coarse=a[(a['level']==0)&(a['rays']==n)&(a['seed']==17)];old=a[(a['level']==4)&(a['rays']==n)&(a['seed']==17)];new=b[(b['level']==4)&(b['rays']==n)&(b['seed']==17)]
 np.testing.assert_array_equal(field(coarse),field(b[(b['level']==0)&(b['rays']==n)&(b['seed']==17)]))
 q=dict(rays=n,points=len(coarse))
 for name,x in (('coarse',coarse),('split',old),('merged',new)):
  q[name]=dict(medianQueryMs=float(np.median(x['solve_seconds'])*1000),mapQuerySeconds=float(x['solve_seconds'].sum()),relativeDifferenceFromCoarse=float(np.linalg.norm(field(x)-field(coarse))/np.linalg.norm(field(coarse))))
 for label,data,level in (('coarse',a,0),('split',a,4),('merged',b,4)):
  subsets=[data[(data['level']==level)&(data['rays']==n)&(data['seed']==seed)&(data['point']%8==0)] for seed in (17,29,71,113)]
  for x in subsets[1:]:np.testing.assert_array_equal(subsets[0]['point'],x['point'])
  values=np.array([field(x) for x in subsets]);mean=values.mean(axis=0)
  q[label]['seedVariationRelativeToOwnMean']=float(np.linalg.norm(values-mean)/np.sqrt(len(values))/np.linalg.norm(mean));q[label]['subsetPoints']=len(mean)
 measurements.append(q)
 print(json.dumps(q,indent=2))
dc=[]
for p in OUT.glob('gpu-*.log'):
 for match in re.finditer(r'Finite cube DC (baseline|merged) level=(\d+) rays=(\d+) seed=(\d+): ([^;]+); reference=([\d.]+)',p.read_text()):
  variant,level,rays,seed,value,ref=match.groups();dc.append(dict(variant=variant,level=int(level),rays=int(rays),seed=int(seed),value=float(value),reference=float(ref)))
summary=dict(topology=topology,fields=measurements,dcControl=dc,decision='Keep offline: edge-count reduction works but clear speed/variance benefit and general mesh acoustic accuracy are not established.')
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
fig,axes=plt.subplots(2,3,figsize=(12,8),layout='constrained');cmap=plt.colormaps['magma'].with_extremes(over='#27c9bd',bad='#dddddd')
for row,n in enumerate((1024,16384)):
 for col,(name,data,level) in enumerate((('12-triangle cube',a,0),('3,072 triangles / 192 edge segments',a,4),('Same 3,072 triangles / 12 merged edges',b,4))):
  x=data[(data['level']==level)&(data['rays']==n)&(data['seed']==17)];xs=np.arange(-4,4.1,.5);ys=np.arange(-3,3.1,.5);grid=np.full((len(ys),len(xs)),np.nan)
  grid[np.searchsorted(ys,x['y']),np.searchsorted(xs,x['x'])]=20*np.log10(np.maximum(abs(field(x)),1e-20));ax=axes[row,col];im=ax.pcolormesh(xs,ys,grid,vmin=-40,vmax=5,cmap=cmap,shading='nearest');ax.add_patch(Rectangle((-1,-1),2,2,color='#444b56'));ax.scatter(-3,0,marker='*',s=75,c='#00b7ff',edgecolor='black',linewidth=.4);ax.set(title=f'{name}\n{n:,} rays/bin',xlabel='x (m)',ylabel='y (m)',aspect='equal')
fig.colorbar(im,ax=axes.ravel().tolist(),label='Pressure (dB re unit)',extend='both',shrink=.8);fig.suptitle('Same finite cube; only triangulation / edge segmentation changes · 250 Hz',fontsize=14);fig.supxlabel('Actual XY receiver samples at z=0, seed 17, two interactions. Same absolute scale; no smoothing or amplitude fitting.\nThese are comparisons within the older 3D sampler, NOT wave-reference accuracy or proof of realism.',fontsize=10)
name='edge-preprocess-fields-2026-10-22.png';fig.savefig(DOC/name,dpi=145);plt.close(fig)
import shutil
shutil.copy2(DOC/name,Path('/Users/clarkpeng/conductor/workspaces/realisticaudioraytracing2d/tyler/.context')/name)
print('Topology at level4',json.dumps([x for x in topology if x['level']==4],indent=2))
