import hashlib,json,zipfile
from pathlib import Path
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'.context/edge-preprocess';DOC=ROOT/'docs/benchmarks'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert (ROOT/'Assets/Scripts/Simulation/RayTransport.cs').read_bytes()==(OUT/'RayTransport.before.cs').read_bytes()
s=json.loads((OUT/'summary.json').read_text());tests=[]
for p in sorted(OUT.glob('gpu-*.xml')):
 t=ET.parse(p).getroot();assert t.get('result')=='Passed';tests.append(dict(file=p.name,passed=int(t.get('passed')),seconds=float(t.get('duration'))))
sourcehashes={sha(p) for p in OUT.glob('*.cs')}
for p in OUT.glob('provenance-*.json'):
 v=json.loads(p.read_text());assert v['source'] in sourcehashes and v['fixture'] in sourcehashes
ledger=dict(date='2026-10-22',baseCommit='47e4fd7',status='offline experiment, not applied to production',hardware='Apple M5 / Unity 6000.4.1f1 / Metal / silent batch, nice15, one worker',settings=dict(sampleRate=1000,fftSize=4,frequencyBins=[0,250,500],bounces=2,horizonSeconds=.1,raysPerBin=[1024,16384],seeds=[17,29,71,113]),limitations=['Comparison against same sampler on unsplit geometry is not independent wave accuracy.','Reported seed variation uses nearby RNG offsets whose ray sequences overlap; not independent replicates or confidence bounds.','Timing includes path readback and CPU double-precision pressure sum is outside solve timing. One map pass per variant; sequential stages on shared hardware.','One finite cube pressure map; topology controls also cover sheets, gaps, bends and material breaks. Arbitrary imported meshes unvalidated.','No runtime changes applied; exact-equality merging conservatively skips nonidentical local wedge representations.'],tests=tests,measurements=s)
archive=DOC/'edge-preprocess-2026-10-22.zip';paths=[p for p in OUT.rglob('*') if p.is_file() and '__pycache__' not in p.parts]+[DOC/'edge-preprocess-fields-2026-10-22.png'];manifest={str(p.relative_to(ROOT)):sha(p) for p in sorted(paths)}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(paths):z.write(p,str(p.relative_to(ROOT)))
 z.writestr('manifest.sha256.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,h in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==h
ledger['archive']=dict(file=archive.name,sha256=sha(archive),bytes=archive.stat().st_size)
(DOC/'edge-preprocess-2026-10-22.json').write_text(json.dumps(ledger,indent=2)+'\n')
print('Verified',len(manifest),'archive members;',archive.stat().st_size,'bytes')
