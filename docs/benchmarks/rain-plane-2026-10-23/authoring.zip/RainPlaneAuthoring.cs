using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

// One-off, silent asset authoring and integration evidence; not production code.
public static class RainPlaneAuthoring
{
    const string Output="/Users/clarkpeng/UnityGames/realisticaudioraytracing2d/.context/rain-plane";
    const string Mask="Assets/External/Church/RainMask.png";
    [Serializable] sealed class Evidence
    {
        public int registeredSources,autostartSources,triangles,colliders,spatialSamples,emittingSamples;
        public bool legacyV4Opened,compactRigMatches,guardRejectsMutation,settingsPreserved;
        public Vector4[] samples;
        public string maskSha256;
        public TakeRender.Report render;
    }
    public static void BuildAndVerify()
    {
        if(!Application.isBatchMode || Application.isPlaying)throw new Exception("Silent batch only");
        EditorSceneManager.OpenScene("Assets/Scenes/Church.unity");
        var session=UnityEngine.Object.FindAnyObjectByType<SceneSession>();var manager=session.manager;
        int originalColliders=UnityEngine.Object.FindObjectsByType<Collider>(FindObjectsInactive.Include,FindObjectsSortMode.None).Length;
        string originalSettings=EditorJsonUtility.ToJson(manager.directSettings);
        var weather=manager.takeRoot.Find("Weather");
        var rain=weather.Find("Rain courtyard").GetComponent<RaytracedAudioSource>();
        var garden=weather.Find("Rain east garden").GetComponent<RaytracedAudioSource>();
        session.startSounds=session.startSounds.Where(s=>s!=garden).ToArray();
        manager.takeSources.Remove(garden);manager.takeObjects.RemoveAll(b=>b.transform==garden.transform);
        UnityEngine.Object.DestroyImmediate(garden.gameObject);
        rain.name="Rain ground";rain.gain=.04f;rain.transform.position=new Vector3(0,1.06f,-7);
        var plane=rain.gameObject.AddComponent<AudioSourcePlane>();plane.size=new Vector2(58,86);plane.samples=8;
        Physics.SyncTransforms();
        var texture=new Texture2D(128,192,TextureFormat.RGB24,false,true);var colors=new Color[texture.width*texture.height];
        for(int y=0;y<texture.height;y++)for(int x=0;x<texture.width;x++)
        {
            var position=rain.transform.position+new Vector3(((x+.5f)/texture.width-.5f)*plane.size.x,0,((y+.5f)/texture.height-.5f)*plane.size.y);
            bool covered=Physics.RaycastAll(new Vector3(position.x,80,position.z),Vector3.down,80,~0,QueryTriggerInteraction.Ignore)
                .Any(h=>!(h.collider is CharacterController) && h.point.y>position.y+.1f);
            colors[y*texture.width+x]=covered?Color.black:Color.white;
        }
        texture.SetPixels(colors);texture.Apply();File.WriteAllBytes(Mask,texture.EncodeToPNG());UnityEngine.Object.DestroyImmediate(texture);
        AssetDatabase.ImportAsset(Mask,ImportAssetOptions.ForceSynchronousImport);
        var importer=(TextureImporter)AssetImporter.GetAtPath(Mask);importer.textureType=TextureImporterType.Default;
        importer.isReadable=true;importer.sRGBTexture=false;importer.mipmapEnabled=false;importer.npotScale=TextureImporterNPOTScale.None;
        importer.textureCompression=TextureImporterCompression.Uncompressed;importer.wrapMode=TextureWrapMode.Clamp;importer.filterMode=FilterMode.Point;
        importer.SaveAndReimport();plane.mask=AssetDatabase.LoadAssetAtPath<Texture2D>(Mask);
        manager.RegisterTakeObjects();EditorUtility.SetDirty(manager);EditorUtility.SetDirty(session);
        EditorSceneManager.SaveScene(session.gameObject.scene);AssetDatabase.SaveAssets();

        var result=new Evidence{registeredSources=manager.takeSources.Count,autostartSources=session.startSounds.Length,
            colliders=UnityEngine.Object.FindObjectsByType<Collider>(FindObjectsInactive.Include,FindObjectsSortMode.None).Length,
            maskSha256=AcousticTake.HashFile(Mask)};
        if(result.registeredSources!=8 || result.autostartSources!=4 || result.colliders!=originalColliders)
            throw new Exception("Unexpected scene registry or geometry change: "+JsonUtility.ToJson(result));
        var sources=manager.takeSources.Select(s=>s.transform).ToArray();var clips=manager.takeSources.Select(s=>s.streamed?null:s.clip).ToArray();
        var listeners=manager.takeListeners.ToArray();
        var scene=SceneToTake.Compile(manager.takeObjects,manager.takeDimension,manager.takeCurveTolerance,manager.takeDefaultMaterial,sources,clips,listeners,out var geometry);
        result.triangles=geometry.Length;if(result.triangles!=17321 || scene.planes.Length!=1)throw new Exception("Scene extraction mismatch");
        using(var rig=new SceneReplay.Rig(session))
        {
            var copied=SceneToTake.Compile(rig.bindings,manager.takeDimension,manager.takeCurveTolerance,manager.takeDefaultMaterial,
                sources.Select(s=>rig.copies[s]).ToArray(),clips,listeners.Select(l=>rig.copies[l]).ToArray(),out var copiedGeometry);
            // Non-plane streamed source components are represented by the original replay metadata.
            for(int i=0;i<scene.sources.Length;i++)copied.sources[i].mutedListenerPlusOne=scene.sources[i].mutedListenerPlusOne;
            result.compactRigMatches=AcousticTake.SceneHash(scene,5)==AcousticTake.SceneHash(copied,5) && copiedGeometry.Length==geometry.Length;
            if(!result.compactRigMatches)throw new Exception("Compact replay lost source shape");
        }
        var guard=new SceneToTake.Guard(manager,sources,clips,listeners);
        plane.samples++;Reject(guard.Validate);plane.samples--;guard.Validate();
        plane.enabled=false;Reject(guard.Validate);plane.enabled=true;guard.Validate();
        var pixel=plane.mask.GetPixel(0,0);uint oldUpdates=plane.mask.updateCount;
        plane.mask.SetPixel(0,0,pixel.r>0?Color.black:Color.white);plane.mask.Apply();
        Debug.Log("MASK_UPDATE "+oldUpdates+" -> "+plane.mask.updateCount);
        Reject(guard.Validate);plane.mask.SetPixel(0,0,pixel);plane.mask.Apply();result.guardRejectsMutation=true;
        using(var legacy=AcousticTake.Open("/Users/clarkpeng/UnityGames/realisticaudioraytracing2d/.context/church-weather/take"))
        {result.legacyV4Opened=legacy.Metadata.version==4;if(!result.legacyV4Opened)throw new Exception("Missing version-four reference");}
        var p=scene.planes[0];result.spatialSamples=p.samples;
        result.samples=Enumerable.Range(0,p.samples).Select(i=>{var s=AudioSourcePlane.Sample(p,i);var world=rain.transform.TransformPoint((Vector3)s);return new Vector4(world.x,world.y,world.z,s.w);}).ToArray();
        foreach(var sample in result.samples)if(sample.w>0)
        {result.emittingSamples++;if(Physics.OverlapSphere((Vector3)sample,.02f).Length!=0)throw new Exception("Rain sample inside solid");}
        if(result.emittingSamples<2)throw new Exception("Insufficient exterior coverage");
        // Small real-scene render; full live-profile capacity is deliberately not allocated.
        var rainScene=SceneToTake.Compile(manager.takeObjects,manager.takeDimension,manager.takeCurveTolerance,manager.takeDefaultMaterial,
            new[]{rain.transform},new[]{rain.clip},listeners,out geometry);
        var states=manager.takeObjects.Select((b,i)=>SceneToTake.Observe(rainScene,i,b.transform)).ToArray();
        states[rainScene.listeners[0]].position=new Vector3(-20,2.7f,-25);
        const int rate=44100;string takePath=Output+"/take";
        using(var writer=new AcousticTake.Writer(takePath,rate,rainScene,geometry,new[]{RayTraceManager.LoadSample(rain.clip,rate)}))
        {
            writer.Append(0,states);states[rainScene.listeners[0]].position+=Vector3.forward*3;writer.Append(2*rate,states);
            writer.Append(new AcousticTake.VoiceEvent{gain=rain.gain,loop=true});writer.Complete();
        }
        using(var take=AcousticTake.Open(takePath))
        {
            var settings=JsonUtility.FromJson<TakeRender.Settings>(JsonUtility.ToJson(manager.directSettings));
            settings.fftSize=256;settings.spectralHop=64;settings.raysPerBin=1;settings.maxBounces=4;
            settings.responseStepSamples=4096;settings.maximumResponsesPerBatch=4;settings.tailSamples=4096;
            result.render=TakeRender.RenderDirect(take,settings,Output+"/render",shader:manager.directShader);
            if(!result.render.complete)throw new Exception("Render incomplete");
        }
        result.settingsPreserved=EditorJsonUtility.ToJson(manager.directSettings)==originalSettings;
        if(!result.settingsPreserved)throw new Exception("Live profile changed");
        File.WriteAllText(Output+"/verification.json",JsonUtility.ToJson(result,true));
        Debug.Log("RAIN_PLANE_VERIFIED");
    }
    static void Reject(Action action)
    {
        try{action();}catch(InvalidOperationException){return;}
        throw new Exception("Configuration mutation was not detected");
    }
}
