import json
from pathlib import Path
import numpy as np
from PIL import Image
from scipy.io import wavfile
from scipy.signal import spectrogram
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
data = json.loads((out / 'verification.json').read_text())
mask = np.asarray(Image.open(root / 'Assets/External/Church/RainMask.png'))[:, :, 0]
points = data['samples']
plt.rcParams.update({'font.size': 11, 'axes.spines.top': False, 'axes.spines.right': False})
fig, ax = plt.subplots(figsize=(6.5, 8.5))
fig.subplots_adjust(left=.14, right=.97, bottom=.13, top=.90)
ax.imshow(mask, origin='upper', extent=(-29, 29, -50, 36), cmap=ListedColormap(['#41474f', '#eef4f7']), vmin=0, vmax=255)
for enabled, color, marker, label in [(True, '#007aaf', 'o', 'Emitting sample'), (False, '#e39c3f', 'x', 'Masked sample (silent)')]:
    selected = [(i, p) for i, p in enumerate(points) if (p['w'] > 0) == enabled]
    ax.scatter([p['x'] for _, p in selected], [p['z'] for _, p in selected], c=color, marker=marker, s=95, linewidths=2, label=label)
    for i, p in selected:
        ax.annotate(str(i + 1), (p['x'], p['z']), xytext=(7, 6), textcoords='offset points', color=color, weight='bold')
ax.plot([-20, -20], [-25, -22], color='#a3456f', lw=3, label='Offline receiver route')
ax.set(xlabel='World X (m)', ylabel='World Z (m)', title='Church rain emission plane\n8 stable sites · 5 emit · 3 masked')
ax.set_aspect('equal')
ax.legend(loc='upper left', frameon=True, framealpha=.95, fontsize=9)
fig.text(.5, .03, 'Light: exposed ground    Dark: covered ground\nMask footprint, not an acoustic pressure map.', ha='center', fontsize=10)
fig.savefig(out / 'rain-plane-map.png', dpi=160)
plt.close(fig)

rate, pcm = wavfile.read(out / 'render/listener-0.wav')
if not np.all(np.isfinite(pcm)) or not np.any(pcm) or np.max(np.abs(pcm)) >= 1:
    raise RuntimeError('Invalid, silent, or clipped render')
metrics = dict(peak=float(np.max(np.abs(pcm))), rms=float(np.sqrt(np.mean(pcm.astype(float)**2))), samples=len(pcm), sampleRate=rate,
               scope='Two-second scripted outdoor receiver movement plus tail, rain only, reduced-quality spectral GPU render. Not a listening or real-time deadline test.')
(out / 'audio-check.json').write_text(json.dumps(metrics, indent=2) + '\n')
fig, axes = plt.subplots(2, 1, figsize=(10, 5.5), layout='constrained')
axes[0].plot(np.arange(len(pcm))/rate, pcm, color='#007aaf', linewidth=.5)
axes[0].set(ylabel='PCM amplitude', title='Silent offline church rain render')
freq, time, power = spectrogram(pcm, rate, window='hann', nperseg=1024, noverlap=768, scaling='density')
im = axes[1].pcolormesh(time, freq, 10*np.log10(np.maximum(power, 1e-16)), vmin=-115, vmax=-65, cmap='magma', shading='auto')
axes[1].set(xlabel='Time (s)', ylabel='Frequency (Hz)', ylim=(0, 10000))
fig.colorbar(im, ax=axes[1], label='dB re 1 PCM²/Hz')
fig.savefig(out / 'waveform-spectrogram.png', dpi=140)
plt.close(fig)
print(json.dumps(metrics))
