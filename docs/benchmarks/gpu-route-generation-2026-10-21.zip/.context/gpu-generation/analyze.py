import json,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(OUT/'source' if (OUT/'source').exists() else ROOT/'tools'));import gpu_routes as gpu
summary=[]
for n in (1,9,25):
 p=OUT/f'full-{n}';gpu.check(p);old=np.genfromtxt(p/'gpu.csv',delimiter=',',names=True);new=np.genfromtxt(p/'generated.csv',delimiter=',',names=True)
 m=json.loads((p/'metadata.json').read_text());g=json.loads((p/'generation.json').read_text());assert gpu.sha(p/'generated.bin')==g['requestSha256']
 np.testing.assert_array_equal(old['point'],new['point']);np.testing.assert_array_equal([v['routes'] for v in m['probes']],new['routes_one']+new['routes_two'])
 a=old['real']+1j*old['imag'];b=new['real']+1j*new['imag'];parity=float(np.linalg.norm(a-b)/np.linalg.norm(a));assert parity<.001
 np.testing.assert_allclose(a,b,rtol=.005,atol=2e-5)
 scene=ROOT/f'.context/spatial-accuracy/planar-{n}/scene.json';assert gpu.sha(scene)==g['sceneSha256']==m['sceneSha256']
 commonpath=ROOT/f'.context/route-monte-carlo/planar-{n}-connections-full.npz';cm=json.loads(commonpath.with_suffix('.json').read_text());assert cm['sceneSha256']==g['sceneSha256']
 common=np.load(commonpath);np.testing.assert_array_equal(common['indices'],g['indices']);shared=common['pressure'].sum(axis=1)
 ref=np.load(scene.parent/'reference-0.35-250.npz')['pressure'];field=b+shared
 db=20*np.log10(np.maximum(abs(field),1e-12)/np.maximum(abs(ref),1e-12));oldstage=json.loads((p/'checked.json').read_text())
 oldseconds=oldstage['cpuPreparationSeconds']+oldstage['gpuSolveSeconds']+oldstage['uploadSeconds']+oldstage['inputSeconds']
 newseconds=g['preparationSeconds']+new['solve_seconds'].sum()+new['input_seconds'].sum()+new['graph_seconds'][0]
 result=dict(boxes=n,probes=len(field),pureEdgeParity=parity,errorPercent=float(100*np.linalg.norm(field-ref)/np.linalg.norm(ref)),within3dBPercent=float(100*np.mean(abs(db)<=3)),
 baselineCpuPreparationSeconds=oldstage['cpuPreparationSeconds'],baselineGpuMedianMs=oldstage['medianSolveMs'],baselineStageSeconds=float(oldseconds),
 generatedPreparationSeconds=g['preparationSeconds'],generatedInputSeconds=float(new['input_seconds'].sum()),generatedGraphWarmMs=float(new['graph_seconds'][0]*1000),generatedGraphColdMs=float(new['cold_graph_seconds'][0]*1000),generatedGpuMedianMs=float(np.median(new['solve_seconds'])*1000),generatedGpuP95Ms=float(np.quantile(new['solve_seconds'],.95)*1000),generatedStageSeconds=float(newseconds),stageSpeedRatio=float(oldseconds/newseconds),oldInputBytes=m['requestBytes'],newInputBytes=g['requestBytes'],gpuBytes=int(new['gpu_bytes'][0]))
 summary.append(result);print(json.dumps(result),flush=True)
 np.savez_compressed(p/'fields.npz',reference=ref,baseline=a+shared,generated=field,points=common['points'])
gpu.save(OUT/'summary.json',summary)
