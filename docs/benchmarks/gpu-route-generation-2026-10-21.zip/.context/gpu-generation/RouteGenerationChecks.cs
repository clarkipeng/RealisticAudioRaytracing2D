using System;
using System.Collections.Generic;
using System.IO;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
public partial class TakeChecks
{
    public static IEnumerable<string> GenerationCases()=>File.ReadAllLines(Environment.GetEnvironmentVariable("ACOUSTIC_GENERATION_CASES"));
    [TestCaseSource(nameof(GenerationCases)),Category("QualityMeasurement")]
    public void MeasureGeneratedRoutes(string directory)
    {
        Assert.That(Application.isBatchMode,Is.True);RequireGpu();
        using var input=new BinaryReader(File.OpenRead(Path.Combine(directory,"generated.bin")));
        Assert.That(input.ReadUInt32(),Is.EqualTo(0x52474731));
        int samples=input.ReadInt32(),depth=input.ReadInt32(),probes=input.ReadInt32(),boxes=input.ReadInt32(),capture=input.ReadInt32();
        Assert.That(depth,Is.InRange(1,2));int edges=checked(boxes*4),square=checked(edges*edges),groups=(samples+63)/64;
        float wave=input.ReadSingle(),horizon=input.ReadSingle(),scale=input.ReadSingle();
        var source=new Vector4(input.ReadSingle(),input.ReadSingle(),0,0);
        var shader=UnityEngine.Object.Instantiate(AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/Tests/Editor/RouteGeneration.compute"));
        try
        {
            int graphKernel=shader.FindKernel("BuildGraph"),endKernel=shader.FindKernel("BuildEnds"),countKernel=shader.FindKernel("CountRoutes"),scan=shader.FindKernel("ScanStarts"),integrate=shader.FindKernel("IntegrateGenerated"),reduce=shader.FindKernel("Reduce");
            using var geometry=new ComputeBuffer(Math.Max(1,boxes),16);using var graph=new ComputeBuffer(Math.Max(1,square+edges),4);
            using var ends=new ComputeBuffer(Math.Max(1,edges),4);using var prefix=new ComputeBuffer(Math.Max(1,square),4);
            using var starts=new ComputeBuffer(Math.Max(1,2*edges),4);using var draws=new ComputeBuffer(samples*5,4);
            using var partial=new ComputeBuffer(groups,8);using var result=new ComputeBuffer(1,8);using var invalid=new ComputeBuffer(1,4);
            using var contributions=new ComputeBuffer(capture!=0?samples:1,8);
            if(boxes>0)geometry.SetData(RouteRead<Vector4>(input,boxes));draws.SetData(RouteRead<float>(input,samples*5));
            shader.SetInt("BoxCount",boxes);shader.SetInt("EdgeCount",edges);shader.SetInt("Depth",depth);
            shader.SetInt("SampleCount",samples);shader.SetInt("Dimensions",5);shader.SetInt("GroupCount",groups);shader.SetInt("Capture",capture);
            shader.SetFloat("WaveNumber",wave);shader.SetFloat("Horizon",horizon);shader.SetFloat("ProposalScale",scale);shader.SetVector("Source",source);
            foreach(int kernel in new[]{graphKernel,endKernel,integrate})shader.SetBuffer(kernel,"Boxes",geometry);
            foreach(int kernel in new[]{graphKernel,countKernel,scan})shader.SetBuffer(kernel,"Graph",graph);
            foreach(int kernel in new[]{endKernel,countKernel,scan})shader.SetBuffer(kernel,"Ends",ends);
            foreach(int kernel in new[]{countKernel,scan,integrate})shader.SetBuffer(kernel,"Prefix",prefix);
            foreach(int kernel in new[]{scan,integrate})shader.SetBuffer(kernel,"Starts",starts);
            shader.SetBuffer(integrate,"Draws",draws);shader.SetBuffer(integrate,"Invalid",invalid);shader.SetBuffer(integrate,"Partials",partial);
            shader.SetBuffer(integrate,"Contributions",contributions);shader.SetBuffer(reduce,"Partials",partial);shader.SetBuffer(reduce,"Result",result);
            var status=new uint[1];long clock=System.Diagnostics.Stopwatch.GetTimestamp();
            if(edges>0)shader.Dispatch(graphKernel,(square+edges+63)/64,1,1);graph.GetData(status,0,0,1);
            double coldGraphSeconds=TakeRender.Elapsed(clock);clock=System.Diagnostics.Stopwatch.GetTimestamp();
            if(edges>0)shader.Dispatch(graphKernel,(square+edges+63)/64,1,1);graph.GetData(status,0,0,1);
            double graphSeconds=TakeRender.Elapsed(clock);var graphValues=new uint[square+edges];if(edges>0)graph.GetData(graphValues);
            using(var debugGraph=new BinaryWriter(File.Create(Path.Combine(directory,"graph.bin"))))foreach(uint v in graphValues)debugGraph.Write(v);
            long bytes=(long)geometry.count*16+(long)(graph.count+ends.count+prefix.count+starts.count+draws.count+1)*4+(long)(partial.count+result.count+contributions.count)*8;
            using var csv=new StreamWriter(Path.Combine(directory,"generated.csv"));csv.WriteLine("point,real,imag,solve_seconds,graph_seconds,gpu_bytes,routes_one,routes_two,cold_graph_seconds,input_seconds");
            using var debug=capture!=0?new BinaryWriter(File.Create(Path.Combine(directory,"generated-contributions.bin"))):null;
            var value=new Vector2[1];var routeTotals=new uint[2];
            void Solve()
            {
                status[0]=0;invalid.SetData(status);
                if(edges>0){shader.Dispatch(endKernel,(edges+63)/64,1,1);shader.Dispatch(countKernel,(edges+63)/64,1,1);shader.Dispatch(scan,1,1,1);}
                shader.Dispatch(integrate,groups,1,1);shader.Dispatch(reduce,1,1,1);result.GetData(value);invalid.GetData(status);
                Assert.That(status[0],Is.Zero);Assert.That(float.IsFinite(value[0].x)&&float.IsFinite(value[0].y),Is.True);
            }
            for(int p=0;p<probes;p++)
            {
                clock=System.Diagnostics.Stopwatch.GetTimestamp();
                shader.SetVector("Receiver",new Vector4(input.ReadSingle(),input.ReadSingle(),0,0));
                double inputSeconds=TakeRender.Elapsed(clock);
                if(p==0)Solve();clock=System.Diagnostics.Stopwatch.GetTimestamp();Solve();double seconds=TakeRender.Elapsed(clock);
                if(edges>0){starts.GetData(routeTotals,0,edges-1,1);starts.GetData(routeTotals,1,2*edges-1,1);}
                csv.WriteLine(FormattableString.Invariant($"{p},{value[0].x:R},{value[0].y:R},{seconds:R},{graphSeconds:R},{bytes},{routeTotals[0]},{routeTotals[1]},{coldGraphSeconds:R},{inputSeconds:R}"));
                if(debug!=null){var v=new Vector2[samples];contributions.GetData(v);foreach(var z in v){debug.Write(z.x);debug.Write(z.y);}}
            }
            Assert.That(input.BaseStream.Position,Is.EqualTo(input.BaseStream.Length));
        }
        finally{UnityEngine.Object.DestroyImmediate(shader);}
    }
}
