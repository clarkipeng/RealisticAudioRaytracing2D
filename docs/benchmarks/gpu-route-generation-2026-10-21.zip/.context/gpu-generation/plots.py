"""Historical measured XY cells; no resampling, fitted gain, or smoothed pressure."""
import json,shutil,sys
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
DEST=Path('/Users/clarkpeng/conductor/workspaces/realisticaudioraytracing2d/tyler/.context');DOC=ROOT/'docs/benchmarks'
cmap=plt.colormaps['magma'].with_extremes(over='#27c9bd',under='#050505',bad='#e5e7eb')
plt.rcParams.update({'font.size':10,'figure.facecolor':'white','savefig.facecolor':'white'})
metrics=[]
def draw(ax,c,points,value,title,ref,small=False):
    x,y=np.unique(points[:,0]),np.unique(points[:,1]);grid=np.full((len(y),len(x)),np.nan)
    grid[np.searchsorted(y,points[:,1]),np.searchsorted(x,points[:,0])]=20*np.log10(np.maximum(abs(value),1e-12))
    im=ax.pcolormesh(x,y,grid,cmap=cmap,vmin=-40,vmax=5,shading='nearest')
    for w in c['walls']:
        center,half=np.array(w['center'][:2]),np.array(w['half'][:2]);ax.add_patch(Rectangle(center-half,*(2*half),facecolor='#515962',edgecolor='white',lw=.6))
    ax.scatter(*c['source'][:2],marker='*',s=100,color='#00a8ff',edgecolor='black',linewidth=.5,zorder=5)
    ax.set(xlabel='x (m)',ylabel='y (m)',title=title,xlim=(-3.4,3.55) if small else (-6.9,6.25),ylim=(-2.75,2.75) if small else (-5.7,5.7));ax.set_aspect('equal')
    db=20*np.log10(np.maximum(abs(value),1e-12)/np.maximum(abs(ref),1e-12));q=dict(errorPercent=float(100*np.linalg.norm(value-ref)/np.linalg.norm(ref)),within3dBPercent=float(100*np.mean(abs(db)<=3)))
    if not np.array_equal(value,ref):
        ax.text(.02,.025,f"{q['within3dBPercent']:.1f}% of cells within ±3 dB",transform=ax.transAxes,fontsize=8.5,bbox=dict(facecolor='white',alpha=.94,edgecolor='none',pad=3))
    return im,q
for n in (1,9,25):
    base=ROOT/f'.context/spatial-accuracy/planar-{n}';c=json.loads((base/'scene.json').read_text());current=np.load(OUT/f'full-{n}/fields.npz');ref=current['reference'];points=current['points']
    old=np.load(ROOT/f'.context/gpu-more-samples/full-maps/planar-{n}/comparison.npz');np.testing.assert_array_equal(old['points'],points);np.testing.assert_array_equal(old['pressure'][0],ref)
    cpu=np.load(ROOT/f'.context/route-monte-carlo/planar-{n}-pooled-n65536-d2-full.npz');shared=np.load(ROOT/f'.context/route-monte-carlo/planar-{n}-connections-full.npz')['pressure'].sum(axis=1)
    np.testing.assert_array_equal(cpu['points'],points);tuned=np.load(ROOT/f'.context/gpu-tuning/planar-{n}-fields.npz');np.testing.assert_array_equal(tuned['points'],points)
    fields=[ref,old['pressure'][1],old['pressure'][2],cpu['pressure'][0].sum(axis=1)+shared,tuned['quarter1m'],current['generated']]
    titles=['Wave reference','1. Old GPU walk · 256 · depth 8','2. More GPU rays · 65K · depth 8','3. Complete routes · CPU · 65K · depth 2','4. GPU port + tuning · 1M · depth 2','5. GPU-generated routes · 65K · depth 2']
    fig,axes=plt.subplots(2,3,figsize=(13,8.7),layout='constrained')
    for ax,field,title in zip(axes.flat,fields,titles):
        im,q=draw(ax,c,points,field,title,ref);metrics.append(dict(scene=n,method=title,**q))
    fig.colorbar(im,ax=list(axes.flat),shrink=.7,pad=.015,extend='both',label='Pressure level (dB re unit pressure)')
    fig.suptitle(f'{n} rigid '+('box' if n==1 else 'boxes')+' · history of measured 2D sound fields · 250 Hz',fontsize=16)
    fig.supxlabel('Same seed 17 and absolute colour scale. Blue star: source. Grey: walls / unmeasured cells. Turquoise: above +5 dB.\nHistorical budgets and path coverage differ: this is a history, not an equal-compute ranking. Complete routes add identical cached reflection/mixed fields.',fontsize=9.5)
    name=f'acoustic-history-{n}-2026-10-21.png';fig.savefig(DOC/name,dpi=145);plt.close(fig);shutil.copy2(DOC/name,DEST/name)
    np.savez_compressed(OUT/f'history-{n}.npz',fields=fields,points=points)
# Smaller original environments; full-map seed 17 rather than multi-seed walk scores.
sampled=np.load(ROOT/'.context/edge-minimal/maps.npz');fig,axes=plt.subplots(2,4,figsize=(15,6.9),layout='constrained');early=[]
for col,(family,label) in enumerate((('barrier','Thick wall'),('staggered','Staggered walls'),('slit','Slit'),('corridor','Corridor'))):
    folder=ROOT/f'.context/wave-study/pilot/{family}-1';c=json.loads((folder/'scene.json').read_text());points=np.array(c['points']).reshape(-1,3);ref=np.load(folder/'reference-0.25-250.npz')['pressure'];trial=sampled[family][0]
    for row,field in enumerate((ref,trial)):
        im,q=draw(axes[row,col],c,points,field,label+(' · wave' if row==0 else ' · complete routes'),ref,True)
        if row:early.append(dict(scene=family,**q))
fig.colorbar(im,ax=list(axes.flat),shrink=.7,pad=.015,extend='both',label='Pressure level (dB re unit pressure)')
fig.suptitle('Earlier small-scene prototype · 19 October · 250 Hz',fontsize=16)
fig.supxlabel('Top: independent wave reference. Bottom: CPU complete-route sampling, 256 samples PER ROUTE, depth 2, seed 17.\nThis earlier budget grows with route count. Same absolute scale as the larger history maps; no smoothing or level matching.',fontsize=10)
name='acoustic-history-small-2026-10-21.png';fig.savefig(DOC/name,dpi=145);plt.close(fig);shutil.copy2(DOC/name,DEST/name)
(OUT/'plot-metrics.json').write_text(json.dumps(dict(larger=metrics,small=early),indent=2)+'\n')
print(json.dumps(early),flush=True)
