import hashlib,json,os,shutil,subprocess,sys,time,uuid
from pathlib import Path
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
runner=ROOT/'.context/gpu-audio/runner';assert not (runner/'Temp/UnityLockfile').exists()
baseline=OUT/'source' if (OUT/'source').exists() else ROOT/'Assets/Tests/Editor'
files={baseline/n:runner/'Assets/Tests/Editor'/n for n in ('RouteIntegration.compute','RouteIntegration.compute.meta','RouteIntegrationChecks.cs','RouteIntegrationChecks.cs.meta')}
for name in ('RouteGeneration.compute','RouteGenerationChecks.cs'):
    source=OUT/name;meta=source.with_name(name+'.meta');meta.write_text('fileFormatVersion: 2\nguid: '+uuid.uuid4().hex+'\n')
    files[source]=runner/'Assets/Tests/Editor'/name;files[meta]=runner/'Assets/Tests/Editor'/meta.name
assert all(not p.exists() for p in files.values())
cases=[str((OUT/n).resolve()) for n in sys.argv[1:]];stamp=time.strftime('%H%M%S')
casefile=OUT/f'cases-{stamp}.txt';casefile.write_text('\n'.join(cases)+'\n')
old=[p for p in cases if (Path(p)/'requests.bin').exists()];oldfile=OUT/f'baseline-{stamp}.txt';oldfile.write_text('\n'.join(old)+'\n')
(OUT/f'provenance-{stamp}.json').write_text(json.dumps(dict(files={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},cases=cases),indent=2))
for source,dest in files.items():shutil.copy2(source,dest)
try:
    cmd=['nice','-n','15','/Applications/Unity/Hub/Editor/6000.4.1f1/Unity.app/Contents/MacOS/Unity','-batchmode','-force-metal','-disable-audio','-job-worker-count','1','-projectPath',str(runner),'-runTests','-testPlatform','EditMode','-testFilter','TakeChecks.MeasureGeneratedRoutes;TakeChecks.RouteAnglesMatchReference'+(';TakeChecks.MeasureCompleteRoutes' if old else ''),'-testResults',str(OUT/f'gpu-{stamp}.xml'),'-logFile',str(OUT/f'gpu-{stamp}.log')]
    result=subprocess.run(cmd,env=dict(os.environ,ACOUSTIC_GENERATION_CASES=str(casefile),ACOUSTIC_ROUTE_CASES=str(oldfile)),timeout=1200)
    test=ET.parse(OUT/f'gpu-{stamp}.xml').getroot();print(test.attrib,flush=True)
    assert result.returncode==0 and test.get('result')=='Passed' and int(test.get('passed'))==len(cases)+len(old)+1
finally:
    for p in files.values():p.unlink(missing_ok=True)
