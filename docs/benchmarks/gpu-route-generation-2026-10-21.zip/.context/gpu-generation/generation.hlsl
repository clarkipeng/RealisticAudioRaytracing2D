// Experimental rigid XY boxes, complete one/two-edge routes. No CPU route lists.
StructuredBuffer<float4> Boxes;
RWStructuredBuffer<uint> Graph, Ends, Prefix, Starts;
uint EdgeCount, BoxCount, Depth;
float2 Source, Receiver;
float2 Corner(uint e)
{
    float4 b=Boxes[e/4]; return float2((e%4)<2?b.x:b.z,(e%2)==0?b.y:b.w);
}
bool Visible(float2 a,float2 b)
{
    for(uint i=0;i<BoxCount;i++)
    {
        float4 box=Boxes[i];float lo=0,hi=1;
        for(uint axis=0;axis<2;axis++)
        {
            float d=b[axis]-a[axis];
            if(d==0) { if(a[axis]<=box[axis] || a[axis]>=box[axis+2]) {hi=-1;break;} }
            else { float x=(box[axis]-a[axis])/d,y=(box[axis+2]-a[axis])/d;lo=max(lo,min(x,y));hi=min(hi,max(x,y)); }
        }
        // Open segments: representable endpoint contacts do not enter a box.
        if(lo<hi-4*1.192092896e-7) return false;
    }
    return true;
}
[numthreads(64,1,1)]
void BuildGraph(uint id:SV_DispatchThreadID)
{
    if(id>=EdgeCount*(EdgeCount+1))return;
    uint a=id/EdgeCount,b=id%EdgeCount;
    Graph[id]=(a==EdgeCount?Visible(Source,Corner(b)):(a!=b && Visible(Corner(a),Corner(b))));
}
[numthreads(64,1,1)]
void BuildEnds(uint id:SV_DispatchThreadID)
{
    if(id<EdgeCount)Ends[id]=Visible(Corner(id),Receiver);
}
[numthreads(64,1,1)]
void CountRoutes(uint id:SV_DispatchThreadID)
{
    if(id>=EdgeCount)return;uint count=0;
    for(uint j=0;j<EdgeCount;j++){count+=Graph[id*EdgeCount+j]*Ends[j];Prefix[id*EdgeCount+j]=count;}
}
[numthreads(1,1,1)]
void ScanStarts(uint id:SV_DispatchThreadID)
{
    uint one=0,two=0;
    for(uint i=0;i<EdgeCount;i++)
    {
        uint start=Graph[EdgeCount*EdgeCount+i];one+=start*Ends[i];
        two+=Depth>1?start*Prefix[i*EdgeCount+EdgeCount-1]:0;
        Starts[i]=one;Starts[EdgeCount+i]=two;
    }
}
uint FindStart(uint rank,uint offset)
{
    uint lo=0,hi=EdgeCount;
    while(lo<hi){uint mid=(lo+hi)/2;if(rank<Starts[offset+mid])hi=mid;else lo=mid+1;}
    return lo;
}
float Angle(uint e,float2 p)
{
    float sx=(e%4)<2?-1:1,sy=(e%2)==0?-1:1;
    float2 face=sx==sy?float2(0,-sy):float2(-sx,0),d=p-Corner(e);
    float x=dot(d,face),y=dot(d,float2(-face.y,face.x));
    float a=Span(abs(y),x);return y<0?2*Pi-a:a;
}
Step MakeStep(uint e,float2 a,float2 b,float remaining)
{
    Step s=(Step)0;float2 p=Corner(e);s.shape=float4(length(a-p),length(b-p),remaining,2.0/3);
    float ts=Angle(e,a),tr=Angle(e,b);if(max(ts,tr)>1.5*Pi+4*1.192092896e-7*Pi)return s;
    float4 theta=Pi+float4(ts+tr,ts-tr,-ts+tr,-ts-tr);uint term=0;
    [unroll] for(uint i=0;i<4;i++)
    {
        // Resolve exact angular boundaries to float precision before division.
        if(min(abs(theta[i]),abs(theta[i]-3*Pi))<=4*1.192092896e-7*Pi)continue;
        float4 mask=(float4)(uint4(0,1,2,3)==term);
        s.sine+=sin((2.0/3)*theta[i])*mask;s.halfSine+=sin(theta[i]/3)*mask;term++;
    }
    return s;
}
Route Generate(uint index,out uint draw,out Step first,out Step second)
{
    Route route=(Route)0;draw=0;first=(Step)0;second=(Step)0;if(EdgeCount==0)return route;
    uint one=Starts[EdgeCount-1],total=one+Starts[2*EdgeCount-1];if(total==0)return route;
    uint rank,selected;
    if(total<=SampleCount)
    {
        uint base=SampleCount/total,extra=SampleCount%total,split=(base+1)*extra;
        rank=index<split?index/(base+1):extra+(index-split)/base;
        selected=base+(rank<extra);draw=index-(rank*base+min(rank,extra));route.weight=2.0/selected;
    }
    else
    {
        // One independent complete route per sample. No rejected-route retries.
        rank=min(total-1,(uint)(Draws[index*Dimensions+4]*total));draw=index;route.weight=2.0*total/SampleCount;
    }
    bool two=rank>=one;uint r=two?rank-one:rank;
    uint a=FindStart(r,two?EdgeCount:0),b=a;route.depth=two?2:1;
    if(two)
    {
        r-=a==0?0:Starts[EdgeCount+a-1];uint lo=0,hi=EdgeCount;
        while(lo<hi){uint mid=(lo+hi)/2;if(r<Prefix[a*EdgeCount+mid])hi=mid;else lo=mid+1;}b=lo;
        float last=length(Receiver-Corner(b));second=MakeStep(b,Corner(a),Receiver,last);
        first=MakeStep(a,Source,Corner(b),length(Corner(b)-Corner(a))+last);
        if(a/4==b/4 && any(Corner(a)==Corner(b)))route.weight*=.5;
    }
    else first=MakeStep(a,Source,Receiver,length(Receiver-Corner(a)));
    if(first.shape.x+first.shape.z>=Horizon || all(first.halfSine==0) || (two && all(second.halfSine==0)))route.depth=0;
    return route;
}
