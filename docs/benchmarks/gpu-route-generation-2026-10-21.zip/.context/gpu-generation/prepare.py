import json,struct,sys,time
from pathlib import Path
import numpy as np
from scipy.stats import qmc
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(OUT/'source' if (OUT/'source').exists() else ROOT/'tools'));import gpu_routes as gpu;import edge_integral as edge

def prepare(name,scene,ids,count=65536,depth=2,seed=17,scale=1.,capture=False,reference=False):
    assert count>0 and count&(count-1)==0 and depth in (1,2)
    directory=OUT/name;directory.mkdir(exist_ok=True);start=time.perf_counter()
    c=json.loads(scene.read_text());points=np.array(c['points']).reshape(-1,3)[ids];source=np.array(c['source']);walls=c['walls']
    # Only pack geometry. No visibility graph, complete routes, angular terms or PDFs on CPU.
    boxes=np.array([np.r_[np.array(w['center'][:2])-w['half'][:2],np.array(w['center'][:2])+w['half'][:2]] for w in walls],dtype='<f4')
    draws=qmc.Sobol(2*depth+1,scramble=True,bits=30,seed=seed).random_base2(count.bit_length()-1)+.5/2**30
    draws=np.clip(draws.astype('<f4'),np.nextafter(np.float32(0),np.float32(1)),np.nextafter(np.float32(1),np.float32(0)))
    if draws.shape[1]<5:
        ranks=draws[:,-1].copy();draws=np.pad(draws,((0,0),(0,5-draws.shape[1])));draws[:,4]=ranks
    k=2*np.pi*250/c['speedOfSound'];h=c['maximumDelaySeconds']*c['speedOfSound']
    binary=struct.pack('<6I5f',0x52474731,count,depth,len(points),len(walls),int(capture),k,h,scale,*source[:2])+boxes.tobytes()+draws.tobytes()+points[:,:2].astype('<f4').tobytes()
    (directory/'generated.bin').write_bytes(binary)
    gpu.save(directory/'generation.json',dict(scene=str(scene),sceneSha256=gpu.sha(scene),indices=np.asarray(ids).tolist(),samples=count,depth=depth,seed=seed,hz=250,scale=scale,preparationSeconds=time.perf_counter()-start,requestBytes=len(binary),requestSha256=gpu.sha(directory/'generated.bin')))
    if reference:
        gpu.prepare(directory,scene,count,depth,seed,250,ids,True,capture,proposal_scale=scale)
    print(name,len(points),'points prepared',flush=True)

if __name__=='__main__':
    if sys.argv[1]=='controls':
        for n in (1,9,25):
            scene=ROOT/f'.context/spatial-accuracy/planar-{n}/scene.json';ids=[0,50,200,400,700]
            prepare(f'control-{n}',scene,ids,65536,reference=True)
        for old in ('empty','no-support','first-order','dc','four-edges','route-subset'):
            p=ROOT/'.context/gpu-routes'/old;m=json.loads((p/'metadata.json').read_text())
            if m['depth']>2:continue
            # New generated cases use 250Hz; short-horizon, empty and subset controls retained.
            prepare('small-'+old,p/'scene.json',m['indices'],m['samples'],m['depth'],m['seed'],capture=True,reference=True)
    elif sys.argv[1]=='maps':
        for n in (1,9,25):
            scene=ROOT/f'.context/spatial-accuracy/planar-{n}/scene.json';c=json.loads(scene.read_text())
            prepare(f'full-{n}',scene,np.arange(len(c['points'])//3))
