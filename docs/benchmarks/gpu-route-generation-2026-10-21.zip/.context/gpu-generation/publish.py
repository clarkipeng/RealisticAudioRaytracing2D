import hashlib,json,shutil,subprocess,zipfile
from pathlib import Path
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent;DOC=ROOT/'docs/benchmarks'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
passed={}
for p in sorted(OUT.glob('gpu-*.xml')):
 r=ET.parse(p).getroot()
 if r.get('result')=='Passed':passed[int(r.get('passed'))]=p
selected=[passed[n] for n in (16,7,2)];assert sum(int(ET.parse(p).getroot().get('passed')) for p in selected)==25
for p in selected:
 provenance=json.loads((OUT/p.name.replace('gpu-','provenance-').replace('.xml','.json')).read_text())
 assert next(v for k,v in provenance['files'].items() if k.endswith('/RouteGeneration.compute'))==sha(OUT/'RouteGeneration.compute')
files=set(p for p in OUT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='manifest.json' and not (p.name=='requests.bin' and p.stat().st_size>2_000_000))
for meta in OUT.glob('*/generation.json'):
 files.add(Path(json.loads(meta.read_text())['scene']))
for n in (1,9,25):
 for name in ('scene.json','reference-0.35-250.npz'):files.add(ROOT/f'.context/spatial-accuracy/planar-{n}'/name)
 for ending in ('connections-full.npz','connections-full.json','pooled-n65536-d2-full.npz','pooled-n65536-d2-full.json'):files.add(ROOT/f'.context/route-monte-carlo/planar-{n}-{ending}')
 files.add(ROOT/f'.context/gpu-more-samples/full-maps/planar-{n}/comparison.npz');files.add(ROOT/f'.context/gpu-tuning/planar-{n}-fields.npz')
for family in ('barrier','staggered','slit','corridor'):
 for name in ('scene.json','reference-0.25-250.npz'):files.add(ROOT/f'.context/wave-study/pilot/{family}-1'/name)
files.add(ROOT/'.context/edge-minimal/maps.npz')
manifest={str(p.relative_to(ROOT)):sha(p) for p in sorted(files)};save(OUT/'manifest.json',manifest);files.add(OUT/'manifest.json')
archive=DOC/'gpu-route-generation-2026-10-21.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(files):z.write(p,p.relative_to(ROOT))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
ledger=dict(baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
 scope='Offline fixed-budget GPU one/two-edge route generation, rigid XY boxes, point-source infinite extrusion. 250 Hz, seed 17, N=65536, width 1. No live renderer change.',
 timing='Final paired whole-map pass: freshly measured CPU packing/planning plus input/submission and warm GPU stages/readback. Excludes initial buffer allocation/upload, cold compilation, diagnostics, cached CPU direct/reflection/mixed and audio/DSP.',
 samples=65536,depth=2,hz=250,seed=17,proposalScale=1,results=json.loads((OUT/'summary.json').read_text()),plotMetrics=json.loads((OUT/'plot-metrics.json').read_text()),
 finalSuites=[dict(file=str(p.relative_to(ROOT)),sha256=sha(p),**ET.parse(p).getroot().attrib) for p in selected],
 controls={p.parent.name:json.loads(p.read_text()) for p in OUT.glob('*/checked-generated.json')},
 archive=dict(file=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,files=len(files)),
 images={p.name:sha(p) for p in DOC.glob('acoustic-history-*-2026-10-21.png')},
 limitations=['Pure diffraction stage speedup only; cached CPU direct/mirror/mixed fields still cost 0.36/30.69/213.96 seconds per prior map calculation.',
 'Physical error unchanged. Only static rigid one/two-edge planar paths qualified; no broadband, moving, finite-3D or near-degenerate boundary qualification.',
 'Earlier old GPU walk maps use depth 8 and different path coverage; not a compute-matched ranking.',
 'Single final pass after warmup, not hardware GPU timestamps or a full process wall-clock guarantee.'])
save(DOC/'gpu-route-generation-2026-10-21.json',ledger)
print('Archived',len(files),'files;',archive.stat().st_size,'bytes;',ledger['finalSuites'],flush=True)
