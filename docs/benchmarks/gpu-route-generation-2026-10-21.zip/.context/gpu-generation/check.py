import json,sys,struct
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(OUT/'source' if (OUT/'source').exists() else ROOT/'tools'));import edge_integral as edge;import gpu_routes as gpu
for name in sys.argv[1:]:
    p=OUT/name;m=json.loads((p/'generation.json').read_text());c=json.loads(Path(m['scene']).read_text());n=m['samples']
    actual=np.genfromtxt(p/'generated.csv',delimiter=',',names=True,ndmin=1);value=actual['real']+1j*actual['imag']
    assert np.isfinite(value).all();edges=edge.corners(c['walls']);source=np.array(c['source']);points=np.array(c['points']).reshape(-1,3)[m['indices']]
    graph=np.array([[int(i!=j and edge.visible(a[0],b[0],c['walls'])) for j,b in enumerate(edges)] for i,a in enumerate(edges)])
    start=np.array([int(edge.visible(source,e[0],c['walls'])) for e in edges]);expected_graph=np.r_[graph.ravel(),start].astype(np.uint32)
    np.testing.assert_array_equal(np.fromfile(p/'graph.bin','<u4'),expected_graph)
    totals=[]
    for point in points:
        ends=np.array([int(edge.visible(e[0],point,c['walls'])) for e in edges])
        totals.append([int(start@ends),int(start@graph@ends) if len(edges) and m['depth']==2 else 0])
    np.testing.assert_array_equal(np.c_[actual['routes_one'],actual['routes_two']],totals)
    if (p/'cpu.npz').exists():
        ref=np.load(p/'cpu.npz');expected=ref['pressure']
        if (p/'generated-contributions.bin').exists():
            parts=np.fromfile(p/'generated-contributions.bin','<f4').reshape(len(points),n,2);parts=parts[...,0]+1j*parts[...,1]
            for i in range(len(points)):
                old=ref['contributions'][ref['offsets'][i]:ref['offsets'][i+1]]
                if not len(old):old=np.zeros(n)
                np.testing.assert_allclose(parts[i],old,rtol=.005,atol=2e-5)
                np.testing.assert_allclose(parts[i].astype(complex).sum(),value[i],rtol=2e-6,atol=1e-7)
    else:
        binary=(p/'generated.bin').read_bytes();draws=np.frombuffer(binary,'<f4',offset=44+16*len(c['walls']),count=n*5).reshape(n,5)
        neighbor=[list(np.flatnonzero(row)) for row in graph];starts=list(np.flatnonzero(start));h=c['maximumDelaySeconds']*c['speedOfSound'];k=2*np.pi*250/c['speedOfSound'];allparts=[]
        for point in points:
            parts=[]
            for draw in draws:
                paths=list(edge.route_samples(edges,neighbor,starts,point,c['walls'],m['depth'],1,[float(draw[4])]))
                parts.append(sum(edge.sample_chain([edges[e] for e in path],source,point,k,h,draw[None,:],proposal_scale=m['scale'])*weight/n for path,selected,weight in paths))
            allparts.append(parts)
        expected=np.sum(allparts,axis=1)
        parts=np.fromfile(p/'generated-contributions.bin','<f4').reshape(len(points),n,2);parts=parts[...,0]+1j*parts[...,1]
        np.testing.assert_allclose(parts,allparts,rtol=.005,atol=2e-5)
    relative=float(np.linalg.norm(value-expected)/max(np.linalg.norm(expected),1e-30))
    result=dict(relativeL2=relative,maximumAbsoluteDifference=float(abs(value-expected).max()),medianMs=float(np.median(actual['solve_seconds'])*1000),routeCountParity=True,visibilityParity=True)
    print(name,result,flush=True)
    np.testing.assert_allclose(value,expected,rtol=.005,atol=2e-5)
    assert relative<.001
    gpu.save(p/'checked-generated.json',result)
