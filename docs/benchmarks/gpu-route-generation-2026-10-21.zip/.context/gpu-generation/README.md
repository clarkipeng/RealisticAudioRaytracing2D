# GPU route generation experiment, 21 October 2026

Restore this archive at the project root; it contains `.context/` paths only. Source baseline: Git `8e3391d`. The current live Unity project is not modified or opened by these commands. The runner must already exist at `.context/gpu-audio/runner`, be closed, and contain the project's test support (`TakeChecks`, `TakeRender`). Python requires the existing `.context/wave-planar/venv` with NumPy, SciPy and matplotlib. The runner/venv are not bundled. Unity is pinned to the installed 6000.4.1f1 path in run.py.

The `source/` directory snapshots the baseline shader, fixture and CPU integrator. The build script composes the 111-line route generator with that integration shader; it does not install a production shader. The 71-line fixture stages into the isolated runner only. `run.py` records exact hashes, runs low-priority batch Metal with audio disabled and one worker, checks XML results, and removes staged assets. No GUI or playback command is used.

To regenerate figures from the included historical pressure arrays:

```sh
OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 \
  nice -n 15 .context/wave-planar/venv/bin/python .context/gpu-generation/plots.py
```

The plotting destination for Conductor copies is set in plots.py; update it on another machine. Canonical figures are written under `docs/benchmarks/`. The archive includes the seven scenes, reference arrays, cached common fields and prior candidate fields needed by that script. Full pressure values, including out-of-scale old-GPU spikes, remain in NPZ files.

To run a fresh paired 9-box map without overwriting the original evidence:

```sh
export OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
nice -n 15 .context/wave-planar/venv/bin/python .context/gpu-generation/build.py
nice -n 15 .context/wave-planar/venv/bin/python - <<'PY'
import sys,json,numpy as np
sys.path.insert(0,'.context/gpu-generation')
from prepare import prepare,ROOT,OUT,gpu
scene=ROOT/'.context/spatial-accuracy/planar-9/scene.json'
ids=np.arange(len(json.loads(scene.read_text())['points'])//3)
prepare('repeat-9',scene,ids)
gpu.prepare(OUT/'repeat-9',scene,65536,2,17,250,ids)
PY
nice -n 15 .context/wave-planar/venv/bin/python .context/gpu-generation/run.py repeat-9
```

`gpu.csv` contains the prepared-route baseline; `generated.csv` includes generated routes. Compare complex pressure and route counts before comparing timings. `analyze.py` shows the exact aggregation used for the three published `full-*` cases. Their large baseline `requests.bin` files are omitted; use the command above with fresh names to rebuild them. Controls retain their smaller inputs, CPU references and per-sample captures.

The current prototype handles rigid XY rectangles and one/two-edge paths at equal source/receiver height. N must be a positive power of two. No ray gain clipping, dropped-route renormalization, frequency fitting or temporal smoothing is applied. For more routes than samples, the prototype samples complete routes rather than enumerating them. The uniform scene graph remains quadratic in edge count; it uses direct box visibility, not a BVH. Reflection/mixed fields in the maps are cached CPU results and excluded from both timing totals.

The scripts' `controls`/`maps` preparation entry points expect some older `.context/gpu-routes` inputs that are not bundled. Existing archived controls can be rerun directly by passing their directory names to run.py and then check.py. The subset controls independently compute one pressure contribution per selected complete route on the CPU. The legacy `small-dc` directory is run at 250 Hz here; it does not validate DC.

Historical failed XML/logs are retained. The final selected suites passed 16, 7 and 2 cases; repeated earlier map measurements are also retained in XML but the published CSV files are the final run. The JSON ledger identifies the exact final suite names and hashes. Metadata stores local absolute scene paths; update these paths when moving the archive to another machine.
