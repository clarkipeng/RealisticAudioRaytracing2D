# Third-order finite path experiment (in progress)

Boundary bake checkpoint 0122256 is already accepted. This experiment adds a separate, opt-in complete interaction order of three; it does not enable a scene preset. Keep the old two-interaction setting as the reproducible baseline.

The single finite evaluator decodes a three-bit R/D topology, samples physical edge points, solves each intervening mirror run by unfolding, checks every physical segment and computes signed wedge pressure / actual travel distance. Adjacent solid-face edge connections retain the accepted half multiplicity. Every actual R/D vertex contributes its velocity factor. Source births and spectral material factors use the ordinary arrival pipeline. No propagation cache or per-object response layer.

Sampling: bounded topology candidates, equal family support when sampling candidates, finite Cauchy/uniform edge mixtures with their actual PDFs; independent Halton dimensions 11/13 for the third edge. Reflected previous-edge proposal guidance is omitted (the uniform component retains support). This is a variance concern to measure, not a new physical parameter or a reason to alter gains.

Primary derivation/reference context:
- Svensson EDtoolbox uses a directional edge-pair integral equation: https://github.com/upsvensson/Edge-diffraction-Matlab-toolbox . Its published scope is convex Neumann scattering. Applying finite mixed paths to a nonconvex room is an extension requiring validation, not inherited full-wave accuracy.
- The retained `tools/edge_integral.py` already unfolds mirror runs for offline planar mixed-order controls. Finite visibility and height dependence are evaluated physically here.
- `reference.py` independently integrates a finite RDR example with SciPy adaptive quadrature and a selected finite cube DDD route with tensor Gauss quadrature (24/48/80 nodes). It does not import the shader's sampling code. `reference.json` retains convergence and expected signed complex values.
- RRR is checked independently with the shoebox image lattice at Manhattan order three. Six open room-face owners represent air between the walls; a solid box containing the source would be a different medium.

Acceptance: independent path controls; rendered CPU/GPU spectral and IR audio; unchanged two-order controls; retained later interactions; final real-room field and sample/seed/cost comparison against the same BEM reference. Preserve failures/prototype sources before changes. Do not hide a failed field gate with normalization, clipping or a reference change.
