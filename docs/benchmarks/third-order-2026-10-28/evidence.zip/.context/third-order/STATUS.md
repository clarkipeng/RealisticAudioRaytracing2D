# Completed: solid boundary bake and third-order audit

Accepted production commits: 0122256 (material-preserving solid boundary bake), 0cbd066 (excluded-root independent-motion guard).

Final production checks: 5/5 pass. Whole/split fields are exactly equal for seeds 0/17 and the rotated/moving case; CPU/GPU audio matches. Prior accepted bake suite: 14/14 plus one focused exclusion check; Python 6/6.

Same finite 3D room/roof: 40.7271% -> 29.2352% overall complex error, 123.9380% -> 86.9216% shadow. Indoor million-sample error remains ~47%. No rain preset promotion.

Third-order experiment rejected and removed from live Assets. Balanced full map 119.3967% overall / 321.3638% shadow; fresh corrected indoor proposal 190.15% / 95.49% error. Balanced checks 18/18; guided-fresh 9/9. The intervening guided run is invalid for source validation because Unity reused the prior conditional-include binary; exact evidence retained. Right-angle integer-index corner residue is too small to explain the spikes. No physical kernel changed on that hypothesis.

Final prototype patch/source retained under final-prototype, and exact per-run source/provenance snapshots under each run. Public audit: docs/benchmarks/third-order-2026-10-28/README.md, report.json, comparison.png and evidence.zip. Accepted workflow/report: docs/acoustic-solid-bake.md and docs/benchmarks/solid-boundary-2026-10-28/README.md.

All owned workers exited. No foreground Unity, speaker/microphone, Chrome, Lavish, branch change, push or PR. User Recovery files remain untouched. No runtime work remains from this approved bake/audit task; full-room fidelity is still an unresolved research problem.
