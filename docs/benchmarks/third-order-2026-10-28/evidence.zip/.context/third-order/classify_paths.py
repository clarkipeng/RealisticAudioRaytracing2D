"""Classify captured physical edge hits; does not modify transport or fit pressure."""
import csv,json,sys
from pathlib import Path
import numpy as np
folder=Path(sys.argv[1]);data=json.loads((folder/'boundary.json').read_text())
v=np.array(data['vertices']).reshape(-1,3);t=np.array(data['triangles']).reshape(-1,3)
normals=np.cross(v[t[:,1]]-v[t[:,0]],v[t[:,2]]-v[t[:,0]]);normals/=np.linalg.norm(normals,axis=1)[:,None]
incidence={}
for i,tri in enumerate(t):
 for a,b in zip(tri,np.roll(tri,-1)):incidence.setdefault(tuple(sorted((int(a),int(b)))),[]).append(i)
edges=[]
for (ia,ib),faces in incidence.items():
 if len(faces)!=2 or abs(np.dot(normals[faces[0]],normals[faces[1]]))>=.99999:continue
 a=v[ia];b=v[ib];axis=(b-a)/np.linalg.norm(b-a)
 def side(face):
  q=v[t[face]].sum(axis=0)-3*a;q-=axis*np.dot(q,axis);return q/np.linalg.norm(q)
 first_side=side(faces[0]);second_side=side(faces[1])
 angle=np.arctan2(np.dot(second_side,normals[faces[0]]),np.dot(second_side,first_side))
 if angle<=0:angle+=2*np.pi
 edges.append(dict(a=a.tolist(),b=b.tolist(),nu=float(np.pi/angle)))
a=np.array([e['a'] for e in edges]);b=np.array([e['b'] for e in edges]);axis=b-a;length2=np.sum(axis*axis,axis=1);nu=np.array([e['nu'] for e in edges])
rows=list(csv.DictReader((folder/'complete-vertices.csv').open()));summary={}
def hit_nu(p):
 f=np.clip(np.sum((p-a)*axis,axis=1)/length2,0,1);dist=np.linalg.norm(a+f[:,None]*axis-p,axis=1);j=dist.argmin()
 if dist[j]>1e-4:raise ValueError(('No physical edge',p.tolist(),float(dist[j])))
 return nu[j]
for r in rows:
 family=int(r['family']);nodes=[0] if family in [0,3] else [1] if family==2 else [0,1] if family==1 else [] if family==4 else [j for j in range(3) if not ((family-5)>>j)&1]
 values=[]
 for j in nodes:
  c='abc'[j];values.append(hit_nu(np.array([float(r[c+k]) for k in 'xyz'])))
 integer=any(abs(x-round(x))<1e-7 for x in values)
 key=(int(r['seed']),family,'integer-nu edge' if integer else 'other')
 q=summary.setdefault(key,dict(count=0,pressure=0j,maximum=0.))
 pressure=float(r['pressure']);p=pressure*np.exp(-2j*np.pi*float(r['hz'])*float(r['delay']))
 q['count']+=1;q['pressure']+=p;q['maximum']=max(q['maximum'],abs(pressure))
output=[]
for (seed,family,kind),q in sorted(summary.items()):
 p=q['pressure'];output.append(dict(seed=seed,family=family,kind=kind,count=q['count'],pressure=[p.real,p.imag],maximum=q['maximum']))
(folder/'edge-classification.json').write_text(json.dumps(dict(edges=edges,groups=output),indent=2)+'\n')
print(json.dumps([q for q in output if q['kind']=='integer-nu edge'],indent=2))
