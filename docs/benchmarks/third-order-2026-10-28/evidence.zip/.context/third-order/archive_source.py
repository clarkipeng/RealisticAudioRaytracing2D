"""Snapshot an ended runner exactly as recorded, before syncing another experiment."""
import hashlib,json,shutil,sys
from pathlib import Path
root=Path.cwd();run=Path(sys.argv[1]);runner=root/'.context/gpu-audio/runner'
assert (run/'resources.json').exists(), 'Runner has not completed'
for name,expected in json.loads((run/'provenance.json').read_text()).items():
    src=runner/name
    assert hashlib.sha256(src.read_bytes()).hexdigest()==expected,name
    dst=run/'source'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
    meta=Path(str(src)+'.meta')
    if meta.exists():shutil.copy2(meta,Path(str(dst)+'.meta'))
shutil.copy2(root/'.context/diffraction-integration/run.py',run/'guarded-runner.py')
print('Archived exact source:',run)
