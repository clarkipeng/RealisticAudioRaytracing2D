// Finite third-order paths share one physical-vertex evaluator. Specular runs
// are unfolded between sampled edge points, then checked against real triangles.
uint CompleteNode(CompleteRoute route,uint node)
{return node==0?route.first:node==1?route.second:route.third;}
float CompleteRadical(uint n,uint radix)
{
    float denominator=1,value=0;
    while(n>0){denominator*=radix;value+=(n%radix)/denominator;n/=radix;}
    return value;
}
float2 CompleteThirdDraw(uint draw,uint dimension)
{
    if(dimension<2)return dimension==0?CompleteDraws[draw].xy:CompleteDraws[draw].zw;
    uint rng=HashRay(RaySeed^0x7d32eb19u);
    return clamp(frac(float2(CompleteRadical(draw+1,11),CompleteRadical(draw+1,13))+float2(RandomRay(rng),RandomRay(rng))),1e-7,1-1e-7);
}
float3 CompleteUnfold(CompleteRoute route,uint state,float3 location,int first,int end,int direction)
{
    float3 normal;
    for(int i=first;i!=end;i+=direction)location=CompleteImage(CompleteNode(route,i),state,location,false,normal);
    return location;
}
bool CompleteMirrorRun(CompleteRoute route,uint state,uint first,uint end,inout float3 points[5],inout float cosines[3])
{
    float3 images[3],image=points[first],normal;
    for(uint i=first;i<end;i++){image=CompleteImage(CompleteNode(route,i),state,image,false,normal);images[i]=image;}
    for(int j=(int)end-1;j>=(int)first;j--)
    {
        uint primitive=CompleteNode(route,j);float3 delta=points[j+2]-images[j];float size=length(delta);
        if(size<=RayEpsilon)return false;float3 direction=delta/size,unused;
        float t=PrimitiveDistance(primitive,state,images[j],direction,false,unused);
        if(t<=RayEpsilon || t>=size-RayEpsilon)return false;
        for(uint k=0;k<primitive;k++)if(Primitives[k].indices.x==Primitives[primitive].indices.x)
            if(abs(PrimitiveDistance(k,state,images[j],direction,false,unused)-t)<RayEpsilon)return false;
        points[j+1]=images[j]+t*direction;
    }
    for(uint j=first;j<=end;j++)if(!Visible(state,points[j],points[j+1],false))return false;
    for(uint j=first;j<end;j++)
    {
        CompleteImage(CompleteNode(route,j),state,points[j],false,normal);
        cosines[j]=abs(dot(normalize(points[j+1]-points[j]),normal));
    }
    return true;
}
bool CompleteThirdCandidate(CompleteRoute route,uint state,float3 source,float3 end)
{
    int first=0;while(first<3 && CompleteIsMirror(route.family,first))first++;
    if(first==3)
    {
        float3 points[5]={source,float3(0,0,0),float3(0,0,0),float3(0,0,0),end};float cosines[3]={0,0,0};
        return CompleteMirrorRun(route,state,0,3,points,cosines);
    }
    int last=2;while(CompleteIsMirror(route.family,last))last--;
    float3 from=CompleteUnfold(route,state,source,0,first,1),to=CompleteUnfold(route,state,end,2,last,-1);
    // Endpoint wedge angles are independent of axial edge height. These are
    // exact zero-contribution rejections, not midpoint-visibility guesses.
    return CompleteExterior(CompleteNode(route,first),state,from,false) && CompleteExterior(CompleteNode(route,last),state,to,false);
}
void IntegrateCompleteThird(CompleteRoute route,uint index,uint samples,uint draw,uint slot)
{
    uint state=CompleteFrame*ObjectCount,emission=CompleteFrame*EmissionFrameStride+RayTracePair/ListenerCount;
    float3 points[5],incoming[3];float cosines[3]={0,0,0};
    points[0]=CompleteSource(false);points[4]=CompleteListener(false);
    for(uint i=0;i<3;i++)points[i+1]=CompleteIsMirror(route.family,i)?0:CompleteAnchor(CompleteNode(route,i),state,false);
    float gain=route.weight/samples;int previous=-1;uint diffractions=0;
    for(int i=0;i<3;i++)if(!CompleteIsMirror(route.family,i))
    {
        int next=i+1;while(next<3 && CompleteIsMirror(route.family,next))next++;
        incoming[i]=CompleteUnfold(route,state,points[previous+1],previous+1,i,1);
        float3 outgoing=CompleteUnfold(route,state,points[next+1],next-1,i,-1);
        uint edge=CompleteNode(route,i),prior=previous==i-1 && previous>=0?CompleteNode(route,previous):0xffffffff;
        float density;
        // Every mixture retains a uniform finite-edge component. Reflected
        // incoming-edge guidance is deferred; omitting it changes variance only.
        float3 before=prior==0xffffffff?incoming[i]:incoming[previous];
        points[i+1]=CompletePoint(edge,prior,state,false,(Step)0,(Step)0,before,incoming[i],outgoing,outgoing,0,0,
                                 CompleteThirdDraw(draw,diffractions),density);
        if(!(density>0) || !all(isfinite(points[i+1])))return;
        gain/=density;previous=i;diffractions++;
    }
    for(uint i=0;i<3;)
    {
        if(!CompleteIsMirror(route.family,i)){i++;continue;}
        uint end=i+1;while(end<3 && CompleteIsMirror(route.family,end))end++;
        if(!CompleteMirrorRun(route,state,i,end,points,cosines))return;i=end;
    }
    // Edges joined directly along a physical solid face carry the same half
    // multiplicity and exterior-limit visibility as the accepted DD integrator.
    if(!CompleteIsMirror(route.family,0) && !Visible(state,points[0],points[1],false))return;
    if(!CompleteIsMirror(route.family,2) && !Visible(state,points[3],points[4],false))return;
    for(uint i=0;i<2;i++)if(!CompleteIsMirror(route.family,i) && !CompleteIsMirror(route.family,i+1))
    {float connection=CompleteEdgeConnection(CompleteNode(route,i),CompleteNode(route,i+1),state,points[i+1],points[i+2]);if(connection==0)return;gain*=connection;}
    float distance=0;for(uint i=0;i<4;i++){float leg=length(points[i+1]-points[i]);if(leg<=RayEpsilon)return;distance+=leg;}
    if(distance>MaximumPathDelay*SpeedOfSound)return;
    if(diffractions==0)gain/=distance;
    else
    {
        previous=-1;
        for(int i=0;i<3;i++)if(!CompleteIsMirror(route.family,i))
        {
            int next=i+1;while(next<3 && CompleteIsMirror(route.family,next))next++;
            float3 from=CompleteUnfold(route,state,points[previous+1],previous+1,i,1);
            float3 to=CompleteUnfold(route,state,points[next+1],next-1,i,-1);
            float a=length(points[i+1]-from),b=length(points[i+1]-to);if(min(a,b)<=RayEpsilon)return;
            gain*=TunedEdgeKernel(CompleteNode(route,i),state,from,points[i+1],to,false)/a;
            if(next==3)gain/=b;previous=i;
        }
    }
    uint identity=HashRay(CompleteIdentity(route,diffractions==0?0:draw)^HashRay(route.third));
    float3 sourceVelocity=EmissionRanges[emission].w==2?float3(0,0,0):PointVelocity(state+Sources[RayTracePair/ListenerCount],points[0]);
    float ratio=(SpeedOfSound-dot(Velocity(state+Listeners[RayTracePair%ListenerCount]),normalize(points[4]-points[3])))/
                (SpeedOfSound-dot(sourceVelocity,normalize(points[1]-points[0])));
    for(uint i=0;i<3;i++)
    {uint node=CompleteNode(route,i),owner=CompleteIsMirror(route.family,i)?Primitives[node].indices.x:Edges[node].ids.x;ratio*=CompleteVelocityRatio(owner,state,points[i],points[i+1],points[i+2],false);}
    for(uint bin=0;bin<FrequencyBins;bin++)
    {
        float weight=exp(-AirCoefficient(max(1,bin*FrequencyStep))*distance);float2 material=float2(1,0);
        for(uint i=0;i<3;i++)
        {
            uint node=CompleteNode(route,i);
            if(CompleteIsMirror(route.family,i))material=ComplexProduct(material,ReflectionPressure(RayMaterials[Primitives[node].indices.y*FrequencyBins+bin],cosines[i]));
            else weight*=DiffractionFactor*EdgeOpacity(node,bin);
        }
        RayPath path=ApplyMaterial(Arrival(points[3],points[4],distance/SpeedOfSound,gain*weight*ReferenceDistance,bin,ratio,identity),material);
        path=ApplyEmission(path,emission,CompleteSite,0);RayPaths[slot+bin]=path;
#if defined(ACOUSTIC_DEBUG)
        if(DebugSelected(CompleteFrame*PairCount+RayTracePair,bin) && (path.pressureGain!=0 || path.pressureImag!=0))
        {
            uint debug=PrimitiveCount+1+RaysPerBin*(2+2*MaxBounces)+2*MirrorCandidateCount+CompleteDebugStride*index;
            uint trace=2*max(RaysPerBin,MirrorCandidateCount)+2+index;float time=0;
            float pressure=path.pressureImag==0?path.pressureGain:length(float2(path.pressureGain,path.pressureImag));
            for(uint i=0;i<3;i++)
            {
                float next=time+length(points[i+1]-points[i])/SpeedOfSound;uint node=CompleteNode(route,i);bool mirror=CompleteIsMirror(route.family,i);
                int materialId=mirror?Primitives[node].indices.y:Primitives[Edges[node].ids.y].indices.y;
                DebugWrite(debug+i,trace,mirror?DebugReflection:DebugDiffraction,materialId,points[i],points[i+1],time,next,pressure);time=next;
            }
            DebugArrival(debug+3,trace,points[3],points[4],time,path);
        }
#endif
    }
}
