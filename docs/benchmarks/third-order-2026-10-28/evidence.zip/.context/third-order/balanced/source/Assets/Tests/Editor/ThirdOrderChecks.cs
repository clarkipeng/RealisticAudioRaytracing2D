using System;
using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine;
using Complex=System.Numerics.Complex;

public partial class TakeChecks
{
    [Test,Category("ThirdOrder")]
    public void ThirdOrderSettingsPreserveOldJobsAndRejectPlanarExtension()
    {
        var settings=ThirdSettings(16);settings.completeRouteOrder=0;TakeRender.Validate(settings);Assert.That(settings.CompleteOrder,Is.EqualTo(2));
        settings.completeRouteOrder=4;Assert.Throws<ArgumentException>(()=>TakeRender.Validate(settings));settings.completeRouteOrder=3;
        KnifeEdgeFixture(true,out var scene,out var geometry,out _);
        Assert.Throws<ArgumentException>(()=>{using var solver=new TransportSolver(scene,geometry,settings,RequireGpu(),sampleRate:1000);});
    }
    TakeRender.Settings ThirdSettings(int samples)
    {
        var settings=EdgeSettings();settings.fftSize=8;settings.spectralHop=2;settings.raysPerBin=2;
        settings.maxBounces=3;settings.completeRouteOrder=3;settings.completeRouteSamples=samples;
        settings.maximumDelaySeconds=.2f;settings.useBvh=true;return settings;
    }
    static int CompleteDebugStart(AcousticTake.Scene scene,AcousticTake.Primitive[] geometry,TakeRender.Settings settings)
        =>geometry.Length+1+settings.RaysPerBin*(2+2*settings.maxBounces)+2*settings.MirrorCandidates(scene);
    [TestCase(0f),TestCase(.35f),Category("GPU"),Category("ThirdOrder")]
    public void ThirdOrderMirrorsMatchIndependentShoeboxImages(float absorption)
    {
        var scene=Scene(7);scene.listeners=new[]{1};var states=States(7);
        scene.materials=new[]{new AcousticTake.MaterialDefinition{frequencies=new[]{0f},absorption=new[]{absorption},scattering=new[]{0f},transmission=new[]{0f}}};
        var half=new Vector3(3,2,4);var geometry=TransportBox(scene.dimension,2,0,1);
        for(int i=0;i<geometry.Length;i++)
        {geometry[i].a=Vector3.Scale(geometry[i].a,half);geometry[i].b=Vector3.Scale(geometry[i].b,half);geometry[i].c=Vector3.Scale(geometry[i].c,half);}
        // Six open wall patches bound an air room. A closed box owner would
        // describe solid material filling that room, which is a different scene.
        for(int face=0;face<6;face++)
        {
            int owner=2+face;scene.objects[owner].primitiveStart=2*face;scene.objects[owner].primitiveCount=2;
            geometry[2*face].objectIndex=geometry[2*face+1].objectIndex=owner;
            states[owner].position=Vector3.zero;states[owner].flags=AcousticTake.StateFlags.Active|AcousticTake.StateFlags.Geometry;
        }
        states[0].position=new Vector3(-.5f,.4f,.3f);states[1].position=new Vector3(.6f,.2f,-.3f);
        var settings=ThirdSettings(4096);settings.diffractionFactor=0;
        using var solver=new TransportSolver(scene,geometry,settings,RequireGpu(),sampleRate:1000);
        int first=CompleteDebugStart(scene,geometry,settings);
        foreach(int bin in new[]{0,1,2})
        {
            var segments=solver.CaptureRays(states,0,bin);var actual=Complex.Zero;int count=0;
            for(int i=0;i<settings.CompleteSamples;i++)
            {
                int at=first+settings.CompleteDebugStride*i;
                if(segments[at+2].kind!=TransportSolver.RayEvent.Reflection)continue;
                Assert.That(segments[at].kind,Is.EqualTo(TransportSolver.RayEvent.Reflection));
                Assert.That(segments[at+1].kind,Is.EqualTo(TransportSolver.RayEvent.Reflection));
                var arrival=segments[at+3];Assert.That(arrival.kind,Is.EqualTo(TransportSolver.RayEvent.Listener));
                actual+=arrival.pressure*Complex.Exp(new Complex(0,-2*Math.PI*bin*125*arrival.end.w));count++;
            }
            var expected=Complex.Zero;
            for(int x=-3;x<=3;x++)for(int y=-3;y<=3;y++)for(int z=-3;z<=3;z++)
            {
                if(Math.Abs(x)+Math.Abs(y)+Math.Abs(z)!=3)continue;
                int[] order={x,y,z};var image=states[0].position;
                for(int axis=0;axis<3;axis++)image[axis]=2*order[axis]*half[axis]+((Math.Abs(order[axis])%2==0)?image[axis]:-image[axis]);
                double distance=Vector3.Distance(image,states[1].position);
                expected+=Math.Pow(1-absorption,1.5)*Complex.Exp(new Complex(0,-2*Math.PI*bin*125*distance/343))/distance;
            }
            Debug.Log("THIRD_RRR: bin="+bin+" actual="+actual+" expected="+expected+" arrivals="+count);
            Assert.That((actual-expected).Magnitude,Is.LessThan(2e-5));
        }
        solver.Solve(states,new TakeRender.DirectPath[1]);
        foreach(var method in new[]{TakeRender.Synthesis.Spectral,TakeRender.Synthesis.ImpulseResponse})
        {
            settings.synthesis=method;settings.listenerOutput=TakeRender.ListenerOutput.Binaural;
            var clip=new float[65];for(int i=0;i<clip.Length;i++)clip[i]=.05f*Mathf.Sin(i*.17f);
            var signal=new TakeRender.Signal(clip);signal.SetActive(0,true);signal.Append(new AcousticTake.VoiceEvent{gain=1,loop=true});
            var signals=new[]{signal};var cpu=new TakeRender.Mixer(scene,1000,settings,signals);
            using var gpu=new GpuAudio(scene,1000,settings,signals,transported:true);
            cpu.SetResponse(0,new TakeRender.DirectPath[1],states,true,solver.RayPaths,0);gpu.SetResponse(0,true,solver.RayBuffer,0,scene,states);
            var a=new float[256];var b=new float[256];cpu.Render(0,128,a);gpu.Render(0,128,b);
            double energy=0;for(int i=0;i<a.Length;i++){Assert.That(b[i],Is.EqualTo(a[i]).Within(2e-4));energy+=a[i]*a[i];}
            Assert.That(energy,Is.GreaterThan(1e-6));
        }
    }
    [TestCase(0),TestCase(17),Category("GPU"),Category("ThirdOrder")]
    public void ThirdOrderDiffractionMatchesIndependentTripleIntegral(int seed)
    {
        KnifeEdgeFixture(false,out var scene,out _,out var state);
        var geometry=TransportBox(scene.dimension,2,0,1);scene.objects[2].primitiveCount=geometry.Length;
        state[0].position=Vector3.left*3;state[1].position=Vector3.right*3;
        var settings=ThirdSettings(1048576);settings.seed=seed;
        using var solver=new TransportSolver(scene,geometry,settings,RequireGpu(),sampleRate:1000);
        int start=CompleteDebugStart(scene,geometry,settings);
        var expected=new[]{new Complex(-.0017141852768593913,0),new Complex(-.0005205691852630922,.001424755699179506),new Complex(.0007490320095331474,.000844637589676592)};
        for(int bin=0;bin<3;bin++)
        {
            var segments=solver.CaptureRays(state,0,bin);var actual=Complex.Zero;int count=0;
            for(int i=0;i<settings.CompleteSamples;i++)
            {
                int at=start+settings.CompleteDebugStride*i;bool selected=true;
                for(int j=0;j<3;j++)selected&=segments[at+j].kind==TransportSolver.RayEvent.Diffraction;
                if(!selected)continue;var a=segments[at].end;var b=segments[at+1].end;var c=segments[at+2].end;
                if(Mathf.Abs(a.x+1)>1e-4f || Mathf.Abs(a.y-1)>1e-4f || Mathf.Abs(b.x-1)>1e-4f || Mathf.Abs(b.y-1)>1e-4f || Mathf.Abs(c.x-1)>1e-4f || Mathf.Abs(c.y+1)>1e-4f)continue;
                var arrival=segments[at+3];actual+=arrival.pressure*Complex.Exp(new Complex(0,-2*Math.PI*bin*125*arrival.end.w));count++;
            }
            Debug.Log("THIRD_DDD: seed="+seed+" bin="+bin+" actual="+actual+" expected="+expected[bin]+" samples="+count);
            Assert.That((actual-expected[bin]).Magnitude,Is.LessThan(.075*expected[bin].Magnitude));
        }
    }
    [TestCase(0,false),TestCase(17,false),TestCase(17,true),Category("GPU"),Category("ThirdOrder")]
    public void ThirdOrderMixedPathMatchesIndependentUnfoldedIntegral(int seed,bool moving)
    {
        var scene=Scene(4);scene.listeners=new[]{1};var state=States(4);var faces=new List<AcousticTake.Primitive>();
        scene.materials=new[]{new AcousticTake.MaterialDefinition{frequencies=new[]{0f},absorption=new[]{.25f},scattering=new[]{0f},transmission=new[]{0f}}};
        void Quad(int owner,Vector3 a,Vector3 b,Vector3 c,Vector3 d)
        {
            scene.objects[owner].primitiveStart=faces.Count;scene.objects[owner].primitiveCount=2;
            faces.Add(new AcousticTake.Primitive{objectIndex=owner,a=a,b=b,c=c});faces.Add(new AcousticTake.Primitive{objectIndex=owner,a=a,b=c,c=d});
            state[owner].position=Vector3.zero;state[owner].flags=AcousticTake.StateFlags.Active|AcousticTake.StateFlags.Geometry;
        }
        Quad(2,new Vector3(0,-50,-10),new Vector3(0,0,-10),new Vector3(0,0,10),new Vector3(0,-50,10));
        for(int i=0;i<2;i++){float z=i==0?-10:10;Quad(3+i,new Vector3(-50,-50,z),new Vector3(50,-50,z),new Vector3(50,50,z),new Vector3(-50,50,z));}
        state[0].position=new Vector3(-2,1,-8);state[1].position=new Vector3(2,-2,4);
        var rotation=moving?Quaternion.Euler(23,41,17):Quaternion.identity;var translation=moving?new Vector3(3,-2,1):Vector3.zero;
        for(int i=0;i<state.Length;i++)
        {
            state[i].position=rotation*state[i].position+translation;state[i].rotation=rotation;
            if(moving){state[i].velocity=new Vector3(2,-1,.5f);state[i].flags|=AcousticTake.StateFlags.VelocityValid;}
        }
        var inverse=Quaternion.Inverse(rotation);
        var settings=ThirdSettings(1048576);settings.seed=seed;var geometry=faces.ToArray();
        using var solver=new TransportSolver(scene,geometry,settings,RequireGpu(),sampleRate:1000);
        int start=CompleteDebugStart(scene,geometry,settings);
        var expected=new[]{new Complex(.01927493027864146,0),new Complex(-.01466706116165704,-.011393818135651265),new Complex(.003399004650913721,.016628291728268286)};
        for(int bin=0;bin<3;bin++)
        {
            var segments=solver.CaptureRays(state,0,bin);var actual=Complex.Zero;int count=0;
            for(int i=0;i<settings.CompleteSamples;i++)
            {
                int at=start+settings.CompleteDebugStride*i;
                if(segments[at].kind!=TransportSolver.RayEvent.Reflection || segments[at+1].kind!=TransportSolver.RayEvent.Diffraction || segments[at+2].kind!=TransportSolver.RayEvent.Reflection)continue;
                var a=inverse*((Vector3)segments[at].end-translation);var b=inverse*((Vector3)segments[at+1].end-translation);var c=inverse*((Vector3)segments[at+2].end-translation);
                if(Mathf.Abs(a.z+10)>1e-4f || Mathf.Abs(c.z-10)>1e-4f || Mathf.Abs(b.x)>1e-4f || Mathf.Abs(b.y)>1e-4f)continue;
                var arrival=segments[at+3];actual+=arrival.pressure*Complex.Exp(new Complex(0,-2*Math.PI*bin*125*arrival.end.w));count++;
            }
            Debug.Log("THIRD_RDR: seed="+seed+" moving="+moving+" bin="+bin+" actual="+actual+" expected="+expected[bin]+" samples="+count);
            Assert.That((actual-expected[bin]).Magnitude,Is.LessThan(.035*expected[bin].Magnitude));
            if(moving)foreach(var path in solver.RayPaths)if(path.pressureGain!=0 || path.pressureImag!=0)
                Assert.That(path.direction.w,Is.EqualTo(0).Within(2e-6),"Common source/boundary/listener translation must cancel every physical Doppler factor.");
        }
    }
}
