"""Summarize third-order finite room controls without gain/phase fitting."""
import csv,hashlib,json,sys,xml.etree.ElementTree as ET
from pathlib import Path
import numpy as np
root=Path(sys.argv[1]).resolve();base=root/'.context/third-order';out=Path(__file__).resolve().parent
prefix=sys.argv[2] if len(sys.argv)>2 else 'checked'
reference=root/'.context/wave-canopy-2026-10-27/reference-0.25-125.npz';ref=np.load(reference)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def measure(directory,indices):
    config=json.loads((directory/'scene.json').read_text());rows=np.genfromtxt(directory/'renderer.csv',delimiter=',',names=True)
    assert np.allclose(np.array(config['points']).reshape(-1,3),ref['points'][indices],rtol=0,atol=1e-12)
    values=[];fields=[]
    for seed in sorted(set(rows['seed'])):
        r=np.sort(rows[(rows['diffraction']==1)&(rows['seed']==seed)],order='point');assert np.array_equal(r['point'],np.arange(len(indices)))
        p=r['real']+1j*r['imag'];target=ref['pressure'][indices];shadow=r['direct_visible']==0
        values.append(dict(seed=int(seed),samples=config['completeRouteSamples'],order=config.get('completeRouteOrder',2),receivers=len(indices),
         complexRelativeL2=float(np.linalg.norm(p-target)/np.linalg.norm(target)),shadowComplexRelativeL2=float(np.linalg.norm((p-target)[shadow])/np.linalg.norm(target[shadow])),
         zeroReceivers=int(np.count_nonzero(p==0)),medianSolveMs=float(np.median(r['solve_seconds'])*1000),
         pressure=[[v.real,v.imag] for v in p] if len(indices)<10 else None,rendererSha256=sha(directory/'renderer.csv')))
        fields.append(p)
    return values,fields
report=dict(referenceSha256=sha(reference),referenceIndoor=[ref['pressure'][323].real,ref['pressure'][323].imag],
 scope='Finite 3D room/roof, rigid surfaces, unchanged source/receivers and 125 Hz numerical BEM reference. No fitting, clipping or smoothing.')
for name,ids in [('indoor',[323]),('probes-128',[0,323,324,700,900]),('probes-65536',[0,323,324,700,900]),('full',list(range(len(ref['pressure']))))]:
    report[name]=measure(base/(prefix+'-'+name),ids)[0]
ids=[0,323,324,700,900]
old,fields0=measure(root/'.context/solid-boundary/ordered-probes-65536',ids);new,fields1=measure(base/(prefix+'-two-order'),ids)
report['twoOrderParity']=[dict(seed=old[i]['seed'],maxAbsolute=float(np.max(abs(a-b))),relativeL2=float(np.linalg.norm(a-b)/np.linalg.norm(a)),baselineMedianMs=old[i]['medianSolveMs'],currentMedianMs=new[i]['medianSolveMs']) for i,(a,b) in enumerate(zip(fields0,fields1))]
report['families']=list(csv.DictReader((base/(prefix+'-indoor/families.csv')).open()))
report['runs']={name:ET.parse(base/name/'tests.xml').getroot().attrib for name in ['pilot-run','compile2','controls','culled','checked'] if (base/name/'tests.xml').exists()}
(out/('report-'+prefix+'.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['indoor','full','twoOrderParity']},indent=2))
