from pathlib import Path
import csv, hashlib, json, subprocess, sys, warnings
import numpy as np
from scipy.io import wavfile

root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/'tools'))
from sequence_movie import TakeActivity,rotate
base=root/'.context/church-first-person';capture=base/'resumed';take=TakeActivity(capture/'take')
old=json.loads((root/'.context/church-sequence/release/take/take.json').read_text())
for key in ['scene','sceneHash','stateHash','eventHash','sourceBlocksHash','streams','durationSamples','sampleRate']:
 assert take.meta[key]==old[key],key
assert (capture/'route.csv').read_bytes()==(root/'.context/church-sequence/release/route.csv').read_bytes()
summary=json.loads((capture/'summary.json').read_text())
with (capture/'view.csv').open() as f:views=list(csv.DictReader(f))
assert len(views)==summary['frames']==2130
assert len(list((capture/'frames').glob('*.png')))==1801
listener=take.scene['listeners'][0];positions=[];directions=[]
for frame,row in enumerate(views):
 assert int(row['frame'])==frame and abs(float(row['seconds'])-frame/30)<1e-7
 assert float(row['headDistance'])==0
 index=min(len(take.frames)-1,max(0,np.searchsorted(take.frames['sample'],round(float(row['seconds'])*take.rate),side='right')-1))
 pose=take.frames[index]['state'][listener]
 eye=np.array([float(row[k]) for k in ['x','y','z']])
 direction=np.array([float(row[k]) for k in ['forwardX','forwardY','forwardZ']])
 positions.append(float(np.linalg.norm(eye-pose[:3])))
 directions.append(float(np.linalg.norm(direction-rotate(pose[3:7],np.array([0.,0.,1.])))))
assert max(positions)<1e-5 and max(directions)<1e-5
checks=[(0,3.99,False),(0,4.1,True),(0,21,False),(8,15.2,True),(8,18.2,False),(8,19.2,True),(8,22.2,False),(9,22.99,False),(9,23.1,True),(6,32.999,False),(6,33,True),(6,34,True),(6,44,True),(7,44.99,False),(7,45.1,True),(7,56.3,False)]
for source,time,expected in checks:assert take.activity(source,time)[0]==expected,(source,time)
assert all(not take.activity(s,60)[0] for s in take.sources)
report={'frames':len(views),'capturedImageFrames':1801,'heldImageFromSeconds':60,'fps':30,'seconds':71,'sameNumericScenePosesEventsSourcePcmAndRoute':True,'stateHash':take.meta['stateHash'],'eventHash':take.meta['eventHash'],'maximumHeadDistance':0,'maximumRecordedListenerPositionDifference':max(positions),'maximumRecordedListenerForwardDifference':max(directions),'activityChecksPassed':17,'sourceIndicators':len(take.sources),'rainMaskResolution':[take.planes[6]['width'],take.planes[6]['height']]}
movie=base/'church-first-person.mp4'
if movie.exists():
 probe=json.loads(subprocess.check_output(['/opt/homebrew/bin/ffprobe','-v','error','-show_streams','-show_format','-of','json',str(movie)]))
 video=next(s for s in probe['streams'] if s['codec_type']=='video');audio=next(s for s in probe['streams'] if s['codec_type']=='audio')
 assert video['width']==1920 and video['height']==1080 and video['nb_frames']=='2130' and video['avg_frame_rate']=='30/1'
 assert float(probe['format']['duration'])==71 and audio['channels']==1 and audio['sample_rate']=='44100'
 (base/'movie-probe.json').write_text(json.dumps(probe,indent=2)+'\n')
 subprocess.run(['/opt/homebrew/bin/ffmpeg','-v','error','-nostdin','-y','-i',str(movie),'-map','0:a:0','-c:a','pcm_f32le',str(base/'decoded.wav')],check=True)
 with warnings.catch_warnings():
  warnings.simplefilter('ignore');rate,y=wavfile.read(base/'decoded.wav')
 assert rate==44100 and np.isfinite(y).all() and np.max(abs(y))<1
 report.update({'decodedAudioFinite':True,'decodedAudioPeak':float(np.max(abs(y))),'clippedSamples':int(np.count_nonzero(abs(y)>=1)),'movieBytes':movie.stat().st_size,'movieSha256':hashlib.sha256(movie.read_bytes()).hexdigest()})
(base/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
